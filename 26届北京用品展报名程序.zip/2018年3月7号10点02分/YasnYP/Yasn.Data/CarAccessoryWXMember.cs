﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Model;
using Yasn.Model.WechatClass;
using Yasn.Utility;

namespace Yasn.Data
{
    public class CarAccessoryWXMember
    {

        public bool IsExistsWXMember(string weiXinNo)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from WXMember as a,dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where a.Id=c.vxmenberid and c.zhanhuiid=b.ID and b.shifoudangqianzh=1 and  a.WXNo='{0}'", weiXinNo);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public bool IsExistsWXMember(string weiXinNo, int zhanhuiId)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from WXMember as a with(nolock),dbo.zhanhuiguanlian  as c  with(nolock) where a.Id=c.vxmenberid and c.zhanhuiid={1} and  a.WXNo='{0}'", weiXinNo, zhanhuiId);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }
            else
            {
                return false;
            }
        }

        public bool IsExistsBaoXiao(string phone)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from WXMember as a,dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where a.Id=c.vxmenberid and c.zhanhuiid=b.ID and b.shifoudangqianzh=1 and  c.phone='{0}' and gift & 1=1", phone);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public bool IsExistsBaoXiao(string phone, int zhanhuiId)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from WXMember as a,dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where a.Id=c.vxmenberid and c.zhanhuiid=b.ID and b.ID={1} and  c.phone='{0}' and gift & 1=1", phone, zhanhuiId);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public bool IsExistsPhoneOfCurrent(string phone)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where  c.zhanhuiid=b.ID and b.shifoudangqianzh=1 and  c.phone='{0}'", phone);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        /// <summary>
        /// 根据手机号查询是否通过其他渠道报名
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public bool IsExistsPhoneOfAllChannels(string phone)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from PhoneBasic WITH(NOLOCK) where  yasn_phone='{0}'", phone);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }
        public bool IsExistsPhoneOfCurrent(string phone, int zhanhuiId)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select count(1) from dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where  c.zhanhuiid=b.ID and b.ID={1} and  c.phone='{0}'", phone, zhanhuiId);


            object result = DbHelperSQL.GetSingle(strSql.ToString());
            if (result != null && result != DBNull.Value)
            {
                if ((int)result > 0)
                    return true;
                else
                    return false;
            }

            return false;
        }

        public long GetMaxMemberNo()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Max(card) from zhanhuiguanlian as zl,zhanhui as z where zl.zhanhuiid=z.ID and  z.shifoudangqianzh=1");

            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return 0;

            return Convert.ToInt64(obj.ToString());
        }

        /// <summary>
        /// 根据展会获取最大卡号编号 
        /// 添加人：李晚强 添加时间：2016-09-08 11:37:21
        /// </summary>
        /// <param name="zhanhuiID">展会ID</param>  
        /// <returns></returns>
        public long GetMaxMemberNoNow(int zhanhuiID)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.AppendFormat("select Max(card) from zhanhuiguanlian as zl where zl.zhanhuiid ={0}", zhanhuiID);
            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return 0;

            return Convert.ToInt64(obj.ToString());
        }

        public long GetMaxMemberNo(int zhanhuiId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.AppendFormat("select Max(card) from zhanhuiguanlian as zl,zhanhui as z where zl.zhanhuiid=z.ID and  z.ID={0}", zhanhuiId);

            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return 0;

            return Convert.ToInt64(obj.ToString());
        }
        /// <summary>
        /// 增加一条数据

        /// </summary>
        public string Add(WXMember model)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into WXMember(");
                strSql.Append("WXNo,MemberNo,CreateDate");
                strSql.Append(") values (");
                strSql.Append("@WXNo,@MemberNo,@CreateDate");
                strSql.Append(");Select @@Identity;");

                SqlParameter[] parameters = {
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@MemberNo", SqlDbType.BigInt),
                        new SqlParameter("@CreateDate",SqlDbType.DateTime)
            };

                parameters[0].Value = model.WXNo;
                parameters[1].Value = model.MemberNo;
                parameters[2].Value = model.CreateDate;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        public string AddWXMemberByPhone(WXMember model)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into WXMember(");
                strSql.Append("UserName,WXNo,MemberNo,Mobile,CompanyName");
                strSql.Append(") values (");
                strSql.Append("@UserName,@WXNo,@MemberNo,@Mobile,@CompanyName");
                strSql.Append(");Select @@Identity;");

                SqlParameter[] parameters = {
                        new SqlParameter("@UserName", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@MemberNo", SqlDbType.BigInt),
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,50),
                         new SqlParameter("@CompanyName", SqlDbType.NVarChar,50) ,
            };
                parameters[0].Value = model.UserName;
                parameters[1].Value = model.WXNo;
                parameters[2].Value = model.MemberNo;
                parameters[3].Value = model.Mobile;
                parameters[4].Value = model.CompanyName;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 得到当前展会实例列表
        /// </summary>
        /// <returns></returns>
        public List<Zhanhui> GetZHList()
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  [ID],[zhanhuiname],[shifoudangqianzh] ");
            sbSql.Append(" FROM zhanhui where shifoudangqianzh=1");
            List<Zhanhui> list = new List<Zhanhui>();
            using (var reader = DbHelperSQL.ExecuteReader(sbSql.ToString()))
            {
                while (reader.Read())
                {
                    list.Add(new Zhanhui()
                    {
                        Id = int.Parse(reader["ID"].ToString()),
                        ZhanhuiName = reader["zhanhuiname"].ToString(),
                        Shifoudangqianzh = bool.Parse(reader["shifoudangqianzh"].ToString())
                    });
                }
            }
            return list;
        }
        /// <summary>
        /// 得到当前展会实例列表
        /// </summary>
        /// <returns></returns>
        public List<Zhanhui> GetZHList(int zhanhuiId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  [ID],[zhanhuiname],[shifoudangqianzh] ");
            sbSql.AppendFormat(" FROM zhanhui where ID={0}", zhanhuiId);
            List<Zhanhui> list = new List<Zhanhui>();
            using (var reader = DbHelperSQL.ExecuteReader(sbSql.ToString()))
            {
                while (reader.Read())
                {
                    list.Add(new Zhanhui()
                    {
                        Id = int.Parse(reader["ID"].ToString()),
                        ZhanhuiName = reader["zhanhuiname"].ToString(),
                        Shifoudangqianzh = bool.Parse(reader["shifoudangqianzh"].ToString())
                    });
                }
            }
            return list;
        }

        public string UpdateZhanHuiGuanLian(ZhanHuiGuanLianModel model)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@vxmenberid", SqlDbType.Int),
                        new SqlParameter("@name", SqlDbType.VarChar,20),
                        new SqlParameter("@cjiname", SqlDbType.VarChar,100),
                        new SqlParameter("@job", SqlDbType.VarChar,50),
                        new SqlParameter("@tqhd", SqlDbType.VarChar,100),
                        new SqlParameter("@ProType", SqlDbType.VarChar,500),
                        new SqlParameter("@phone", SqlDbType.VarChar,500)
                     };
            parameters[0].Value = model.vxmenberid;
            parameters[1].Value = model.name;
            parameters[2].Value = model.cjiname;
            parameters[3].Value = model.job;
            parameters[4].Value = model.tqhd;
            parameters[5].Value = model.ProType;
            parameters[6].Value = model.phone;

            StringBuilder sbSql = new StringBuilder();
            if (model.zhanhuiid == 0)
            {
                sbSql.Append("update zhanhuiguanlian  ");
                sbSql.Append("  set vxmenberid=@vxmenberid,name=@name,cjiname=@cjiname,job=@job,tqhd=@tqhd,ProType=@ProType ");
                sbSql.Append(" from zhanhui z ");
                sbSql.Append("  where zhanhuiguanlian.zhanhuiid=z.ID AND z.shifoudangqianzh=1 and phone=@phone;Select zl.id from zhanhuiguanlian as zl,zhanhui z  where zl.zhanhuiid=z.ID AND z.shifoudangqianzh=1 and phone=@phone ");
            }
            else
            {
                sbSql.Append("update zhanhuiguanlian  ");
                sbSql.Append("  set vxmenberid=@vxmenberid,name=@name,cjiname=@cjiname,job=@job,tqhd=@tqhd,ProType=@ProType ");
                sbSql.AppendFormat("  where zhanhuiguanlian.zhanhuiid={0} and phone=@phone;Select zl.id from zhanhuiguanlian as zl,zhanhui z  where zl.zhanhuiid=z.ID AND z.ID={0} and phone=@phone ", model.zhanhuiid);

            }
            object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
            if (obj == null)
            {
                return "0";
            }
            else
            {
                return Convert.ToInt32(obj).ToString();
            }
        }

        public string AddZhanHuiGuanLian(ZhanHuiGuanLianModel model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@zhanhuiid", SqlDbType.Int) ,
                        new SqlParameter("@vxmenberid", SqlDbType.Int),
                        new SqlParameter("@createtime", SqlDbType.DateTime),
                        new SqlParameter("@phone", SqlDbType.VarChar,20),
                        new SqlParameter("@name", SqlDbType.VarChar,20),
                        new SqlParameter("@cjiname", SqlDbType.VarChar,100),
                        new SqlParameter("@job", SqlDbType.VarChar,50),
                        new SqlParameter("@email", SqlDbType.VarChar,50),
                        new SqlParameter("@tqhd", SqlDbType.VarChar,100),
                        new SqlParameter("@card", SqlDbType.VarChar,100),
                        new SqlParameter("@cardimageurl", SqlDbType.VarChar,500),
                        new SqlParameter("@gift", SqlDbType.Int),
                        new SqlParameter("@channel", SqlDbType.VarChar,10),
                        new SqlParameter("@mapId", SqlDbType.BigInt),
                        new SqlParameter("@tongbu", SqlDbType.Bit),
                        new SqlParameter("@exhibitorId", SqlDbType.Int),
                        new SqlParameter("@ProType", SqlDbType.VarChar,500),
                        new SqlParameter("@LeadID", SqlDbType.Int),
                        new SqlParameter("@IsZS", SqlDbType.Int),
                        new SqlParameter("@Telephone", SqlDbType.VarChar,500),
                        new SqlParameter("@YXZhanhui", SqlDbType.VarChar)
                     };

                if (model.zhanhuiid == 0)
                {
                    Yasn.Model.Zhanhui result = GetZHList().FirstOrDefault();
                    parameters[0].Value = result == null ? -1 : result.Id;
                }
                else
                {
                    parameters[0].Value = model.zhanhuiid;
                }
                parameters[1].Value = model.vxmenberid;
                parameters[2].Value = model.createtime;
                parameters[3].Value = model.phone;
                parameters[4].Value = model.name;
                parameters[5].Value = model.cjiname;
                parameters[6].Value = model.job;
                parameters[7].Value = model.email;
                parameters[8].Value = model.tqhd;
                parameters[9].Value = model.card;
                parameters[10].Value = model.cardimageurl;
                parameters[11].Value = model.gift;
                parameters[12].Value = model.Channel;
                parameters[13].Value = model.MapID;
                parameters[14].Value = model.shifoutb;
                parameters[15].Value = model.ExhibitorId;
                parameters[16].Value = model.ProType;
                parameters[17].Value = model.LeadId;
                parameters[18].Value = model.IsZS;
                parameters[19].Value = model.Telephone;
                parameters[20].Value = model.YXZhanhui;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  zhanhuiguanlian(zhanhuiid, ");
                sbSql.Append("  vxmenberid,createtime,phone,name, ");
                sbSql.Append("  cjiname,job,email,tqhd,card,cardimageurl,gift,channel,mapId,shifoutb,exhibitorId,ProType,LeadID,IsZS,Telephone,YXZhanhui,cardtype)");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@zhanhuiid, ");
                sbSql.Append("  @vxmenberid,@createtime,@phone,@name, ");
                sbSql.Append("  @cjiname,@job,@email,@tqhd,@card,@cardimageurl,@gift,@channel,@mapId,@tongbu,@exhibitorId,@ProType,@LeadID,@IsZS,@Telephone,@YXZhanhui,3) Select @@Identity");
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /// <summary>
        /// 通过其他渠道报名的信息插入到zhanhuiguanlian表中
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int AddZhanHuiGuanLianByOther(ZhanHuiGuanLianModel model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@vxmenberid", SqlDbType.Int),
                        new SqlParameter("@phone", SqlDbType.VarChar,20),
                        new SqlParameter("@name", SqlDbType.VarChar,20),
                        new SqlParameter("@card", SqlDbType.VarChar,100),
                        new SqlParameter("@cardimageurl", SqlDbType.VarChar,500),
                        new SqlParameter("@gift", SqlDbType.Int),
                        new SqlParameter("@tongbu", SqlDbType.Bit),
                        new SqlParameter("@MainBusine",SqlDbType.VarChar,100),
                        new SqlParameter("@ProType",SqlDbType.VarChar,500),
                        new SqlParameter("@IsGift",SqlDbType.Int),
                        new SqlParameter("@cjiname", SqlDbType.VarChar,100),
                        new SqlParameter("@job", SqlDbType.VarChar,500),
                        new SqlParameter("@ManageType", SqlDbType.VarChar,500),
                        new SqlParameter("@EnjoyProduct", SqlDbType.VarChar,500),
                        new SqlParameter("@zhanhuiid", SqlDbType.Int),
                        new SqlParameter("@WeiXinOpenId", SqlDbType.VarChar,500),
                        new SqlParameter("@LeadID", SqlDbType.Int)
                     };
                parameters[0].Value = model.vxmenberid;
                parameters[1].Value = model.phone;
                parameters[2].Value = model.name;
                parameters[3].Value = model.card;
                parameters[4].Value = model.cardimageurl;
                parameters[5].Value = model.gift;
                parameters[6].Value = model.shifoutb;
                parameters[7].Value = model.MainBusine;
                parameters[8].Value = model.IndustryOwend;  //所属行业
                parameters[9].Value = model.IsGift;
                parameters[10].Value = model.cjiname;
                parameters[11].Value = model.job;
                parameters[12].Value = model.ManageType;
                parameters[13].Value = model.EnjoyProduct;
                parameters[14].Value = model.zhanhuiid;
                parameters[15].Value = model.WeiXinOpenId;
                parameters[16].Value = model.LeadId;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  zhanhuiguanlian(zhanhuiid,vxmenberid,phone, ");
                sbSql.Append("name, ");
                sbSql.Append("  card,cardimageurl,gift,shifoutb,MainBusine,ProType,IsZS,cardtype,IsGift,cjiname,job,ManageType,EnjoyProduct,WXNo,LeadId)");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@zhanhuiid,@vxmenberid,@phone, ");
                sbSql.Append(" @name, ");
                sbSql.Append("  @card,@cardimageurl,0,@tongbu,@MainBusine,@ProType,0,3,@IsGift,@cjiname,@job,@ManageType,@EnjoyProduct,@WeiXinOpenId,@LeadID) Select @@Identity");
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return 0;
                }
                else
                {
                    return Convert.ToInt32(obj);
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        public List<ZhanHuiGuanLianModel> GetListByWxno(int zhanhuiid, string wxNo)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  z.id,z.gift ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember w with(nolock) ");
            sbSql.Append("INNER JOIN zhanhuiguanlian z with(nolock) ");
            sbSql.Append("  ON w.id=z.vxmenberid ");
            sbSql.Append("WHERE ");
            sbSql.Append("  z.zhanhuiid=@zhanhuiid ");
            sbSql.Append("  AND w.WXNo=@WXNO ");

            SqlParameter[] parameters = {
                new SqlParameter("@zhanhuiid",zhanhuiid),
                new SqlParameter("@WXNO",wxNo)
            };

            ZhanHuiGuanLianModel model = null;
            List<ZhanHuiGuanLianModel> modeList = new List<ZhanHuiGuanLianModel>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new ZhanHuiGuanLianModel();
                    if (row["Id"].ToString() != "")
                    {
                        model.Id = int.Parse(row["Id"].ToString());
                    }
                    //model.zhanhuiid = zhanhuiid;
                    //model.vxmenberid = int.Parse(row["vxmenberid"].ToString());
                    //model.ContactId = row["ContactId"].ToString();
                    //if (row["shifoutb"].ToString() != "")
                    //{
                    //    model.shifoutb = bool.Parse(row["shifoutb"].ToString());
                    //}
                    //else
                    //{
                    //    model.shifoutb = false;
                    //}
                    //if (row["Createtime"].ToString() != "")
                    //{
                    //    model.createtime = DateTime.Parse(row["Createtime"].ToString());
                    //}
                    //model.owneridname = row["owneridname"].ToString();
                    //model.tqhd = row["tqhd"].ToString();
                    //model.card = row["card"].ToString();
                    //model.cardimageurl = row["cardimageurl"].ToString();
                    //if (row["cardtype"].ToString() != "")
                    //{
                    //    model.cardtype = int.Parse(row["cardtype"].ToString());
                    //}
                    //model.phone = row["phone"].ToString();
                    //model.name = row["name"].ToString();
                    //model.cjiname = row["cjiname"].ToString();
                    //model.job = row["job"].ToString();
                    //model.email = row["email"].ToString();
                    //if (row["IsZS"].ToString() != "")
                    //{
                    //    model.IsZS = Convert.ToInt32(row["IsZS"].ToString());
                    //}
                    if (row["gift"].ToString() != "")
                    {
                        model.gift = Convert.ToInt32(row["gift"].ToString());
                    }
                    modeList.Add(model);
                }
            }
            return modeList;
        }
        public List<ZhanHuiGuanLianModel> GetListByPhone(string card, string Phone)
        {

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  a.phone, ");
            sbSql.Append("  a.id, ");
            sbSql.Append("  a.zhanhuiid,a.gift ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian a with(nolock) ");
            sbSql.Append("INNER JOIN PhoneBasic b with(nolock) ");
            sbSql.Append("  ON a.card=@yasn_code ");
            sbSql.Append("  AND a.phone=@yasn_phone ");

            SqlParameter[] parameters = {
                new SqlParameter("@yasn_code",card),
                new SqlParameter("@yasn_phone",Phone)
            };

            ZhanHuiGuanLianModel model = null;
            List<ZhanHuiGuanLianModel> modeList = new List<ZhanHuiGuanLianModel>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new ZhanHuiGuanLianModel();
                    if (row["Id"].ToString() != "")
                    {
                        model.Id = int.Parse(row["Id"].ToString());
                    }
                    if (row["gift"].ToString() != "")
                    {
                        model.gift = Convert.ToInt32(row["gift"].ToString());
                    }
                    modeList.Add(model);
                }
            }
            return modeList;
        }
        /// <summary>
        /// 从手机号库中查询是否存在符合条件的记录，
        /// </summary>
        /// <param name="card"></param>
        /// <param name="Phone"></param>
        /// <returns></returns>
        public List<Test_Phone> GetListByPhoned(string card, string Phone)
        {

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  yasn_phone, ");
            sbSql.Append("  yasn_code, ");
            sbSql.Append("  cardimageurl, ");
            sbSql.Append("  fullname, ");
            sbSql.Append("  signup, ");
            sbSql.Append("  ISGift ");
            sbSql.Append("FROM ");
            sbSql.Append("  PhoneBasic WITH(NOLOCK) ");
            sbSql.Append("WHERE ");
            sbSql.Append("  yasn_phone=@yasn_phone ");
            sbSql.Append(" and yasn_code=@yasn_code ");
            SqlParameter[] parameters = {
                new SqlParameter("@yasn_code",card),
                new SqlParameter("@yasn_phone",Phone)
            };

            Test_Phone model = null;
            List<Test_Phone> modeList = new List<Test_Phone>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new Test_Phone();
                    if (row["yasn_phone"].ToString() != "")
                    {
                        model.yasn_phone = row["yasn_phone"].ToString();
                    }
                    if (row["yasn_code"].ToString() != "")
                    {
                        model.yasn_code = row["yasn_code"].ToString();
                    }

                    if (row["cardimageurl"].ToString() != "")
                    {
                        model.cardimageurl = row["cardimageurl"].ToString();
                    }
                    if (row["fullname"].ToString() != "")
                    {
                        model.fullname = row["fullname"].ToString();
                    }
                    if (row["signup"].ToString() != "")
                    {
                        model.signup = Convert.ToInt32(row["signup"].ToString());
                    }
                    if (row["ISGift"].ToString() != "")
                    {
                        model.ISGift = Convert.ToInt32(row["ISGift"].ToString());
                    }
                    modeList.Add(model);
                }
            }
            return modeList;
        }
        public List<Test_Phone> GetListByPhone(string Phone)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  yasn_phone, ");
            sbSql.Append("  yasn_code, ");
            sbSql.Append("  cardimageurl, ");
            sbSql.Append("  fullname, ");
            sbSql.Append("  signup, ");
            sbSql.Append("  ISGift, ");
            sbSql.Append("  job, ");
            sbSql.Append("  protype, ");
            sbSql.Append("  mainbusine, ");
            sbSql.Append("  managetype,Company ");
            sbSql.Append("FROM ");
            sbSql.Append("  PhoneBasic WITH(NOLOCK) ");
            sbSql.Append(" WHERE ");
            sbSql.Append("  yasn_phone=@Phone ");

            SqlParameter[] parameters = {
                new SqlParameter("@Phone",Phone),
            };

            Test_Phone model = null;
            List<Test_Phone> modeList = new List<Test_Phone>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new Test_Phone();
                    if (row["yasn_phone"].ToString() != "")
                    {
                        model.yasn_phone = (row["yasn_phone"].ToString());
                    }
                    if (row["yasn_code"].ToString() != "")
                    {
                        model.yasn_code = (row["yasn_code"].ToString());
                    }
                    if (row["cardimageurl"].ToString() != "")
                    {
                        model.cardimageurl = (row["cardimageurl"].ToString());
                    }
                    model.fullname = row["fullname"].ToString();

                    if (row["signup"].ToString() != "")
                    {
                        model.signup = int.Parse((row["signup"].ToString()));
                    }
                    if (row["ISGift"].ToString() != "")
                    {
                        model.ISGift = Convert.ToInt32(row["ISGift"].ToString());
                    }
                    model.job= (row["job"].ToString());
                    model.protype = (row["protype"].ToString());
                    model.mainbusine = (row["mainbusine"].ToString());
                    model.managetype = (row["managetype"].ToString());
                    model.Company = (row["Company"].ToString());
                    modeList.Add(model);
                }
            }
            return modeList;
        }

        public DataTable GetDQBMID(string weiXinNo)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  zl.id, ");
            sbSql.Append("  zl.shifoutb,zl.gift ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian zl with(nolock) ");
            sbSql.Append("INNER JOIN zhanhui z ");
            sbSql.Append("  ON zl.zhanhuiid=z.ID ");
            sbSql.Append("  AND z.shifoudangqianzh=1 ");
            sbSql.Append("INNER JOIN WXMember w ");
            sbSql.Append("  ON w.id=zl.vxmenberid ");
            sbSql.Append("  AND w.WXNo='" + weiXinNo.Trim() + "' ");

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }

        public DataTable GetDQBMID(string weiXinNo, int zhanhuiId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  zl.id, ");
            sbSql.Append("  zl.shifoutb,zl.gift ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian zl with(nolock) ");
            sbSql.Append("INNER JOIN zhanhui z ");
            sbSql.Append("  ON zl.zhanhuiid=z.ID ");
            sbSql.AppendFormat("  AND z.ID={0} ", zhanhuiId);
            sbSql.Append("INNER JOIN WXMember w ");
            sbSql.Append("  ON w.id=zl.vxmenberid ");
            sbSql.AppendFormat("  AND w.WXNo='{0}'", weiXinNo.Trim());

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }
        public DataTable GetDQBMBYID(string weiXinNo, int zhanhuiId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  zl.id,zl.phone ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian zl with(nolock) ");
            sbSql.Append("INNER JOIN WXMember w with(nolock)");
            sbSql.Append("  ON w.id=zl.vxmenberid ");
            sbSql.AppendFormat("  AND w.WXNo='{0}'", weiXinNo.Trim());
            sbSql.AppendFormat("  where  zl.zhanhuiid={0} ", zhanhuiId);

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }

        public void UpdateApply(int userId, int giftId, bool isTongBu)
        {
            StringBuilder strSql = new StringBuilder();
            if (isTongBu)
            {
                strSql.AppendFormat("update dbo.zhanhuiguanlian  set shifoutb=0, gift=gift | {0}  where id={1}", giftId, userId);
            }
            else
            {
                strSql.AppendFormat("update dbo.zhanhuiguanlian  set gift=gift | {0}  where id={1}", giftId, userId);
            }
            DbHelperSQL.ExecuteSql(strSql.ToString());
        }

        public DataTable GetUserConcern(int userId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("select aa.tqhdname ");
            sbSql.Append(" from dbo.ActiveList as aa,zhanhui as zz, ");
            sbSql.AppendFormat("  (select F1 from dbo.splitstr((select tqhd  from zhanhuiguanlian where id={0}),',')) as ff ", userId);
            sbSql.Append(" where aa.zhid=zz.ID and zz.shifoudangqianzh=1 and aa.tqhdbh=ff.F1 ");
            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }
        /// <summary>
        /// 根据他方用户ID获取用户二维码
        /// </summary>
        /// <param name="mapId">他方用户ID</param>
        /// <returns></returns>
        public string GetUserQRCode(long mapId)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.AppendFormat("select cardimageurl from zhanhuiguanlian where mapId={0}", mapId);
            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return string.Empty;

            return obj.ToString();
        }

        public List<Activity> GetActivityOfCurrent(int zhanhuiid)
        {
            List<Activity> activityList = new List<Activity>();
            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat(" select [id],[tqhd],[StateCode],[zhanhuiid]  FROM [Activity] where zhanhuiid={0} ", zhanhuiid);
            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            Activity model = null;
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    model = new Activity();

                    if (row["id"].ToString() != "")
                    {
                        model.ID = int.Parse(row["id"].ToString());
                    }
                    model.Tqhd = row["tqhd"].ToString();

                    if (row["StateCode"].ToString() != "")
                    {
                        model.StateCode = Convert.ToBoolean(row["StateCode"]);
                    }

                    if (row["zhanhuiid"].ToString() != "")
                    {
                        model.Zhanhuiid = int.Parse(row["zhanhuiid"].ToString());
                    }

                    activityList.Add(model);
                }
            }
            return activityList;
        }
        /// <summary>
        /// 根据手机号码获取该用户的酒店入住相关信息
        /// </summary>
        /// <param name="zhanhuiId"></param>
        /// <param name="weiXinNo"></param>
        /// <param name="fullname"></param>
        /// <param name="bm"></param>
        /// <param name="isgift"></param>
        /// <returns></returns>
        public int GetMID(int zhanhuiId, string phone,  ref string FullName, ref string HotelName, ref string RoomType, ref DateTime CheckInDate, ref DateTime CheckOutDate, ref string CheckInState, ref string Remark)
        {
            int ID = 0;
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  a.ID , ");
            sbSql.Append("  a.FullName , ");
            sbSql.Append("  b.Name , ");
            sbSql.Append("  a.RoomType , ");
            sbSql.Append("  a.CheckInDate , ");
            sbSql.Append("  a.CheckOutDate , ");
            sbSql.Append("  a.CheckInState, ");
            sbSql.Append("  a.Remark ");
            sbSql.Append("FROM ");
            sbSql.Append("  dbo.HotelCheckIn a ");
            sbSql.Append("INNER JOIN dbo.Hotel b ");
            sbSql.Append("  ON a.HotelID = b.ID ");
            sbSql.Append("  AND StateCode = '可用' ");
            sbSql.Append("INNER JOIN dbo.Company c ");
            sbSql.Append("  ON a.CompanyID = c.ID ");
            sbSql.Append("WHERE ");
            sbSql.Append("  GETDATE() ");
            sbSql.Append("BETWEEN ");
            sbSql.Append("  CheckInDate ");
            sbSql.Append("  AND CheckOutDate AND");
            sbSql.Append("   a.Mobilephone ='" + phone + "' ");
            sbSql.Append("  AND zhanhuiid = " + zhanhuiId + "  ");
            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                ID =int.Parse(dt.Rows[0]["ID"].ToString());
                FullName = dt.Rows[0]["FullName"].ToString();
                HotelName = dt.Rows[0]["Name"].ToString();
                RoomType = dt.Rows[0]["RoomType"].ToString();
                CheckInDate = DateTime.Parse(dt.Rows[0]["CheckInDate"].ToString());
                CheckOutDate = DateTime.Parse(dt.Rows[0]["CheckOutDate"].ToString());
                CheckInState = dt.Rows[0]["CheckInState"].ToString();
                Remark = dt.Rows[0]["Remark"].ToString();
            }
            return ID;
        }
        public DataTable GetMID(int zhanhuiId, string phone)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  a.ID , ");
            sbSql.Append("  a.FullName , ");
            sbSql.Append("  b.Name , ");
            sbSql.Append("  a.RoomType , ");
            sbSql.Append("  a.CheckInDate , ");
            sbSql.Append("  a.CheckOutDate , ");
            sbSql.Append("  a.CheckInState, ");
            sbSql.Append("  a.Remark ");
            sbSql.Append("FROM ");
            sbSql.Append("  dbo.HotelCheckIn a ");
            sbSql.Append("INNER JOIN dbo.Hotel b ");
            sbSql.Append("  ON a.HotelID = b.ID ");
            sbSql.Append("  AND StateCode = '可用' ");
            sbSql.Append("INNER JOIN dbo.Company c ");
            sbSql.Append("  ON a.CompanyID = c.ID ");
            sbSql.Append("WHERE ");
            sbSql.Append("  GETDATE() ");
            sbSql.Append("BETWEEN ");
            sbSql.Append("  CheckInDate ");
            sbSql.Append("  AND CheckOutDate AND");
            sbSql.Append("   a.Mobilephone ='" + phone + "' ");
            sbSql.Append("  AND zhanhuiid = " + zhanhuiId + "  ");
            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }
        /// <summary>
        /// 点击入住
        /// </summary>
        /// <param name="openid"></param>
        /// <param name="flag"></param>
        /// <param name="zhanhuiid"></param>
        /// <returns></returns>
        public string GoCheckIn(string ID, int zhanhuiid)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("update dbo.HotelCheckIn  set CheckInState='已入住'  where ID={0} and zhanhuiid={1}", ID, zhanhuiid);


            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return "0";
            }
            else
            {
                return "入住成功";
            }
        }
        public int AddToken(TokenInfo model)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into TokenInfo(");
                strSql.Append("access_token,expiretime");
                strSql.Append(") values (");
                strSql.Append("@access_token,@expiretime");
                strSql.Append(");Select @@Identity;");

                SqlParameter[] parameters = {
                        new SqlParameter("@access_token", SqlDbType.NVarChar,350) ,
                        new SqlParameter("@expiretime", SqlDbType.DateTime)
            };

                parameters[0].Value = model.access_token;
                parameters[1].Value = model.expiretime;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                if (obj == null)
                {
                    return 0;
                }
                else
                {
                    return Convert.ToInt32(obj);
                }

            }
            catch (Exception ex)
            {
                return 0;
            }

        }
        public string GetToken()
        {
            string sql = "SELECT TOP 1 access_token,expiretime FROM tokeninfo WITH(NOLOCK) ORDER BY id desc";
            DataTable dt = DbHelperSQL.Query(sql).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                if (DateTime.Now >= Convert.ToDateTime(dt.Rows[0]["expiretime"]))
                {
                    return "";
                }
                return dt.Rows[0]["access_token"].ToString();
            }
            return "";
        }
        public string GetQCode(int Code)
        {
            string sql = "SELECT TOP 1 ImgUrl FROM SignUpSMS WITH(NOLOCK) where bm='" + Code + "'";
            DataTable dt = DbHelperSQL.Query(sql).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                return dt.Rows[0]["ImgUrl"].ToString();
            }
            return "";
        }
        /// <summary>
        /// 将每次发送的短信信息存入短信日志表中，便于统计
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddSMSHistory(SMSHistory model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@zhanhuiid", SqlDbType.Int) ,
                        new SqlParameter("@SMSContent", SqlDbType.NVarChar,200),
                        new SqlParameter("@SerialNum", SqlDbType.NVarChar,20),
                        new SqlParameter("@Channel", SqlDbType.Int),
                        new SqlParameter("@SMSType", SqlDbType.Int),
                        new SqlParameter("@Phone", SqlDbType.NVarChar,20)
                     };

                if (model.ZhanhuiID == 0)
                {
                    Yasn.Model.Zhanhui result = GetZHList().FirstOrDefault();
                    parameters[0].Value = result == null ? -1 : result.Id;
                }
                else
                {
                    parameters[0].Value = model.ZhanhuiID;
                }
                parameters[1].Value = model.SMSContent;
                parameters[2].Value = model.SerialNum;
                parameters[3].Value = model.Channel;
                parameters[4].Value = model.SMSType;
                parameters[5].Value = model.Phone;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  SMSHistory(ZhanhuiID, ");
                sbSql.Append("  SMSContent, ");
                sbSql.Append("  SerialNum, ");
                sbSql.Append("  Channel, ");
                sbSql.Append("  SMSType, ");
                sbSql.Append("  phone) ");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@zhanhuiid, ");
                sbSql.Append("  @SMSContent, ");
                sbSql.Append("  @SerialNum, ");
                sbSql.Append("  @Channel, ");
                sbSql.Append("  @SMSType, ");
                sbSql.Append("  @Phone) ");
                sbSql.Append("SELECT ");
                sbSql.Append("  @@Identity ");
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /// <summary>
        /// 向数据库插入用户的位置信息
        /// </summary>
        /// <param name="Lng">经度</param>
        /// <param name="Lat">纬度</param>
        /// <param name="Province">省份</param>
        /// <param name="City">城市</param>
        /// <param name="District">区县</param>
        /// <returns></returns>
        public string AddLocationInfo(int ZhanhuiNo, string openid, decimal Lng, decimal Lat, string Province, string City, string District)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@ZhanhuiNo", SqlDbType.Int) ,
                        new SqlParameter("@openid", SqlDbType.NVarChar,50),
                        new SqlParameter("@Lng", SqlDbType.Decimal) ,
                        new SqlParameter("@Lat", SqlDbType.Decimal),
                        new SqlParameter("@Province", SqlDbType.NVarChar,50),
                        new SqlParameter("@City", SqlDbType.NVarChar,50),
                        new SqlParameter("@District", SqlDbType.NVarChar,50)
                     };
                parameters[0].Value = ZhanhuiNo;
                parameters[1].Value = openid;
                parameters[2].Value = Lng;
                parameters[3].Value = Lat;
                parameters[4].Value = Province;
                parameters[5].Value = City;
                parameters[6].Value = District;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  LocationInfo(ZhanhuiID,WXNo,LongItude, ");
                sbSql.Append("  LatItude,Province, ");
                sbSql.Append("  City,District)");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@ZhanhuiNo,@openid,@Lng, ");
                sbSql.Append("  @Lat,@Province, ");
                sbSql.Append("  @City,@District) Select @@Identity");
                int obj = DbHelperSQL.ExecuteSql(sbSql.ToString(), parameters);
                if (obj < 0)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        /// <summary>
        /// 进入程序首先判断微信openid是否已经报过名
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public DataTable IsWXNo(string weiXinNo, int zhanhuiId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  ID ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian  with(nolock) ");
            sbSql.AppendFormat("  where WXNo='{0}'", weiXinNo.Trim());
            sbSql.AppendFormat("  and  zhanhuiid={0} ", zhanhuiId);

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }

        /// <summary>
        /// 多个微信号绑定同一个手机号，则更新微信号；
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateWXNOByPhone(WXMember model)
        {
            SqlParameter[] parameters = {
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50),
                        new SqlParameter("@CreateDate", SqlDbType.DateTime),
                        new SqlParameter("@phone", SqlDbType.NVarChar,50)
                     };
            parameters[0].Value = model.WXNo;
            parameters[1].Value = model.CreateDate;
            parameters[2].Value = model.Mobile;

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("UPDATE ");
            sbSql.Append("  dbo.WXMember ");
            sbSql.Append("SET ");
            sbSql.Append("  WXNo=@WXNo , ");
            sbSql.Append("  CreateDate=@CreateDate ");
            sbSql.Append("WHERE ");
            sbSql.Append("  Mobile=@phone ");

            object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
            if (obj == null)
            {
                return "0";
            }
            else
            {
                return Convert.ToInt32(obj).ToString();
            }
        }

        /// <summary>
        /// 更新微信号之后，通过手机号获取展会关联表中的id
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public DataTable GetIDByPhone(string phone, int ZhanhuiNo)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT  ");
            sbSql.Append(" top 1 id ");
            sbSql.Append("FROM ");
            sbSql.Append("  dbo.zhanhuiguanlian with(nolock) ");
            sbSql.Append("WHERE ");
            sbSql.AppendFormat(" zhanhuiid ='{0}' ", ZhanhuiNo);
            sbSql.Append("  AND phone ='" + phone.Trim() + "'");
            sbSql.Append("ORDER BY ");
            sbSql.Append("  id DESC ");

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }

        /// <summary>
        /// 根据手机号查询当前该手机号为过期的验证码
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public DataTable QueryCode(string phone)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT  ");
            sbSql.Append(" top 1 VerCode ");
            sbSql.Append("FROM ");
            sbSql.Append("  dbo.VerCodeExprise with(nolock) ");
            sbSql.Append("WHERE ");
            sbSql.Append(" ExpriseDate>GETDATE() ");
            sbSql.Append("  AND phone ='" + phone.Trim() + "'");
            sbSql.Append("ORDER BY ");
            sbSql.Append("  ExpriseDate DESC ");

            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            return dt;
        }

        public string ZHGLUpdateWXNOByPhone(string WXNo, string Mobile, int ZhanhuiNo)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("update dbo.zhanhuiguanlian  set WXNo='{0}', issend=1 where phone={1} and zhanhuiid={2}", WXNo, Mobile, ZhanhuiNo);
            

            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return "0";
            }
            else
            {
                return Convert.ToInt32(obj).ToString();
            }
        }

        /// <summary>
        /// 获取当前展会的某个微信号的报名部分信息 2017.11.20
        /// </summary>
        /// <param name="zhanhuiId"></param>
        /// <param name="weiXinNo"></param>
        /// <param name="fullname"></param>
        /// <param name="bm"></param>
        /// <param name="isgift"></param>
        /// <returns></returns>
        public int GetRestInfo(int zhanhuiId, string weiXinNo, ref string fullname, ref string bm, ref int isgift, ref int giftvalue, ref string phone)
        {
            int MID = 0;
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  zl.id, ");
            sbSql.Append("  zl.name, ");
            sbSql.Append("  zl.card, ");
            sbSql.Append("  zl.IsGift,zl.GiftValue,zl.phone ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian zl with(nolock) ");
            sbSql.Append("INNER JOIN WXMember wm with(nolock) ");
            sbSql.Append("  ON zl.vxmenberid=wm.id ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=" + zhanhuiId + " ");
            sbSql.Append("  AND wm.WXNo='" + weiXinNo + "' ");
            DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                MID = int.Parse(dt.Rows[0]["id"].ToString());
                fullname = dt.Rows[0]["name"].ToString();
                bm = dt.Rows[0]["card"].ToString();
                isgift = int.Parse(dt.Rows[0]["IsGift"].ToString());
                giftvalue = int.Parse(dt.Rows[0]["GiftValue"].ToString());
                phone = dt.Rows[0]["phone"].ToString();
            }
            return MID;
        }

        /// <summary>
        /// 领取礼品或报销     2017.11.20
        /// </summary>
        /// <param name="openid"></param>
        /// <param name="flag"></param>
        /// <param name="zhanhuiid"></param>
        /// <returns></returns>
        public string GoGift(string openid, int flag, int zhanhuiid)
        {
            string result;
            SqlParameter[] parameters = {
                        new SqlParameter("@msg",SqlDbType.VarChar,15),
                        new SqlParameter("@openid", openid),
                        new SqlParameter("@giftflag", flag),
                        new SqlParameter("@zhanhuiid",zhanhuiid)
            };
            parameters[0].Direction = ParameterDirection.Output;
            DbHelperSQL.RunProcedure("GoGift", parameters);
            result = (string)parameters[0].Value;
            return result;
        }

        public string AddTqhdSign(TqhdSign model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@OpenID", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@tqhdID", SqlDbType.Int),
                     };
                parameters[0].Value = model.OpenID;
                parameters[1].Value = model.tqhdID;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  TqhdSign(OpenID, ");
                sbSql.Append("  tqhdID)");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@OpenID, ");
                sbSql.Append("  @tqhdID) Select @@Identity");
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog("插入签到信息出错原因："+ex.ToString());
                return ex.Message;
            }
        }
        public string GoARState(string Openid, int zhanhuiid)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("update dbo.zhanhuiguanlian  set ARState='1',ARDatetime=GETDATE()  where WXNo='{0}' and zhanhuiid={1};Select @@Identity", Openid, zhanhuiid);


            object obj = DbHelperSQL.GetSingle(strSql.ToString());
            if (obj == null)
            {
                return "0";
            }
            else
            {
                return "领取成功";
            }
        }
        /// <summary>
        /// 获取该观众的领取证件的状态
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public DataTable GetARInfo(string weiXinNo, int zhanhuiId)
        {
            try
            {
                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("SELECT ");
                sbSql.Append("  ARState, ");
                sbSql.Append("  ARDatetime ");
                sbSql.Append("FROM ");
                sbSql.Append("  dbo.zhanhuiguanlian ");
                sbSql.Append(" where ");
                sbSql.AppendFormat("  WXNo='{0}'", weiXinNo.Trim());
                sbSql.AppendFormat(" and  zhanhuiid='{0}'", zhanhuiId);
                Utils.WriteLog("获取观众信息sql：" + sbSql.ToString());
                DataTable dt = DbHelperSQL.Query(sbSql.ToString()).Tables[0];
                return dt;
            }
            catch (Exception ex)
            {
                DataTable dt = new DataTable();
                Utils.WriteLog("获取展商信息错误详情：" + ex.ToString());
                return dt;
            }
        }
        /// <summary>
        /// 读取PhoneBasic表中的数据插入到数据库中
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int AddZhanHuiGuanLianByPhoneBasic(ZhanHuiGuanLianModel model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@vxmenberid", SqlDbType.Int),
                        new SqlParameter("@phone", SqlDbType.VarChar,20),
                        new SqlParameter("@name", SqlDbType.VarChar,20),
                        new SqlParameter("@card", SqlDbType.VarChar,100),
                        new SqlParameter("@cardimageurl", SqlDbType.VarChar,500),
                        new SqlParameter("@gift", SqlDbType.Int),
                        new SqlParameter("@tongbu", SqlDbType.Bit),
                        new SqlParameter("@MainBusine",SqlDbType.VarChar,100),
                        new SqlParameter("@ProType",SqlDbType.VarChar,500),
                        new SqlParameter("@IsGift",SqlDbType.Int),
                        new SqlParameter("@cjiname", SqlDbType.VarChar,100),
                        new SqlParameter("@job", SqlDbType.VarChar,500),
                        new SqlParameter("@ManageType", SqlDbType.VarChar,500),
                        new SqlParameter("@EnjoyProduct", SqlDbType.VarChar,500),
                        new SqlParameter("@zhanhuiid", SqlDbType.Int),
                        new SqlParameter("@WeiXinOpenId", SqlDbType.VarChar,500),
                        new SqlParameter("@LeadID", SqlDbType.Int)
                     };
                parameters[0].Value = model.vxmenberid;
                parameters[1].Value = model.phone;
                parameters[2].Value = model.name;
                parameters[3].Value = model.card;
                parameters[4].Value = model.cardimageurl;
                parameters[5].Value = model.gift;
                parameters[6].Value = model.shifoutb;
                parameters[7].Value = model.MainBusine;
                parameters[8].Value = model.IndustryOwend;  //所属行业
                parameters[9].Value = model.IsGift;
                parameters[10].Value = model.cjiname;
                parameters[11].Value = model.job;
                parameters[12].Value = model.ManageType;
                parameters[13].Value = model.EnjoyProduct;
                parameters[14].Value = model.zhanhuiid;
                parameters[15].Value = model.WeiXinOpenId;
                parameters[16].Value = model.LeadId;

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  zhanhuiguanlian(zhanhuiid,vxmenberid,phone, ");
                sbSql.Append("name, ");
                sbSql.Append("  card,cardimageurl,gift,shifoutb,MainBusine,ProType,IsZS,cardtype,IsGift,cjiname,job,ManageType,EnjoyProduct,WXNo,LeadId)");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@zhanhuiid,@vxmenberid,@phone, ");
                sbSql.Append(" @name, ");
                sbSql.Append("  @card,@cardimageurl,0,@tongbu,@MainBusine,@ProType,0,3,@IsGift,@cjiname,@job,@ManageType,@EnjoyProduct,@WeiXinOpenId,@LeadID) Select @@Identity");
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return 0;
                }
                else
                {
                    return Convert.ToInt32(obj);
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
