﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Utility;

namespace Yasn.Data
{
    public class PhoneValidateLog
    {
        /// <summary>
        /// 判断用户发来的验证码是否过期或者有效
        /// </summary>
        /// <param name="userPhone">用户手机</param>
        /// <param name="validateCode">验证码</param>
        /// <returns>0--正常，可修改密码，-2--验证码不可信,-1--验证码失效</returns>
        public int Exists(string userPhone, string validateCode)
        {
            int result;
            SqlParameter[] parameters = {
                        new SqlParameter("@status",SqlDbType.Int,4),
                        new SqlParameter("@phone", userPhone),
                        new SqlParameter("@validateCode",validateCode)
            };
            parameters[0].Direction = ParameterDirection.Output;
            DbHelperSQL.RunProcedure("PhoneValidateLog_Exists", parameters);
            result = (int)parameters[0].Value;
            return result;
        }

        public int IsPhoneBM(string userPhone, string validateCode)
        {
            int result;
            SqlParameter[] parameters = {
                        new SqlParameter("@status",SqlDbType.Int,4),
                        new SqlParameter("@phone", userPhone),
                        new SqlParameter("@validateCode",validateCode)
            };
            parameters[0].Direction = ParameterDirection.Output;
            DbHelperSQL.RunProcedure("IsPhoneBMLog_Exists", parameters);
            result = (int)parameters[0].Value;
            return result;
        }
        /// <summary>
        /// 添加发送日志
        /// </summary>
        /// <param name="model"></param>
        /// <returns>0--添加成功，-1为当天达到最大发送限制</returns>
        public int Add(string phone, string validateCode)
        {
            int result;
            SqlParameter[] parameters = {
                        new SqlParameter("@status",SqlDbType.Int,4),
                        new SqlParameter("@Phone", phone),
                        new SqlParameter("@ValidateCode",validateCode)
            };
            parameters[0].Direction = ParameterDirection.Output;
            DbHelperSQL.RunProcedure("PhoneValidateLog_ADD", parameters);
            result = (int)parameters[0].Value;
            return result;
        }
    }
}
