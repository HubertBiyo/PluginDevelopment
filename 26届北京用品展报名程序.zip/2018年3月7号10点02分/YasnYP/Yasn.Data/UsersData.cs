﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Framework;
using Yasn.Model;
using Yasn.Model.WechatClass;
using Yasn.Utility;

namespace Yasn.Data
{
    public partial class UsersData
    {


        public Users Login(string userName, string password)
        {
            var sqlTxt = string.Format("SELECT top 1  [Id],[Name],[Mobile],[Email],[UserStatus] FROM [dbo].[Users] where [Name] ='{0}' and [Password] ='{1}'", userName, password);

            Users stores = null;

            using (var reader = DbHelperSQL.ExecuteReader(sqlTxt))
            {
                while (reader.Read())
                {
                    stores = new Users
                    {
                        Id = int.Parse(reader["Id"].ToString()),
                        Name = reader["Name"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        Email = reader["Email"].ToString(),
                        UserStatus = int.Parse(reader["UserStatus"].ToString()),
                    };
                }
            }

            return stores;
        }

        public bool Exists(int Id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from Users");
            strSql.Append(" where ");
            strSql.Append(" Id = @Id  ");
            SqlParameter[] parameters = {
                    new SqlParameter("@Id", SqlDbType.Int,4)
            };
            parameters[0].Value = Id;

            return DbHelperSQL.Exists(strSql.ToString(), parameters);
        }
        /// <summary>
        /// 查询当天的要提醒用户名单
        /// </summary>
        /// <returns></returns>
        public DataSet GetWXTimer()
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXTimer ");
            sbSql.Append("WHERE ");
            sbSql.Append("  (txdatetime ");
            sbSql.Append("BETWEEN ");
            sbSql.Append("  @begindate ");
            sbSql.Append("  AND @enddate ) ");
            sbSql.Append("  AND shifoutx=0 ");

            SqlParameter[] parameters = {
                    new SqlParameter("@begindate", SqlDbType.DateTime),
                    new SqlParameter("@enddate", SqlDbType.DateTime)
            };
            parameters[0].Value = DateTime.Parse(DateTime.Now.ToShortDateString() + " 00:00:00");
            parameters[1].Value = DateTime.Parse(DateTime.Now.ToShortDateString() + " 23:59:59");

            return DbHelperSQL.Query(sbSql.ToString(), parameters);
        }

        /// <summary>
        /// 增加一条数据
        /// </summary>
        public int Add(Users model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("insert into Users(");
            strSql.Append("Name,Password,Mobile,Email,UserStatus,CreateId,CreateDate");
            strSql.Append(") values (");
            strSql.Append("@Name,@Password,@Mobile,@Email,@UserStatus,@CreateId,@CreateDate");
            strSql.Append(") ");
            strSql.Append(";select @@IDENTITY");
            SqlParameter[] parameters = {
                        new SqlParameter("@Name", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@Password", SqlDbType.NVarChar,100) ,
                        new SqlParameter("@GroupId", SqlDbType.Int,4) ,
                        new SqlParameter("@Mobile", SqlDbType.VarChar,20) ,
                        new SqlParameter("@Email", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@UserStatus", SqlDbType.Int,4) ,
                        new SqlParameter("@CreateId", SqlDbType.Int,4) ,
                        new SqlParameter("@CreateDate", SqlDbType.DateTime)

            };

            parameters[0].Value = model.Name;
            parameters[1].Value = model.Password;
            parameters[3].Value = model.Mobile;
            parameters[4].Value = model.Email;
            parameters[5].Value = model.UserStatus;
            parameters[6].Value = model.CreateId;
            parameters[7].Value = model.CreateDate;

            object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            if (obj == null)
            {
                return 0;
            }
            else
            {

                return Convert.ToInt32(obj);

            }
        }


        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Users model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update Users set ");

            strSql.Append(" Name = @Name , ");
            strSql.Append(" Password = @Password , ");
            strSql.Append(" Mobile = @Mobile , ");
            strSql.Append(" Email = @Email , ");
            strSql.Append(" UserStatus = @UserStatus");
            strSql.Append(" where Id=@Id ");

            SqlParameter[] parameters = {
                        new SqlParameter("@Id", SqlDbType.Int,4) ,
                        new SqlParameter("@Name", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@Password", SqlDbType.NVarChar,100) ,
                        new SqlParameter("@Mobile", SqlDbType.VarChar,20) ,
                        new SqlParameter("@Email", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@UserStatus", SqlDbType.Int,4)
            };

            parameters[0].Value = model.Id;
            parameters[1].Value = model.Name;
            parameters[2].Value = model.Password;
            parameters[3].Value = model.Mobile;
            parameters[4].Value = model.Email;
            parameters[5].Value = model.UserStatus;
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Update(int Id, int status)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("update Users set ");
            strSql.Append(" IsDel = @IsDel");
            strSql.Append(" where Id=@Id ");

            SqlParameter[] parameters = {
                        new SqlParameter("@Id", SqlDbType.Int,4) ,
                        new SqlParameter("@IsDel", SqlDbType.Int) ,
            };

            parameters[0].Value = Id;
            parameters[1].Value = status;
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 批量删除一批数据
        /// </summary>
        public bool DeleteList(string Idlist)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from Users ");
            strSql.Append(" where ID in (" + Idlist + ")  ");
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Users GetModel(int Id)
        {

            var sqlTxt = string.Format("select Id, Name,Password, Mobile, Email, UserStatus, CreateId, CreateDate   from Users   where Id={0}", Id);

            Users stores = null;

            using (var reader = DbHelperSQL.ExecuteReader(sqlTxt))
            {
                while (reader.Read())
                {
                    stores = new Users
                    {
                        Id = int.Parse(reader["Id"].ToString()),
                        Name = reader["Name"].ToString(),
                        Password = reader["Password"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        Email = reader["Email"].ToString(),
                        UserStatus = int.Parse(reader["UserStatus"].ToString()),
                        CreateId = reader["CreateId"].ToString().ConvertTo(0),
                        CreateDate = reader["CreateDate"].ToString().ConvertTo<DateTime>()
                    };
                }
            }

            return stores;
        }

        /// <summary>
        /// 得到对象实体
        /// </summary>
        public List<WXMember> GetModelList(int WXNo)
        {

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  [Id], ");
            sbSql.Append("  [UserName], ");
            sbSql.Append("  [Mobile], ");
            sbSql.Append("  [CompanyName], ");
            sbSql.Append("  [MemberNo], ");
            sbSql.Append("  [WXNo], ");
            sbSql.Append("  [CreateDate], ");
            sbSql.Append("  [Activity], ");
            sbSql.Append("  [ContactId], ");
            sbSql.Append("  [shifoudel], ");
            sbSql.Append("  [shifoutb] ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember WHERE  WXNo='" + WXNo + "'");


            WXMember stores = null;
            List<WXMember> modelList = new List<WXMember>();
            using (var reader = DbHelperSQL.ExecuteReader(sbSql.ToString()))
            {
                while (reader.Read())
                {
                    stores = new WXMember
                    {
                        Id = int.Parse(reader["Id"].ToString()),
                        UserName = reader["UserName"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        CompanyName = reader["CompanyName"].ToString(),
                        MemberNo = long.Parse(reader["MemberNo"].ToString()),
                        Activity = reader["Activity"].ToString(),
                        CreateDate = reader["CreateDate"].ToString().ConvertTo<DateTime>()
                    };

                    modelList.Add(stores);
                }
            }

            return modelList;
        }

        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" FROM Users ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 获得前几行数据
        /// </summary>
        public DataSet GetList(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" * ");
            strSql.Append(" FROM Users ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by " + filedOrder);
            return DbHelperSQL.Query(strSql.ToString());
        }



        public List<Users> GetList(int pageIdex, int pageSize, string sortKey, string sortMode, string keyWords, int groupId, out int totalCount)
        {
            string sqlTxt = string.Empty;
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrEmpty(keyWords))
            {
                sb.AppendFormat(" and Name like '%{0}%'", keyWords);
            }

            if (groupId > 0)
            {
                sb.AppendFormat(" and GroupId = {0}", groupId);
            }
            sqlTxt = string.Format(
           @"select * FROM [dbo].[Users] where 1=1 {0} order by {1} {2} offset {3} row fetch next {4} rows only;
                                            SELECT count(1) FROM [dbo].[Users] ", sb.ToString(), sortKey, sortMode, (pageIdex - 1) * pageSize, pageSize);

            List<Users> list = null;

            using (var reader = DbHelperSQL.ExecuteReader(sqlTxt))
            {
                list = new List<Users>();
                while (reader.Read())
                {
                    list.Add(new Users()
                    {
                        Id = reader["Id"].ToString().ConvertTo(0),
                        Name = reader["Name"].ToString(),
                        Password = reader["Password"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        Email = reader["Email"].ToString(),
                        UserStatus = reader["UserStatus"].ToString().ConvertTo(0),
                        CreateId = reader["CreateId"].ToString().ConvertTo<int>(0),
                        CreateDate = reader["CreateDate"].ToString().ConvertTo<DateTime>(),
                        IsDel = reader["IsDel"].ToString().ConvertTo<bool>()
                        //LastLogInDate = reader["LastLogInDate"].ToString().ConvertTo<DateTime>()
                    });
                }
                totalCount = (reader.NextResult() && reader.Read()) ? int.Parse(reader[0].ToString()) : 0;
            }
            return list;
        }

        public bool UpdateList(string Sortlist, int status)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update Users ");
            strSql.Append("set IsDel=@IsDel");
            strSql.Append(" where ID in (" + Sortlist + ")  ");
            SqlParameter[] parameters = {
                        new SqlParameter("@IsDel", SqlDbType.Int)
            };
            parameters[0].Value = status;
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool GetIsExsitName(string userName, int userId)
        {
            const string sqlTxt = "select * from Users  where Name=@Name and Id != @Id";


            SqlParameter[] paras =
            {
                new SqlParameter("@Name",userName),
                new SqlParameter("@Id",userId)
            };

            using (var reader = DbHelperSQL.ExecuteReader(sqlTxt, paras))
            {
                return reader.HasRows;
            }
        }
    }
}
