﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Model;
using Yasn.Model.WechatClass;
using Yasn.Utility;

namespace Yasn.Data
{
    //WXMember
    public partial class WXMemberData
    {


        /// <summary>
        /// 获得前几行数据

        /// </summary>
        public List<WXMember> GetList(int pageIdex, int pageSize, string keyWord, out int totalCount)
        {
            var con = "";


            if (!string.IsNullOrEmpty(keyWord))
            {
                con += string.Format(" and UserName like '%{0}%' ", keyWord);
            }

            string sqlTxt = string.Format(
                @"select * FROM [dbo].[WXMember] where 1=1  {2} order by Id desc offset {0} row fetch next {1} rows only;
                                            SELECT count(1) FROM [dbo].[WXMember] where 1=1 {2} ",
                (pageIdex - 1) * pageSize, pageSize, con);

            List<WXMember> list;

            using (var reader = DbHelperSQL.ExecuteReader(sqlTxt))
            {
                list = new List<WXMember>();
                while (reader.Read())
                {
                    var info = new WXMember
                    {
                        Id = int.Parse(reader["Id"].ToString()),
                        UserName = reader["UserName"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        WXNo = reader["WXNo"].ToString(),
                        CreateDate = DateTime.Parse(reader["CreateDate"].ToString()),
                        MemberNo = Convert.ToInt64(reader["MemberNo"].ToString()),
                    };
                    list.Add(info);
                }
                totalCount = (reader.NextResult() && reader.Read()) ? int.Parse(reader[0].ToString()) : 0;
            }
            return list;
        }

        public long GetMaxMemberNo()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Max(MemberNo) from WXMember");

            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return 0;

            return Convert.ToInt64(obj.ToString());
        }
        public long GetFoodMaxMemberNo()
        {
            ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Max(MemberNo) from WXMember");

            object obj = DbHelperSQL.GetSingle(strSql.ToString());

            if (obj == null)
                return 0;

            return Convert.ToInt64(obj.ToString());
        }

        public bool ExistsWxNo(string wxNo)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from WXMember");
            strSql.Append(" where WXNo=@WxNo");

            SqlParameter[] parameters = {
                new SqlParameter("@WxNo",wxNo)
            };

            return DbHelperSQL.Exists(strSql.ToString(), parameters);
        }

        public bool ExistsMobile(string mobile)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(1) from WXMember");
            strSql.Append(" where Mobile=@Mobile");

            SqlParameter[] parameters = {
                new SqlParameter("@Mobile",mobile)
            };

            return DbHelperSQL.Exists(strSql.ToString(), parameters);
        }
        /// <summary>
        /// 展会报销
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddBiaoXiao(ZhanHuiBiaoXiaoModel model)
        {
            try
            {
                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  zhanhuibx(WXNo, ");
                sbSql.Append("  zhanhuiid, ");
                sbSql.Append("  name, ");
                sbSql.Append("  mobil, ");
                sbSql.Append("  bxbm, ");
                sbSql.Append("  createdatetime) ");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@WXNo, ");
                sbSql.Append("  @zhanhuiid, ");
                sbSql.Append("  @name, ");
                sbSql.Append("  @mobil, ");
                sbSql.Append("  @bxbm, ");
                sbSql.Append("  @createdatetime) ");
                sbSql.Append(" Select @@Identity");

                SqlParameter[] parameters = {
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,100) ,
                        new SqlParameter("@zhanhuiid", SqlDbType.Int) ,
                        new SqlParameter("@name", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@mobil", SqlDbType.NVarChar,100),
                        new SqlParameter("@bxbm",SqlDbType.NVarChar,50),
                        new SqlParameter("@createdatetime",SqlDbType.DateTime)
            };

                parameters[0].Value = model.WXNo;
                parameters[1].Value = model.zhanhuiid;
                parameters[2].Value = model.name;
                parameters[3].Value = model.mobil;
                parameters[4].Value = model.bxbm;
                parameters[5].Value = model.createdatetime;

                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);

                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// 增加一条数据

        /// </summary>
        public string Add(WXMember model)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into WXMember(");
                strSql.Append("UserName,Mobile,WXNo,MemberNo,CompanyName");
                strSql.Append(") values (");
                strSql.Append("@UserName,@Mobile,@WXNo,@MemberNo,@CompanyName");
                strSql.Append(") Select @@Identity");

                SqlParameter[] parameters = {
                        new SqlParameter("@UserName", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@MemberNo", SqlDbType.BigInt),
                        new SqlParameter("@CompanyName",SqlDbType.NVarChar,50)
            };

                parameters[0].Value = model.UserName;
                parameters[1].Value = model.Mobile;
                parameters[2].Value = model.WXNo;
                parameters[3].Value = model.MemberNo;
                parameters[4].Value = model.CompanyName;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 查找用户报名同期活动时是否已经注册
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public bool GetActiveSF(string mobile, string zhanhuiid)
        {

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  COUNT(1) ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian ");
            sbSql.Append("INNER JOIN WXMember ");
            sbSql.Append("  ON WXMember.Id=zhanhuiguanlian.vxmenberid ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=@zhanhuiid ");
            sbSql.Append("  AND Mobile=@Mobile ");

            SqlParameter[] parameters = {
                new SqlParameter("@zhanhuiid",zhanhuiid),
                new SqlParameter("@Mobile",mobile)
            };

            return DbHelperSQL.Exists(sbSql.ToString(), parameters);
        }
        /// <summary>
        /// 查找用户是否申请报销
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public bool GetBiaoXiao(string wxno, string zhanhuiid)
        {

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  COUNT(1) ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuibx ");
            sbSql.Append("INNER JOIN zhanhui ");
            sbSql.Append("  ON zhanhui.ID=zhanhuibx.zhanhuiid ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuibx.WXNO=@WXNO ");
            sbSql.Append("  AND zhanhuibx.zhanhuiid=@zhanhuiid ");

            SqlParameter[] parameters = {
                new SqlParameter("@zhanhuiid",zhanhuiid),
                new SqlParameter("@WXNO",wxno)
            };

            return DbHelperSQL.Exists(sbSql.ToString(), parameters);
        }

        /// <summary>
        /// 获得默认展会信息
        /// </summary>
        public DataSet GetActiveList(int wmid, int zhanhuiid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  ISNULL(tqhd, ");
            sbSql.Append("  '') AS tqhd ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid='" + zhanhuiid + "' ");
            sbSql.Append("  AND vxmenberid='" + wmid + "' ");

            DataSet tempDs = DbHelperSQL.Query(sbSql.ToString());

            if (tempDs == null || tempDs.Tables.Count == 0)
            {
                return null;
            }
            if (tempDs.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            string activeStr = tempDs.Tables[0].Rows[0]["tqhd"].ToString();
            if (string.IsNullOrEmpty(activeStr))
                return null;

            activeStr = "-1" + activeStr;
            sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  ActiveList ");
            sbSql.Append("WHERE ");
            sbSql.Append("  tqhdbh ");
            sbSql.Append("IN ");
            sbSql.Append("  (" + activeStr + ") ");
            sbSql.Append("  AND zhid='" + zhanhuiid + "' ");
            sbSql.Append("  AND statecode=0 ");
            sbSql.Append("ORDER BY ");
            sbSql.Append("  id ");
            //writeLogToFile("参加的同期活动SQL: " + sbSql.ToString());
            DataSet tempActiveDS = DbHelperSQL.Query(sbSql.ToString());
            if (tempActiveDS == null || tempActiveDS.Tables.Count == 0)
            {
                return null;
            }
            if (tempActiveDS.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            return tempActiveDS;
        }
        /// <summary>
        /// 更新同期活动
        /// </summary>
        public bool UpdateTQHD(string mibile, string tqhd, int zhanhuiid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("UPDATE ");
            sbSql.Append("  zhanhuiguanlian ");
            sbSql.Append("SET ");
            sbSql.Append("  tqhd= '" + tqhd + "' ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=" + zhanhuiid);
            sbSql.Append("  AND vxmenberid=( ");
            sbSql.Append("SELECT ");
            sbSql.Append("  TOP 1 Id ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember ");
            sbSql.Append("WHERE ");
            sbSql.Append("  Mobile='" + mibile + "') ");

            writeLogToFile(sbSql.ToString());
            //SqlParameter[] parameters = {           
            //            new SqlParameter("@Mobile", SqlDbType.NVarChar,50) ,            
            //            new SqlParameter("@tqhd", SqlDbType.NVarChar,50) ,            
            //            new SqlParameter("@zhanhuiid", SqlDbType.Int)            

            //};

            //parameters[0].Value = mibile;
            //parameters[1].Value = tqhd;
            //parameters[2].Value = zhanhuiid;

            int rows = DbHelperSQL.ExecuteSql(sbSql.ToString());
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 增加一条数据

        /// </summary>
        public string AddFood(WXMember model)
        {
            try
            {
                ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;

                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into WXMember(");
                strSql.Append("UserName,Mobile,WXNo,MemberNo,CompanyName");
                strSql.Append(") values (");
                strSql.Append("@UserName,@Mobile,@WXNo,@MemberNo,@CompanyName");
                strSql.Append(");Select @@Identity;");

                SqlParameter[] parameters = {
                        new SqlParameter("@UserName", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@MemberNo", SqlDbType.BigInt),
                        new SqlParameter("@CompanyName",SqlDbType.NVarChar,50)
            };

                parameters[0].Value = model.UserName;
                parameters[1].Value = model.Mobile;
                parameters[2].Value = model.WXNo;
                parameters[3].Value = model.MemberNo;
                parameters[4].Value = model.CompanyName;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                if (obj == null)
                {
                    return "0";
                }
                else
                {
                    return Convert.ToInt32(obj).ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 更新一条数据

        /// </summary>
        public bool Update(WXMember model)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update WXMember set ");

            strSql.Append(" Id = @Id , ");
            strSql.Append(" UserName = @UserName , ");
            strSql.Append(" Mobile = @Mobile , ");
            strSql.Append(" WXNo = @WXNo , ");
            strSql.Append(" CreateDate = @CreateDate , ");
            strSql.Append(" MemberNo = @MemberNo  ");
            strSql.Append(" where  ");

            SqlParameter[] parameters = {
                        new SqlParameter("@Id", SqlDbType.Int,4) ,
                        new SqlParameter("@UserName", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@Mobile", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@WXNo", SqlDbType.NVarChar,50) ,
                        new SqlParameter("@CreateDate", SqlDbType.DateTime) ,
                        new SqlParameter("@MemberNo", SqlDbType.NVarChar,50)

            };

            parameters[0].Value = model.Id;
            parameters[1].Value = model.UserName;
            parameters[2].Value = model.Mobile;
            parameters[3].Value = model.WXNo;
            parameters[4].Value = model.CreateDate;
            parameters[5].Value = model.MemberNo;
            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 删除一条数据

        /// </summary>
        public bool Delete(int id)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from WXMember ");
            strSql.Append(" where id=@Id");
            SqlParameter[] parameters = {
                new SqlParameter("@Id",id)
            };


            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 得到一个对象实体

        /// </summary>
        public WXMember GetModel(string wxNo)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Id, UserName, Mobile, WXNo, CreateDate, MemberNo");
            strSql.Append("  from WXMember ");
            strSql.Append(" where WXNo = @WXNo");
            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",wxNo)
            };


            WXMember model = null;
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                model = new WXMember();
                if (ds.Tables[0].Rows[0]["Id"].ToString() != "")
                {
                    model.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
                }
                model.UserName = ds.Tables[0].Rows[0]["UserName"].ToString();
                model.Mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                model.WXNo = ds.Tables[0].Rows[0]["WXNo"].ToString();
                if (ds.Tables[0].Rows[0]["CreateDate"].ToString() != "")
                {
                    model.CreateDate = DateTime.Parse(ds.Tables[0].Rows[0]["CreateDate"].ToString());
                }
                model.MemberNo = Convert.ToInt64(ds.Tables[0].Rows[0]["MemberNo"].ToString());

                return model;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 得到一个对象实体

        /// </summary>
        public WXMember GetModelByPhone(string phone)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Id, UserName, Mobile, WXNo, CreateDate, MemberNo");
            strSql.Append("  from WXMember ");
            strSql.Append(" where Mobile ='" + phone + "'");

            //writeLogToFile("执行查询操作SQL：" + strSql.ToString());
            WXMember model = null;
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), null);

            //writeLogToFile("执行查询操作：" + ds.Tables.Count);
            if (ds.Tables[0].Rows.Count > 0)
            {
                model = new WXMember();
                if (ds.Tables[0].Rows[0]["Id"].ToString() != "")
                {
                    model.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
                }
                model.UserName = ds.Tables[0].Rows[0]["UserName"].ToString();
                model.Mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                model.WXNo = ds.Tables[0].Rows[0]["WXNo"].ToString();
                if (ds.Tables[0].Rows[0]["CreateDate"].ToString() != "")
                {
                    model.CreateDate = DateTime.Parse(ds.Tables[0].Rows[0]["CreateDate"].ToString());
                }
                model.MemberNo = Convert.ToInt64(ds.Tables[0].Rows[0]["MemberNo"].ToString());

                return model;
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 得到一个对象实体

        /// </summary>
        public WXMember GetFoodModelByPhone(string phone)
        {
            ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select Id, UserName, Mobile, WXNo, CreateDate, MemberNo");
            strSql.Append("  from WXMember ");
            strSql.Append(" where Mobile ='" + phone + "'");

            writeLogToFile("执行查询操作SQL：" + strSql.ToString());
            WXMember model = null;
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), null);

            writeLogToFile("执行查询操作：" + ds.Tables.Count);
            if (ds.Tables[0].Rows.Count > 0)
            {
                model = new WXMember();
                if (ds.Tables[0].Rows[0]["Id"].ToString() != "")
                {
                    model.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
                }
                model.UserName = ds.Tables[0].Rows[0]["UserName"].ToString();
                model.Mobile = ds.Tables[0].Rows[0]["Mobile"].ToString();
                model.WXNo = ds.Tables[0].Rows[0]["WXNo"].ToString();
                if (ds.Tables[0].Rows[0]["CreateDate"].ToString() != "")
                {
                    model.CreateDate = DateTime.Parse(ds.Tables[0].Rows[0]["CreateDate"].ToString());
                }
                model.MemberNo = Convert.ToInt64(ds.Tables[0].Rows[0]["MemberNo"].ToString());

                return model;
            }
            else
            {
                return null;
            }
        }

        /// 往日志文件中追加信息

        /// </summary>
        /// <param name="logInfo"></param>
        private void writeLogToFile(string strMemo)
        {
            if (!Directory.Exists(@"d:\logs\"))
            {
                Directory.CreateDirectory((@"d:\logs\"));
            }
            string filename = @"d:\logs\log.txt";
            StreamWriter sr = null;
            try
            {
                if (!System.IO.File.Exists(filename))
                {
                    sr = System.IO.File.CreateText(filename);
                }
                else
                {
                    sr = System.IO.File.AppendText(filename);
                }
                sr.WriteLine(strMemo);
            }
            catch
            {

            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                }
            }
        }


        /// <summary>
        /// 增加一条数据

        /// </summary>
        public string Add(ZhanHuiGuanLianModel model)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@zhanhuiid", SqlDbType.Int) ,
                        new SqlParameter("@vxmenberid", SqlDbType.Int)
                     };

                parameters[0].Value = model.zhanhuiid;
                parameters[1].Value = model.vxmenberid;

                //判断展会和用户ID为条件记录是否存在，如果存在不进行添加

                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("SELECT ");
                sbSql.Append("  COUNT(1) ");
                sbSql.Append("FROM ");
                sbSql.Append("  zhanhuiguanlian ");
                sbSql.Append("WHERE ");
                sbSql.Append("  zhanhuiid='" + model.zhanhuiid + "'");
                sbSql.Append("  AND vxmenberid='" + model.vxmenberid + "' ");

                //writeLogToFile("查询展会关联表:" + sbSql.ToString());
                if (!DbHelperSQL.Exists(sbSql.ToString(), parameters))
                {
                    sbSql = new StringBuilder();
                    sbSql.Append("INSERT INTO ");
                    sbSql.Append("  zhanhuiguanlian(zhanhuiid, ");
                    sbSql.Append("  vxmenberid) ");
                    sbSql.Append("VALUES ");
                    sbSql.Append("  (@zhanhuiid, ");
                    sbSql.Append("  @vxmenberid) ");


                    DbHelperSQL.ExecuteSql(sbSql.ToString(), parameters);
                }

                return "OK";

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 增加一条数据

        /// </summary>
        public string AddFood(ZhanHuiGuanLianModel model)
        {
            try
            {
                ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;

                SqlParameter[] parameters = {
                        new SqlParameter("@zhanhuiid", SqlDbType.Int) ,
                        new SqlParameter("@vxmenberid", SqlDbType.Int)
                     };

                parameters[0].Value = model.zhanhuiid;
                parameters[1].Value = model.vxmenberid;

                ////判断展会和用户ID为条件记录是否存在，如果存在不进行添加

                //StringBuilder sbSql = new StringBuilder();
                //sbSql.Append("SELECT ");
                //sbSql.Append("  * ");
                //sbSql.Append("FROM ");
                //sbSql.Append("  zhanhuiguanlian ");
                //sbSql.Append("WHERE ");
                //sbSql.Append("  zhanhuiid=@zhanhuiid");
                //sbSql.Append("  AND vxmenberid=@vxmenberid ");

                //DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

                //if (ds == null || ds.Tables[0].Rows.Count == 0)
                //{
                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  zhanhuiguanlian(zhanhuiid, ");
                sbSql.Append("  vxmenberid) ");
                sbSql.Append("VALUES ");
                sbSql.Append("  (@zhanhuiid, ");
                sbSql.Append("  @vxmenberid) ");


                DbHelperSQL.ExecuteSql(sbSql.ToString(), parameters);
                //}
                return "OK";

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public List<WXMember> GetModelList(string wxNo)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id, ");
            sbSql.Append("  UserName, ");
            sbSql.Append("  Mobile, ");
            sbSql.Append("  WXNo, ");
            sbSql.Append("  CreateDate, ");
            sbSql.Append("  MemberNo ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember ");
            sbSql.Append("INNER JOIN zhanhuiguanlian ");
            sbSql.Append("  ON zhanhuiguanlian.vxmenberid=WXMember.Id ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=(SELECT top 1 id ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhui ");
            sbSql.Append("WHERE ");
            sbSql.Append("  shifoudangqianzh=1) ");
            sbSql.Append("  AND  WXNo = @WXNo ");

            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",wxNo)
            };


            WXMember model = null;
            List<WXMember> modeList = new List<WXMember>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new WXMember();
                    if (row["Id"].ToString() != "")
                    {
                        model.Id = int.Parse(row["Id"].ToString());
                    }
                    model.UserName = row["UserName"].ToString();
                    model.Mobile = row["Mobile"].ToString();
                    model.WXNo = row["WXNo"].ToString();
                    if (row["CreateDate"].ToString() != "")
                    {
                        model.CreateDate = DateTime.Parse(row["CreateDate"].ToString());
                    }
                    model.MemberNo = Convert.ToInt64(row["MemberNo"].ToString());
                    //model.Activity = row["Activity"].ToString();
                    //model.ContactId = row["ContactId"].ToString();

                    modeList.Add(model);
                }

            }

            return modeList;
        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public List<WXMember> GetModelList(string wxNo, string zhanhuiid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id, ");
            sbSql.Append("  UserName, ");
            sbSql.Append("  Mobile, ");
            sbSql.Append("  WXNo, ");
            sbSql.Append("  CreateDate, ");
            sbSql.Append("  MemberNo, ");
            sbSql.Append("  card, ");
            sbSql.Append("  cardimageurl, ");
            sbSql.Append("  cardtype ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember ");
            sbSql.Append("INNER JOIN zhanhuiguanlian ");
            sbSql.Append("  ON zhanhuiguanlian.vxmenberid=WXMember.Id ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=@zhanhuiid ");
            sbSql.Append("  AND  WXNo = @WXNo ");

            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",wxNo),
                new SqlParameter("@zhanhuiid",zhanhuiid)
            };


            WXMember model = null;
            List<WXMember> modeList = new List<WXMember>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new WXMember();
                    if (row["Id"].ToString() != "")
                    {
                        model.Id = int.Parse(row["Id"].ToString());
                    }
                    model.UserName = row["UserName"].ToString();
                    model.Mobile = row["Mobile"].ToString();
                    model.WXNo = row["WXNo"].ToString();
                    model.card = row["card"].ToString();
                    model.cardimageurl = row["cardimageurl"].ToString();
                    model.cardtype = row["cardtype"].ToString();
                    if (row["CreateDate"].ToString() != "")
                    {
                        model.CreateDate = DateTime.Parse(row["CreateDate"].ToString());
                    }
                    model.MemberNo = Convert.ToInt64(row["MemberNo"].ToString());
                    //model.Activity = row["Activity"].ToString();
                    //model.ContactId = row["ContactId"].ToString();

                    modeList.Add(model);
                }

            }

            return modeList;
        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public DataSet GetModelBiaoXiaoList(string wxNo, string zhanhuiid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  zhanhuibx.* ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuibx ");
            //sbSql.Append("INNER JOIN zhanhui ");
            //sbSql.Append("  ON zhanhui.ID=zhanhuibx.zhanhuiid ");
            sbSql.Append("WHERE ");
            sbSql.Append("  WXNO=@wxNo ");
            sbSql.Append("  AND zhanhuiid=@zhanhuiid ");

            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",wxNo),
                new SqlParameter("@zhanhuiid",zhanhuiid)
            };

            //writeLogToFile("sbSql--申请补贴：" + sbSql.ToString());

            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            return ds;

        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public List<WXMember> GetFoodModelList(string wxNo)
        {
            ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id, ");
            sbSql.Append("  UserName, ");
            sbSql.Append("  Mobile, ");
            sbSql.Append("  WXNo, ");
            sbSql.Append("  CreateDate, ");
            sbSql.Append("  MemberNo ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember ");
            sbSql.Append("INNER JOIN zhanhuiguanlian ");
            sbSql.Append("  ON zhanhuiguanlian.vxmenberid=WXMember.Id ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=(SELECT top 1 id ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhui ");
            sbSql.Append("WHERE ");
            sbSql.Append("  shifoudangqianzh=1) ");
            sbSql.Append("  AND  WXNo = @WXNo ");

            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",wxNo)
            };


            WXMember model = null;
            List<WXMember> modeList = new List<WXMember>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);

            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    model = new WXMember();
                    if (row["Id"].ToString() != "")
                    {
                        model.Id = int.Parse(row["Id"].ToString());
                    }
                    model.UserName = row["UserName"].ToString();
                    model.Mobile = row["Mobile"].ToString();
                    model.WXNo = row["WXNo"].ToString();
                    if (row["CreateDate"].ToString() != "")
                    {
                        model.CreateDate = DateTime.Parse(row["CreateDate"].ToString());
                    }
                    model.MemberNo = Convert.ToInt64(row["MemberNo"].ToString());
                    //model.Activity = row["Activity"].ToString();
                    //model.ContactId = row["ContactId"].ToString();

                    modeList.Add(model);
                }

            }

            return modeList;
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select * ");
            strSql.Append(" FROM WXMember ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            return DbHelperSQL.Query(strSql.ToString());
        }
        /// <summary>
        /// 获得默认展会信息
        /// </summary>
        public DataSet GetZhanHui()
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhui ");
            sbSql.Append("WHERE ");
            sbSql.Append("  shifoudangqianzh=1 ");
            return DbHelperSQL.Query(sbSql.ToString());
        }
        /// <summary>
        /// 获取同期活动列表
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public DataSet GetActiveList(int zhid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  ActiveList ");
            sbSql.Append("WHERE ");
            sbSql.Append("  statecode=0 ");
            sbSql.Append("  AND zhid=@zhid ");
            SqlParameter[] parameters = {
                new SqlParameter("@zhid",zhid)
            };

            return DbHelperSQL.Query(sbSql.ToString(), parameters);
        }
        /// <summary>
        /// 获得默认展会信息
        /// </summary>
        public DataSet GetZhanHuiFood()
        {
            ////DbHelperSQL.connectionString = ConfigurationManager.ConnectionStrings["ConnectionFoodString"].ConnectionString;

            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhui ");
            sbSql.Append("WHERE ");
            sbSql.Append("  shifoudangqianzh=1 ");
            return DbHelperSQL.Query(sbSql.ToString());
        }

        /// <summary>
        /// 获得前几行数据

        /// </summary>
        public DataSet GetList(int Top, string strWhere, string filedOrder)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" * ");
            strSql.Append(" FROM WXMember ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by " + filedOrder);
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// 插入时间表

        /// </summary>
        public void GetSp_WXTimer(string touser)
        {

            SqlParameter[] parameters = {
                new SqlParameter("@touser",touser)
            };
            DbHelperSQL.RunProcedure("sp_WXTimer", parameters);
        }
        public List<WXMember> GetYPModelList(string phone)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id, ");
            sbSql.Append("  WXMember.UserName, ");
            sbSql.Append("  zhanhuiguanlian.Phone, ");
            sbSql.Append("  WXNo,zhanhuiguanlian.id as VipId, ");
            sbSql.Append("  CreateDate, ");
            sbSql.Append("  MemberNo ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember with(nolock) ");
            sbSql.Append("INNER JOIN zhanhuiguanlian with(nolock) ");
            sbSql.Append("  ON zhanhuiguanlian.vxmenberid=WXMember.Id ");
            sbSql.Append("WHERE ");
            sbSql.Append("  zhanhuiid=(SELECT top 1 id ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhui with(nolock) ");
            sbSql.Append("WHERE ");
            sbSql.Append("  shifoudangqianzh=1) ");
            sbSql.Append("  AND  zhanhuiguanlian.phone = @phone ");

            SqlParameter[] parameters = {
                new SqlParameter("@phone",phone)
            };
            List<WXMember> modeList = new List<WXMember>();

            using (IDataReader dataReader = DbHelperSQL.ExecuteReader(sbSql.ToString(), parameters))
            {
                while (dataReader.Read())
                {
                    modeList.Add(ReaderBind(dataReader));
                }
            }
            return modeList;
        }

        public List<WXMember> GetYPModelList(string phone, int zhanhuiId)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id, ");
            sbSql.Append("  WXMember.UserName, ");
            sbSql.Append("  zhanhuiguanlian.Phone, ");
            sbSql.Append("  zhanhuiguanlian.WXNo,zhanhuiguanlian.id as VipId, ");
            sbSql.Append("  CreateDate, ");
            sbSql.Append("  MemberNo ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember with(nolock) ");
            sbSql.Append("INNER JOIN zhanhuiguanlian with(nolock) ");
            sbSql.Append("  ON zhanhuiguanlian.vxmenberid=WXMember.Id AND ");
            sbSql.AppendFormat("  zhanhuiid={0} ", zhanhuiId);
            //sbSql.Append("WHERE ");
            //sbSql.AppendFormat("  zhanhuiid={0} ", zhanhuiId);
            sbSql.Append("  AND  zhanhuiguanlian.phone = @phone ");

            SqlParameter[] parameters = {
                new SqlParameter("@phone",phone)
            };
            List<WXMember> modeList = new List<WXMember>();

            using (IDataReader dataReader = DbHelperSQL.ExecuteReader(sbSql.ToString(), parameters))
            {
                while (dataReader.Read())
                {
                    modeList.Add(ReaderBind(dataReader));
                }
            }
            return modeList;
        }

        public int GetMemberModelList(string WXNo)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  WXMember.Id ");
            sbSql.Append("FROM ");
            sbSql.Append("  WXMember with(nolock) ");
            sbSql.Append("  where WXNo=@WXNo ");

            SqlParameter[] parameters = {
                new SqlParameter("@WXNo",WXNo)
            };
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(ds.Tables[0].Rows[0]["ID"].ToString());
                }
                return 0;
            }
            return 0;
        }
        private WXMember ReaderBind(IDataReader dataReader)
        {
            Yasn.Model.WechatClass.WXMember model = new Yasn.Model.WechatClass.WXMember();
            DataTable dt = dataReader.GetSchemaTable();
            object ojb;
            if (dt.Select("ColumnName='Id'").LongLength > 0)
            {
                ojb = dataReader["Id"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.Id = (int)ojb;
                }
            }
            model.UserName = dt.Select("ColumnName='UserName'").LongLength > 0 ? dataReader["UserName"].ToString() : string.Empty;
            model.Mobile = dt.Select("ColumnName='Phone'").LongLength > 0 ? dataReader["Phone"].ToString() : string.Empty;
            model.WXNo = dt.Select("ColumnName='WXNo'").LongLength > 0 ? dataReader["WXNo"].ToString() : string.Empty;
            if (dt.Select("ColumnName='CreateDate'").LongLength > 0)
            {
                ojb = dataReader["CreateDate"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.CreateDate = (DateTime)(ojb);
                }
            }
            if (dt.Select("ColumnName='MemberNo'").LongLength > 0)
            {
                ojb = dataReader["MemberNo"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.MemberNo = (long)ojb;
                }
            }
            if (dt.Select("ColumnName='VipId'").LongLength > 0)
            {
                ojb = dataReader["VipId"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.Zhanhuiguanlian_ID = (int)ojb;
                }
            }
            return model;
        }

        public int InsertWechatXML(ExmlMsg WechatXML, string ReturnContent)
        {
            try
            {
                SqlParameter[] parameters = {
                        new SqlParameter("@MsgId", SqlDbType.Int) ,
                        new SqlParameter("@ToUserName", SqlDbType.VarChar),
                        new SqlParameter("@FromUserName", SqlDbType.VarChar),
                        new SqlParameter("@CreateTime", SqlDbType.DateTime),
                        new SqlParameter("@MsgType", SqlDbType.VarChar),
                        new SqlParameter("@Content", SqlDbType.VarChar),
                        new SqlParameter("@ReturnContent", SqlDbType.VarChar)
                     };

                parameters[0].Value = WechatXML.MsgId;
                parameters[1].Value = WechatXML.ToUserName;
                parameters[2].Value = WechatXML.FromUserName;
                parameters[3].Value = ConvertUnixToDateTime(WechatXML.CreateTime);
                parameters[4].Value = WechatXML.MsgType;
                parameters[5].Value = WechatXML.Content;
                parameters[6].Value = ReturnContent;


                StringBuilder sbSql = new StringBuilder();
                sbSql.Append("INSERT INTO ");
                sbSql.Append("  wechatxml( MsgId, ");
                sbSql.Append("  ToUserName,FromUserName,CreateTime,MsgType,Content,ReturnContent) ");
                sbSql.Append("VALUES ");
                sbSql.Append("  ( @MsgId, ");
                sbSql.Append("  @ToUserName, ");
                sbSql.Append("  @FromUserName, ");
                sbSql.Append("  @CreateTime, ");
                sbSql.Append("  @MsgType, ");
                sbSql.Append("  @Content, ");
                sbSql.Append("  @ReturnContent);Select @@Identity; ");
                Utils.WriteLog("执行的sql语句： --" + sbSql.ToString() + "  " + DateTime.Now.ToString());
                object obj = DbHelperSQL.GetSingle(sbSql.ToString(), parameters);
                if (obj == null)
                {
                    return 0;
                }
                else
                {
                    return Convert.ToInt32(obj);
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog("执行的sql语句： --" + ex.ToString() + "  " + DateTime.Now.ToString());
                return 0;
            }
        }
        /// <summary>
        /// 时间戳转换为datetime
        /// </summary>
        /// <param name="unix"></param>
        /// <returns></returns>
        public static DateTime ConvertUnixToDateTime(string unix)
        {
            DateTime startUnixTime = System.TimeZoneInfo.ConvertTime(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc), TimeZoneInfo.Local);
            return startUnixTime.AddSeconds(double.Parse(unix));
        }
        /// <summary>
        /// 根据用户发送的消息回复相应的信息
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public string GetUserName(string Phone)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT top 1 ");
            sbSql.Append("  vercode ");
            sbSql.Append("FROM ");
            sbSql.Append("  dbo.VerCodeExprise WITH(NOLOCK) ");
            sbSql.Append("WHERE ");
            sbSql.Append("  phone=@Phone ");
            sbSql.Append("  AND ExpriseDate>GETDATE() order by id DESC ");

            SqlParameter[] parameters = {
                new SqlParameter("@Phone",Phone)
            };
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    return ds.Tables[0].Rows[0]["vercode"].ToString();
                }
                return "";
            }
            return "";
        }

    }
}
