﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Model;
using Yasn.Utility;

namespace Yasn.Data
{
    public class ZhanhuiguanlianData
    {
        public ZhanHuiGuanLianModel GetYPModel(int zhglid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian with(nolock) ");
            sbSql.Append("WHERE ");
            sbSql.Append("  id=@id ");

            SqlParameter[] parameters = {
                new SqlParameter("@id",zhglid)
            };
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);
            ZhanHuiGuanLianModel model = null;
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = ds.Tables[0].Rows[0];
                model = new ZhanHuiGuanLianModel();
                if (row["Id"].ToString() != "")
                {
                    model.Id = int.Parse(row["Id"].ToString());
                }
                if (row["zhanhuiid"].ToString() != "")
                {
                    model.zhanhuiid = int.Parse(row["zhanhuiid"].ToString());
                }
                if (row["vxmenberid"].ToString() != "")
                {
                    model.vxmenberid = int.Parse(row["vxmenberid"].ToString());
                }
                model.ContactId = row["ContactId"].ToString();
                if (row["shifoutb"].ToString() != "")
                {
                    model.shifoutb = bool.Parse(row["shifoutb"].ToString());
                }
                else
                {
                    model.shifoutb = false;
                }
                if (row["Createtime"].ToString() != "")
                {
                    model.createtime = DateTime.Parse(row["Createtime"].ToString());
                }
                model.owneridname = row["owneridname"].ToString();
                model.tqhd = row["tqhd"].ToString();
                model.card = row["card"].ToString();
                model.cardimageurl = row["cardimageurl"].ToString();
                if (row["cardtype"].ToString() != "")
                {
                    model.cardtype = int.Parse(row["cardtype"].ToString());
                }
                model.phone = row["phone"].ToString();
                model.name = row["name"].ToString();
                model.cjiname = row["cjiname"].ToString();
                model.job = row["job"].ToString();
                model.email = row["email"].ToString();
            }
            return model;
        }
        //用datareader办法获取实体
        //public List<Yasn.Model.ZhanHuiGuanLianModel> GetPrimarySecondaryList(int zhglid)
        //{
        //    Yasn.Model.ZhanHuiGuanLianModel one = GetModel(zhglid);
        //    if (one.LeadId != 0)
        //    {
        //        zhglid = one.LeadId;
        //    }
        //    StringBuilder sbSql = new StringBuilder();
        //    sbSql.Append("SELECT * FROM zhanhuiguanlian with(nolock) WHERE  id=@id ");
        //    sbSql.Append(" union SELECT * FROM zhanhuiguanlian with(nolock) WHERE  LeadID=@id ");

        //    SqlParameter[ ] parameters = {
        //        new SqlParameter("@id",zhglid)
        //    };
        //    List<Yasn.Model.ZhanHuiGuanLianModel> list = new List<Yasn.Model.ZhanHuiGuanLianModel>();

        //    using (IDataReader dataReader = DbHelperSQL.ExecuteReader(sbSql.ToString(), parameters))
        //    {
        //        while (dataReader.Read())
        //        {
        //            list.Add(ReaderBind(dataReader));
        //        }
        //    }
        //    return list;
        //}

        /// <summary>
        /// 获取给定对象ID基本信息和随行人员信息，用dataset办法获取实体
        /// </summary>
        /// <param name="zhglid"></param>
        /// <returns></returns>
        public List<Yasn.Model.ZhanHuiGuanLianModel> GetPrimarySecondaryList(int zhglid)
        {
            //Yasn.Model.ZhanHuiGuanLianModel one = GetModel(zhglid);
            //if (one.LeadId != 1)
            //{
            //    zhglid = one.LeadId;
            //}
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT top 1 * FROM zhanhuiguanlian with(nolock) WHERE  id=@id ");
            //sbSql.Append(" union SELECT * FROM zhanhuiguanlian with(nolock) WHERE  LeadID=@id ");

            SqlParameter[] parameters = {
                new SqlParameter("@id",zhglid)
            };
            List<Yasn.Model.ZhanHuiGuanLianModel> list = new List<Yasn.Model.ZhanHuiGuanLianModel>();
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        Yasn.Model.ZhanHuiGuanLianModel model = new Yasn.Model.ZhanHuiGuanLianModel();
                        model.Id = int.Parse(row["id"].ToString());
                        model.zhanhuiid = int.Parse(row["zhanhuiid"].ToString());
                        if (!string.IsNullOrEmpty(row["vxmenberid"].ToString()))
                        {
                            model.vxmenberid = int.Parse(row["vxmenberid"].ToString());
                        }
                        model.ContactId = row["ContactId"].ToString();
                        if (!string.IsNullOrEmpty(row["shifoutb"].ToString()))
                        {
                            model.shifoutb = Convert.ToBoolean(row["shifoutb"].ToString());
                        }
                        else
                        {
                            model.shifoutb = false;
                        }
                        model.createtime = DateTime.Parse(row["Createtime"].ToString());
                        model.owneridname = row["owneridname"].ToString();
                        model.tqhd = row["tqhd"].ToString();
                        model.card = row["card"].ToString();
                        model.cardimageurl = row["cardimageurl"].ToString();
                        if (!string.IsNullOrEmpty(row["cardtype"].ToString()))
                        {
                            model.cardtype = int.Parse(row["cardtype"].ToString());
                        }

                        model.phone = row["phone"].ToString();
                        model.name = row["name"].ToString();
                        model.cjiname = row["cjiname"].ToString();
                        model.job = row["job"].ToString();
                        model.email = row["email"].ToString();
                        model.MainBusine = row["MainBusine"].ToString();
                        if (!string.IsNullOrEmpty(row["IsZS"].ToString()))
                        {
                            model.IsZS = int.Parse(row["IsZS"].ToString());
                        }
                        if (!string.IsNullOrEmpty(row["gift"].ToString()))
                        {
                            model.gift = int.Parse(row["gift"].ToString());
                        }
                        if (!string.IsNullOrEmpty(row["LeadID"].ToString()))
                        {
                            model.LeadId = int.Parse(row["LeadID"].ToString());
                        }
                        model.ProType = row["ProType"].ToString();
                        model.Telephone = row["Telephone"].ToString();
                        model.YXZhanhui = row["YXZhanhui"].ToString();
                        //model.AnswerInfo = row["AnswerInfo"].ToString();
                        list.Add(model);
                    }
                }
            }
            return list;
        }

        public ZhanHuiGuanLianModel GetModel(int zhglid)
        {
            StringBuilder sbSql = new StringBuilder();
            sbSql.Append("SELECT top 1 ");
            sbSql.Append("  * ");
            sbSql.Append("FROM ");
            sbSql.Append("  zhanhuiguanlian with(nolock) ");
            sbSql.Append("WHERE ");
            sbSql.Append("  id=@id order by id desc ");

            SqlParameter[] parameters = {
                new SqlParameter("@id",zhglid)
            };
            DataSet ds = DbHelperSQL.Query(sbSql.ToString(), parameters);
            ZhanHuiGuanLianModel model = null;

            using (IDataReader dataReader = DbHelperSQL.ExecuteReader(sbSql.ToString(), parameters))
            {
                while (dataReader.Read())
                {
                    model = ReaderBind(dataReader);
                }
            }
            return model;
        }
        /// <summary>
        /// 根据手机号获取当前展会参展信息
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <returns></returns>
        public ZhanHuiGuanLianModel GetParticipants(string phone)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select top 1 c.* from dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where  c.zhanhuiid=b.ID and b.shifoudangqianzh=1 and  c.phone='{0}'", phone.Trim());
            Yasn.Model.ZhanHuiGuanLianModel model = null;
            using (IDataReader dataReader = DbHelperSQL.ExecuteReader(strSql.ToString()))
            {
                while (dataReader.Read())
                {
                    model = ReaderBind(dataReader);
                }
            }
            return model;
        }

        /// <summary>
        /// 根据手机号获取当前展会参展信息
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <param name="zhanhuiId">展会</param>
        /// <returns></returns>
        public ZhanHuiGuanLianModel GetParticipants(string phone, int zhanhuiId)
        {
            StringBuilder strSql = new StringBuilder();

            strSql.AppendFormat("select top 1 c.* from dbo.zhanhui as b,dbo.zhanhuiguanlian  as c  where  c.zhanhuiid=b.ID and b.ID={1} and  c.phone='{0}'", phone.Trim(), zhanhuiId);
            Yasn.Model.ZhanHuiGuanLianModel model = null;
            using (IDataReader dataReader = DbHelperSQL.ExecuteReader(strSql.ToString()))
            {
                while (dataReader.Read())
                {
                    model = ReaderBind(dataReader);
                }
            }
            return model;
        }


        private ZhanHuiGuanLianModel ReaderBind(IDataReader dataReader)
        {
            Yasn.Model.ZhanHuiGuanLianModel model = new Yasn.Model.ZhanHuiGuanLianModel();
            DataTable dt = dataReader.GetSchemaTable();
            object ojb;
            if (dt.Select("ColumnName='Id'").LongLength > 0)
            {
                ojb = dataReader["Id"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.Id = (int)ojb;
                }
            }
            if (dt.Select("ColumnName='zhanhuiid'").LongLength > 0)
            {
                ojb = dataReader["zhanhuiid"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.zhanhuiid = (int)ojb;
                }
            }
            if (dt.Select("ColumnName='vxmenberid'").LongLength > 0)
            {
                ojb = dataReader["vxmenberid"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.vxmenberid = (int)ojb;
                }
            }
            model.ContactId = dt.Select("ColumnName='ContactId'").LongLength > 0 ? dataReader["ContactId"].ToString() : string.Empty;
            if (dt.Select("ColumnName='shifoutb'").LongLength > 0)
            {
                ojb = dataReader["shifoutb"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.shifoutb = Convert.ToBoolean(ojb);
                }
            }
            if (dt.Select("ColumnName='Createtime'").LongLength > 0)
            {
                ojb = dataReader["Createtime"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.createtime = (DateTime)(ojb);
                }
            }
            model.owneridname = dt.Select("ColumnName='owneridname'").LongLength > 0 ? dataReader["owneridname"].ToString() : string.Empty;
            model.tqhd = dt.Select("ColumnName='tqhd'").LongLength > 0 ? dataReader["tqhd"].ToString() : string.Empty;
            model.card = dt.Select("ColumnName='card'").LongLength > 0 ? dataReader["card"].ToString() : string.Empty;
            model.cardimageurl = dt.Select("ColumnName='cardimageurl'").LongLength > 0 ? dataReader["cardimageurl"].ToString() : string.Empty;

            if (dt.Select("ColumnName='cardtype'").LongLength > 0)
            {
                ojb = dataReader["cardtype"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.cardtype = (int)ojb;
                }
            }

            model.phone = dt.Select("ColumnName='phone'").LongLength > 0 ? dataReader["phone"].ToString() : string.Empty;
            model.name = dt.Select("ColumnName='name'").LongLength > 0 ? dataReader["name"].ToString() : string.Empty;

            model.cjiname = dt.Select("ColumnName='cjiname'").LongLength > 0 ? dataReader["cjiname"].ToString() : string.Empty;
            model.job = dt.Select("ColumnName='job'").LongLength > 0 ? dataReader["job"].ToString() : string.Empty;
            model.email = dt.Select("ColumnName='email'").LongLength > 0 ? dataReader["email"].ToString() : string.Empty;
            if (dt.Select("ColumnName='IsZS'").LongLength > 0)
            {
                ojb = dataReader["IsZS"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.IsZS = (int)ojb;
                }
            }
            if (dt.Select("ColumnName='gift'").LongLength > 0)
            {
                ojb = dataReader["gift"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.gift = (int)ojb;
                }
            }
            if (dt.Select("ColumnName='LeadID'").LongLength > 0)
            {
                ojb = dataReader["LeadID"];
                if (ojb != null && ojb != DBNull.Value)
                {
                    model.LeadId = (int)ojb;
                }
            }

            model.ProType = dt.Select("ColumnName='ProType'").LongLength > 0 ? dataReader["ProType"].ToString() : string.Empty;
            model.Telephone = dt.Select("ColumnName='Telephone'").LongLength > 0 ? dataReader["Telephone"].ToString() : string.Empty;
            model.YXZhanhui = dt.Select("ColumnName='YXZhanhui'").LongLength > 0 ? dataReader["YXZhanhui"].ToString() : string.Empty;
            model.AnswerInfo = dt.Select("ColumnName='AnswerInfo'").LongLength > 0 ? dataReader["AnswerInfo"].ToString() : string.Empty;
            return model;
        }
    }
}
