﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Yasn.Model;
using Yasn.Model.WechatClass;

namespace Yasn.Logic
{
    public class CarAccessoryWXMember
    {

        public static string AddMember(WXMember model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            model.MemberNo = GetMaxCardNo();
            return dal.Add(model);

        }
        /// <summary>
        /// 通过其他渠道的数据添加到WXMember表
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static string AddWXMemberByPhone(WXMember model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddWXMemberByPhone(model);

        }
        public static string AddWXMemberByPhone_xzc(WXMember model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            model.MemberNo = GetMaxCardNoNow(2012);
            return dal.AddWXMemberByPhone(model);

        }
        public static string AddWXMemberByPhone_xzc(WXMember model, int zhanhuiID)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            model.MemberNo = GetMaxCardNoNow(zhanhuiID);
            return dal.AddWXMemberByPhone(model);

        }

        //添加人：李晚强 添加时间：2016-09-08 12:02:21
        public static string AddMemberNew(WXMember model, int zhanhuiID)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            model.MemberNo = GetMaxCardNoNow(zhanhuiID);
            return dal.Add(model);

        }
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static long GetMaxCardNoNow(int zhanhuiID)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            long maxMemberNo = dal.GetMaxMemberNoNow(zhanhuiID);
            if (maxMemberNo == 0 && zhanhuiID == 2009)
            {
                maxMemberNo = 20001001;
            }
            //else if (maxMemberNo == 0 && zhanhuiID == 2010)
            //{
            //    maxMemberNo = 90001001;
            //}
            //else if (maxMemberNo == 0 && zhanhuiID == 2011)
            //{
            //    maxMemberNo = 90001001;
            //}
            else if (maxMemberNo == 0 && zhanhuiID == 2012)
            {
                maxMemberNo = 90001001;
            }
            else if (maxMemberNo == 0 && zhanhuiID == 2013)
            {
                maxMemberNo = 260001001;
            }
            else
            {
                maxMemberNo = maxMemberNo + 1;
            }
            return maxMemberNo;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static long GetMaxCardNo()
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            long maxMemberNo = dal.GetMaxMemberNo();

            if (maxMemberNo == 0)
                maxMemberNo = 90000001;
            maxMemberNo = maxMemberNo + 1;
            return maxMemberNo;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static long GetMaxCardNo(int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            long maxMemberNo = dal.GetMaxMemberNo(zhanhuiId);

            if (maxMemberNo == 0)
                maxMemberNo = 90000001;
            maxMemberNo = maxMemberNo + 1;
            return maxMemberNo;
        }

        public static bool IsExistsWXMember(string weiXinNo)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsWXMember(weiXinNo);

        }
        public static bool IsExistsWXMember(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsWXMember(weiXinNo, zhanhuiId);

        }

        public static bool IsExistsBaoXiao(string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsBaoXiao(phone);
        }

        public static bool IsExistsBaoXiao(string phone, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsBaoXiao(phone, zhanhuiId);
        }

        public static bool IsExistsPhoneOfCurrent(string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsPhoneOfCurrent(phone);
        }

        public static bool IsExistsPhoneOfAllChannels(string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsPhoneOfAllChannels(phone);
        }
        public static bool IsExistsPhoneOfCurrent(string phone, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();

            return dal.IsExistsPhoneOfCurrent(phone, zhanhuiId);
        }
        // 得到当前展会实例
        public static Zhanhui GetExhibit()
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            Yasn.Model.Zhanhui result = dal.GetZHList().FirstOrDefault();
            return result;
        }

        // 得到当前展会实例
        public static Zhanhui GetExhibit(int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            Yasn.Model.Zhanhui result = dal.GetZHList(zhanhuiId).FirstOrDefault();
            return result;
        }

        /// <summary>
        /// 根据他方用户ID获取用户二维码
        /// </summary>
        /// <param name="mapId">他方用户ID</param>
        /// <returns></returns>
        public static string GetUserQRCode(long mapId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetUserQRCode(mapId);
        }

        public static string AddZhanHuiGuanLian(ZhanHuiGuanLianModel model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddZhanHuiGuanLian(model);
        }
        /// <summary>
        /// 通过其他渠道报名的信息插入到zhanhuiguanlian表中
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static int AddZhanHuiGuanLianByOther(ZhanHuiGuanLianModel model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddZhanHuiGuanLianByOther(model);
        }

        public static string UpdateZhanHuiGuanLian(ZhanHuiGuanLianModel model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.UpdateZhanHuiGuanLian(model);
        }

        public static ZhanHuiGuanLianModel GetZhanHuiGuanLian(int zhanhuiid, string wxNo)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetListByWxno(zhanhuiid, wxNo).FirstOrDefault();
        }
        public static Test_Phone GetListByPhoned(string card, string Phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetListByPhoned(card, Phone).FirstOrDefault();
        }
        public static Test_Phone GetListByPhone(string Phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetListByPhone(Phone).FirstOrDefault();
        }
        public static ZhanHuiGuanLianModel GetListByPhone(string card, string Phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetListByPhone(card, Phone).FirstOrDefault();
        }

        public static void UpdateApply(int userId, int giftId, bool isTongBu)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            dal.UpdateApply(userId, giftId, isTongBu);
        }
        /// <summary>
        /// 得到当前展会实例列表
        /// </summary>
        /// <returns></returns>
        public static List<Zhanhui> GetZHList()
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetZHList();
        }
        public static Dictionary<string, string> GetDQBMID(string weiXinNo)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetDQBMID(weiXinNo);
            Dictionary<string, string> dic = new Dictionary<string, string>();

            if (dt != null && dt.Rows.Count > 0)
            {
                dic["Id"] = dt.Rows[0]["id"].ToString();
                dic["Gift"] = dt.Rows[0]["gift"].ToString();
            }
            return dic;
        }

        public static Dictionary<string, string> GetDQBMID(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetDQBMID(weiXinNo, zhanhuiId);
            Dictionary<string, string> dic = new Dictionary<string, string>();

            if (dt != null && dt.Rows.Count > 0)
            {
                dic["Id"] = dt.Rows[0]["id"].ToString();
                dic["Gift"] = dt.Rows[0]["gift"].ToString();
            }
            return dic;
        }
        public static int GetDQBMBYID(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetDQBMBYID(weiXinNo, zhanhuiId);

            if (dt != null && dt.Rows.Count > 0)
            {
                return int.Parse(dt.Rows[0]["id"].ToString());
            }
            return 0;
        }

        public static List<string> GetUserConcern(int userId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetUserConcern(userId);
            return dt.AsEnumerable().Select(c => c.Field<string>("tqhdname")).ToList<string>();
        }
        /// <summary>
        /// 获取当前展会同期活动
        /// </summary>
        /// <param name="zhanhuiId"></param>
        /// <param name="status">活动状态</param>
        /// <returns></returns>
        public static List<Yasn.Model.WechatClass.Activity> GetActivityOfCurrent(int zhanhuiId, bool status)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            var activities = dal.GetActivityOfCurrent(zhanhuiId);
            return activities.Where(c => c.StateCode == status).ToList();
        }
        /// <summary>
        /// 根据手机号码获取该用户的酒店入住相关信息
        /// </summary>
        /// <param name="zhanhuiId"></param>
        /// <param name="weiXinNo"></param>
        /// <param name="fullname"></param>
        /// <param name="bm"></param>
        /// <param name="isgift"></param>
        /// <returns></returns>
        public static int GetMID(int zhanhuiId, string phone, ref string FullName, ref string HotelName, ref string RoomType, ref DateTime CheckInDate, ref DateTime CheckOutDate, ref string CheckInState, ref string Remark)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetMID( zhanhuiId, phone, ref FullName, ref HotelName, ref RoomType, ref CheckInDate, ref CheckOutDate, ref CheckInState, ref Remark);
        }
        public static DataTable GetMID(int zhanhuiId, string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetMID(zhanhuiId, phone);
        }
        public static int AddToken(TokenInfo model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddToken(model);
        }
        public static string GetToken()
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetToken();
        }
        public static string GetQCode(int Code)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetQCode(Code);
        }
        public static string AddSMSHistory(SMSHistory model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddSMSHistory(model);
        }
        public static string AddLocationInfo(int ZhanhuiNo, string openid, decimal Lng, decimal Lat, string Province, string City, string District)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddLocationInfo(ZhanhuiNo, openid, Lng, Lat, Province, City, District);
        }
        /// <summary>
        /// 进入程序首先判断微信openid是否已经报过名
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public static int IsWXNo(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetDQBMBYID(weiXinNo, zhanhuiId);

            if (dt != null && dt.Rows.Count > 0)
            {
                return int.Parse(dt.Rows[0]["id"].ToString());
            }
            return 0;
        }
        /// <summary>
        /// 多个微信号绑定一个手机号；需要更新微信号
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static string UpdateWXNOByPhone(WXMember model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.UpdateWXNOByPhone(model);
        }
        /// <summary>
        /// 更新微信号之后，通过手机号获取展会关联表中的id
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public static int GetIDByPhone(string phone, int ZhanhuiNo)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetIDByPhone(phone, ZhanhuiNo);

            if (dt != null && dt.Rows.Count > 0)
            {
                return int.Parse(dt.Rows[0]["id"].ToString());
            }
            return 0;
        }
        public static string QueryCode(string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.QueryCode(phone);

            if (dt != null && dt.Rows.Count > 0)
            {
                return dt.Rows[0]["VerCode"].ToString();
            }
            return "未查到任何数据";
        }

        public static string ZHGLUpdateWXNOByPhone(string WXNo, string Mobile, int ZhanhuiNo)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.ZHGLUpdateWXNOByPhone(WXNo, Mobile, ZhanhuiNo);
        }
        /// <summary>
        /// 领取礼品或报销     2017.11.20
        /// </summary>
        /// <param name="openid"></param>
        /// <param name="flag"></param>
        /// <param name="zhanhuiid"></param>
        /// <returns></returns>
        public static string GoCheckIn(string ID, int zhanhuiid)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GoCheckIn(ID, zhanhuiid);
           
        }
        /// <summary>
        /// 进入程序首先判断微信openid是否已经报过名
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public static string GetPhoneByOpenid(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetDQBMBYID(weiXinNo, zhanhuiId);

            if (dt != null && dt.Rows.Count > 0)
            {
                return dt.Rows[0]["phone"].ToString();
            }
            return "未查到手机号";
        }

        /// <summary>
        /// 获取当前展会的某个微信号的报名部分信息 2017.11.20
        /// </summary>
        /// <param name="zhanhuiId"></param>
        /// <param name="weiXinNo"></param>
        /// <param name="fullname"></param>
        /// <param name="bm"></param>
        /// <param name="isgift"></param>
        /// <returns></returns>
        public static int GetRestInfo(int zhanhuiId, string weiXinNo, ref string fullname, ref string bm, ref int isgift, ref int giftvalue, ref string phone)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GetRestInfo(zhanhuiId, weiXinNo, ref fullname, ref bm, ref isgift, ref giftvalue, ref phone);
        }

        /// <summary>
        /// 领取礼品或报销     2017.11.20
        /// </summary>
        /// <param name="openid"></param>
        /// <param name="flag"></param>
        /// <param name="zhanhuiid"></param>
        /// <returns></returns>
        public static string GoGift(string ID,int flag, int zhanhuiid)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GoGift(ID, flag, zhanhuiid);

        }

        public static string AddTqhdSign(TqhdSign model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddTqhdSign(model);
        }

        public static string GoARState(string ID, int zhanhuiid)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.GoARState(ID, zhanhuiid);

        }
        /// <summary>
        /// 获取观众领取状态
        /// </summary>
        /// <param name="weiXinNo"></param>
        /// <param name="zhanhuiId"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetARInfo(string weiXinNo, int zhanhuiId)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            DataTable dt = dal.GetARInfo(weiXinNo, zhanhuiId);

            Dictionary<string, string> dic = new Dictionary<string, string>();
            if (dt != null && dt.Rows.Count > 0)
            {
                dic["ARState"] = dt.Rows[0]["ARState"].ToString();      //观众领取状态
                dic["ARDatetime"] = dt.Rows[0]["ARDatetime"].ToString();      //观众领取时间
            }
            return dic;
        }
        public static int AddZhanHuiGuanLianByPhoneBasic(ZhanHuiGuanLianModel model)
        {
            Yasn.Data.CarAccessoryWXMember dal = new Yasn.Data.CarAccessoryWXMember();
            return dal.AddZhanHuiGuanLianByPhoneBasic(model);
        }
    }
}
