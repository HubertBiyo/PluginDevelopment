﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Data;
using Yasn.Model;
using Yasn.Model.WechatClass;

namespace Yasn.Logic
{
    public class WXMemberLogic
    {

        private static WXMemberData dal;

        #region  Method

        public static List<WXMember> GetList(int pageIdex, int pageSize, string keyWord, out int totalCount)
        {
            dal = new WXMemberData();
            return dal.GetList(pageIdex, pageSize, keyWord, out totalCount);
        }

        public static bool ExistsWxNo(string wxNo)
        {
            dal = new WXMemberData();
            return dal.ExistsWxNo(wxNo);
        }

        public static bool ExistsMobile(string mobile)
        {
            dal = new WXMemberData();
            return dal.ExistsMobile(mobile);
        }

        /// <summary>
        /// 增加一条数据
        /// </summary>
        public static string Add(WXMember model)
        {
            dal = new WXMemberData();

            long maxMemberNo = dal.GetMaxMemberNo();

            if (maxMemberNo == 0)
                maxMemberNo = 90000001;

            model.MemberNo = maxMemberNo + 1;

            return dal.Add(model);

        }
        /// <summary>
        /// 增加一条数据
        /// </summary>
        public static string Add(ZhanHuiGuanLianModel model)
        {
            dal = new WXMemberData();

            return dal.Add(model);

        }

        /// <summary>
        /// 增加一条数据-展会报销
        /// </summary>
        public static string AddBiaoXiao(ZhanHuiBiaoXiaoModel model)
        {
            dal = new WXMemberData();

            return dal.AddBiaoXiao(model);

        }
        /// <summary>
        /// 获得默认展会信息
        /// </summary>
        public static DataSet GetZhanHui()
        {
            dal = new WXMemberData();

            return dal.GetZhanHui();
        }
        /// <summary>
        /// 获取同期活动列表
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public static DataSet GetActiveList(int zhid)
        {
            dal = new WXMemberData();

            return dal.GetActiveList(zhid);
        }
        /// <summary>
        /// 查找用户报名同期活动时是否已经注册
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public static bool GetActiveSF(string mobile, string zhanhuiid)
        {
            dal = new WXMemberData();

            return dal.GetActiveSF(mobile, zhanhuiid);
        }
        /// <summary>
        /// 查找用户报名是否已报名报销
        /// </summary>
        /// <param name="zhid"></param>
        /// <returns></returns>
        public static bool GetBiaoXiao(string wxno, string zhanhuiid)
        {
            dal = new WXMemberData();

            return dal.GetBiaoXiao(wxno, zhanhuiid);
        }
        /// <summary>
        /// 更新同期活动
        /// </summary>
        public static bool UpdateTQHD(string mibile, string tqhd, int zhanhuiid)
        {
            dal = new WXMemberData();
            return dal.UpdateTQHD(mibile, tqhd, zhanhuiid);
        }
        /// <summary>
        /// 获得默认展会信息
        /// </summary>
        public static DataSet GetActiveList(int wmid, int zhanhuiid)
        {
            dal = new WXMemberData();

            return dal.GetActiveList(wmid, zhanhuiid);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public static bool Update(WXMember model)
        {
            dal = new WXMemberData();
            return dal.Update(model);
        }


        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public static WXMember GetModel(string wxNo)
        {
            dal = new WXMemberData();

            return dal.GetModel(wxNo);
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public static WXMember GetModelByPhone(string phone)
        {
            dal = new WXMemberData();
            return dal.GetModelByPhone(phone);
        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public static List<WXMember> GetModelList(string wxNo)
        {
            dal = new WXMemberData();

            return dal.GetModelList(wxNo);
        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public static List<WXMember> GetModelList(string wxNo, string zhanhuiid)
        {
            dal = new WXMemberData();

            return dal.GetModelList(wxNo, zhanhuiid);
        }
        /// <summary>
        /// 得到对象实体
        /// </summary>
        public static DataSet GetModelBiaoXiaoList(string wxNo, string zhanhuiid)
        {
            dal = new WXMemberData();

            return dal.GetModelBiaoXiaoList(wxNo, zhanhuiid);
        }
        public static List<WXMember> GetYPModelList(string Phone)
        {
            WXMemberData dal = new WXMemberData();

            return dal.GetYPModelList(Phone);
        }
        public static List<WXMember> GetYPModelList(string Phone, int zhanhuiId)
        {
            WXMemberData dal = new WXMemberData();

            return dal.GetYPModelList(Phone, zhanhuiId);
        }
        public static int GetMemberModelList(string wxno)
        {
            WXMemberData dal = new WXMemberData();

            return dal.GetMemberModelList(wxno);
        }
        public static bool Delete(int id)
        {
            dal = new WXMemberData();
            return dal.Delete(id);
        }
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public static void GetSp_WXTimer(string touser)
        {
            dal = new WXMemberData();

            dal.GetSp_WXTimer(touser);
        }
        /// <summary>
        /// 查询当天的要提醒用户名单
        /// </summary>
        /// <returns></returns>
        public static DataSet GetWXTimer()
        {
            UsersData userdal = new UsersData();

            return userdal.GetWXTimer();
        }
        /// <summary>
        /// 添加被动回复文本信息
        /// </summary>
        /// <param name="WechatXML"></param>
        /// <param name="ReturnContent"></param>
        /// <returns></returns>
        public static int InsertWechatXML(ExmlMsg WechatXML, string ReturnContent)
        {
            Yasn.Data.WXMemberData dal = new Yasn.Data.WXMemberData();
            return dal.InsertWechatXML(WechatXML, ReturnContent);
        }
        /// <summary>
        /// 根据用户发送的消息查询对应的数据
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static string GetUserName(string content)
        {
            Yasn.Data.WXMemberData dal = new Yasn.Data.WXMemberData();
            return dal.GetUserName(content);
        }
        #endregion

    }
}
