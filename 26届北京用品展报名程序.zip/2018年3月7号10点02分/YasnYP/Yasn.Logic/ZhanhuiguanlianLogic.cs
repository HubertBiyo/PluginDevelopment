﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yasn.Data;
using Yasn.Model;

namespace Yasn.Logic
{
    public class ZhanhuiguanlianLogic
    {
        private static ZhanhuiguanlianData dal = new ZhanhuiguanlianData();
        public static ZhanHuiGuanLianModel GetYPModel(int zhglid)
        {
            return dal.GetYPModel(zhglid);
        }
        /// <summary>
        /// 获取给定对象ID基本信息和随行人员信息
        /// </summary>
        /// <param name="zhglid"></param>
        /// <returns></returns>
        public static List<Yasn.Model.ZhanHuiGuanLianModel> GetPrimarySecondaryList(int zhglid)
        {
            return dal.GetPrimarySecondaryList(zhglid);
        }

        /// <summary>
        /// 根据手机号获取当前展会参展信息
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <returns></returns>
        public static ZhanHuiGuanLianModel GetParticipants(string phone)
        {
            return dal.GetParticipants(phone);
        }

        /// <summary>
        /// 根据手机号获取当前展会参展信息
        /// </summary>
        /// <param name="phone">手机号</param>
        ///  <param name="zhanhuiId">展会</param>
        /// <returns></returns>
        public static ZhanHuiGuanLianModel GetParticipants(string phone, int zhanhuiId)
        {
            return dal.GetParticipants(phone, zhanhuiId);
        }
    }
}
