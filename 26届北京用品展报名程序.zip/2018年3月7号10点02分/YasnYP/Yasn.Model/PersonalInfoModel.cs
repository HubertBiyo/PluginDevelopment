﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class PersonalInfoModel : ICloneable
    {
        private int _zhanhuiNo;
        private string _company;
        private string _username;
        private string _iszs;
        private string _userposition;
        private string _industryOwend;
        private string _proType;
        private string _UserMobile;
        private string _mainBusine; //经营类型
        private string _manageType; //主营业务
        private string _enjoyProduct;//兴趣活动
        private string _registratCode;
        public string _idcard;
        public string _sex;
        public string _gztype;
        public string _zwcard;
        public string _imgUrl;
        public int _leadid;
        /// <summary>
        /// 姓名
        /// </summary>
        public string UserName
        {
            set
            {
                _username = value;
            }
            get
            {
                return _username;
            }
        }
        /// <summary>
        /// 经营类型
        /// </summary>
        public string MainBusine
        {
            set
            {
                _mainBusine = value;
            }
            get
            {
                return _mainBusine;
            }
        }
        /// <summary>
        /// 主营业务
        /// </summary>
        public string ManageType
        {
            set
            {
                _manageType = value;
            }
            get
            {
                return _manageType;
            }
        }
        public string EnjoyProduct
        {
            set
            {
                _enjoyProduct = value;
            }
            get
            {
                return _enjoyProduct;
            }
        }
        /// <summary>
        /// 性别
        /// </summary>
        public string Sex
        {
            set { _sex = value; }
            get { return _sex; }
        }
        public string IndustryOwend
        {
            set { _industryOwend = value; }
            get { return _industryOwend; }
        }
        /// <summary>
        /// 观众类别
        /// </summary>
        public string GZType
        {
            set { _gztype = value; }
            get { return _gztype; }
        }
        /// <summary>
        /// 身份证号
        /// </summary>
        public string IDCard
        {
            set { _idcard = value; }
            get { return _idcard; }
        }
        /// <summary>
        /// 工作单位
        /// </summary>
        public string Company
        {
            set
            {
                _company = value;
            }
            get
            {
                return _company;
            }
        }
        /// <summary>
        /// 展位号
        /// </summary>
        public string ZWCard
        {
            set
            {
                _zwcard = value;
            }
            get
            {
                return _zwcard;
            }
        }
        //随行人员ID
        public int LeadID
        {
            set { _leadid = value; }
            get { return _leadid; }
        }
        /// <summary>
        /// 职务
        /// </summary>
        public string UserPosition
        {
            set
            {
                _userposition = value;
            }
            get
            {
                return _userposition;
            }
        }
        /// <summary>
        /// 是否展商（观众，展商）
        /// </summary>
        public string ISZS
        {
            set
            {
                _iszs = value;
            }
            get
            {
                return _iszs;
            }
        }
        public string ImgUrl
        {
            set
            {
                _imgUrl = value;
            }
            get
            {
                return _imgUrl;
            }
        }
        /// <summary>
        /// 编码
        /// </summary>
        public string RegistratCode
        {
            set { _registratCode = value; }
            get { return _registratCode; }
        }

        public string UserMobile
        {
            set
            {
                _UserMobile = value;
            }
            get
            {
                return _UserMobile;
            }
        }
        public int ZhanhuiNo
        {
            set
            {
                _zhanhuiNo = value;
            }
            get
            {
                return _zhanhuiNo;
            }
        }




        /// <summary>
        /// 微信OpenID
        /// </summary>
        public string WeiXinOpenId
        {
            set;
            get;
        }

        /// <summary>
        /// 申请报销与礼品
        /// </summary>
        public string MyGift
        {
            set;
            get;
        }
        /// <summary>
        /// 喜好分类
        /// </summary>
        public string ProType
        {
            set
            {
                _proType = value;
            }
            get
            {
                return _proType;
            }
        }






        #region ICloneable 成员

        public object Clone()
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(ms, this);
            ms.Position = 0;
            return formatter.Deserialize(ms);
        }

        #endregion
    }
}
