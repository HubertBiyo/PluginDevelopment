﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    /// <summary>
    /// 北京用品展报名基础数据表
    /// </summary>
    public class PhoneBasic
    {
        /// <summary>
        /// 手机号码
        /// </summary>
        public string phone { get; set; }
        /// <summary>
        /// 编码
        /// </summary>
        public string card { get; set; }
        /// <summary>
        /// 二维码url路径
        /// </summary>
        public string cardimageurl { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string fullname { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string accountname { get; set; }
        /// <summary>
        /// 职务
        /// </summary>
        public string job { get; set; }
        /// <summary>
        /// 单位性质
        /// </summary>
        public string accounttype { get; set; }
        /// <summary>
        /// 编码首数字，便于统计
        /// </summary>
        public int signup { get; set; }
    }
}
