﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class SMSHistory
    {
        /// <summary>
        /// 主键，自增
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 短信内容
        /// </summary>
        public string SMSContent { get; set; }
        /// <summary>
        /// 短信平台账户
        /// </summary>
        public string SerialNum { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// 发送短信渠道
        /// </summary>
        public int Channel { get; set; }
        /// <summary>
        /// 短信类型
        /// </summary>
        public int SMSType { get; set; }
        /// <summary>
        /// 展会id
        /// </summary>
        public int ZhanhuiID { get; set; }
        /// <summary>
        /// 手机号码
        /// </summary>
        public string Phone { get; set; }
    }
}
