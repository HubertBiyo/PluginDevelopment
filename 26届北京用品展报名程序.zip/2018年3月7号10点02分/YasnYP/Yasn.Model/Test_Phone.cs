﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    /// <summary>
    /// 广州展全部手机号
    /// </summary>
    public class Test_Phone
    {
        /// <summary>
        /// 手机号码
        /// </summary>
        public string yasn_phone { get; set; }
        /// <summary>
        /// 跳转成功页的唯一编码
        /// </summary>
        public string yasn_code { get; set; }
        /// <summary>
        /// 二维码图片路径
        /// </summary>
        public string cardimageurl { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string fullname { get; set; }
        /// <summary>
        /// 报销，预登记，新注册
        /// </summary>
        public int signup { get; set; }

        public int ISGift { get; set; }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string accountname { get; set; }
        /// <summary>
        /// 职务
        /// </summary>
        public string job { get; set; }
        /// <summary>
        /// 单位性质
        /// </summary>
        public string accounttype { get; set; }
        /// <summary>
        /// 编码
        /// </summary>
        public string card { get; set; }

        public string protype { get; set; }
        public string mainbusine { get; set; }
        public string managetype { get; set; }
        public string Company { get; set; }
    }
}
