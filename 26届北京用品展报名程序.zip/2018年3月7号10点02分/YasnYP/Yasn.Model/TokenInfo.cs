﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class TokenInfo
    {
        /// <summary>
        /// ID
        /// </summary>
        public int id { set; get; }
        /// <summary>
        /// access_token
        /// </summary>
        public string access_token { set; get; }
        /// <summary>
        /// expiretime
        /// </summary>
        public DateTime expiretime { set; get; }
    }
}
