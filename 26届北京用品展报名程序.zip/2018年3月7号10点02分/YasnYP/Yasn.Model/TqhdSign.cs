﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    /// <summary>
    /// 同期活动签到记录表
    /// </summary>
   public class TqhdSign
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 微信公众号OpenID
        /// </summary>
        public string OpenID { get; set; }
        /// <summary>
        /// 同期活动表ID(Activity)
        /// </summary>
        public int tqhdID { get; set; }
        /// <summary>
        /// 创建时间，默认为当前日期
        /// </summary>
        public DateTime Createdon { get; set; }
    }
}
