﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class Users
    {

        /// <summary>
        /// Id
        /// </summary>		
        public static string FIELDId = "Id";

        /// <summary>
        ///  用户名称
        /// </summary>		
        public static string FIELDName = "Name";

        /// <summary>
        /// 登陆密码
        /// </summary>		
        public static string FIELDPassword = "Password";


        /// <summary>
        /// Mobile
        /// </summary>		
        public static string FIELDMobile = "Mobile";

        /// <summary>
        /// Email
        /// </summary>		
        public static string FIELDEmail = "Email";

        /// <summary>
        /// UserStatus
        /// </summary>		
        public static string FIELDUserStatus = "UserStatus";

        /// <summary>
        /// 创建人
        /// </summary>		
        public static string FIELDCreateId = "CreateId";

        /// <summary>
        /// CreateDate
        /// </summary>		
        public static string FIELDCreateDate = "CreateDate";

        /// <summary>
        /// LastLogDate
        /// </summary>
        public static string FIELDLastLogInDate = "LastLogInDate";
        /// <summary>
        /// IsDel
        /// </summary>
        public static string FIELDIsDel = "IsDel";


        /// <summary>
        /// Id
        /// </summary>	
        public int Id
        {
            get;
            set;
        }
        /// <summary>
        ///  用户名称
        /// </summary>	
        public string Name
        {
            get;
            set;
        }
        /// <summary>
        /// 登陆密码
        /// </summary>
        public string Password
        {
            get;
            set;
        }

        /// <summary>
        /// Mobile
        /// </summary>
        public string Mobile
        {
            get;
            set;
        }
        /// <summary>
        /// Email
        /// </summary>	
        public string Email
        {
            get;
            set;
        }
        /// <summary>
        /// UserStatus
        /// </summary>	
        public int UserStatus
        {
            get;
            set;
        }
        /// <summary>
        /// 创建人
        /// </summary>
        public int CreateId
        {
            get;
            set;
        }
        /// <summary>
        /// CreateDate
        /// </summary>	
        public DateTime CreateDate
        {
            get;
            set;
        }

        public DateTime LastLogInDate
        {
            get;
            set;
        }

        /// <summary>
        /// 是否删除
        /// </summary>
        public bool IsDel
        {
            get;
            set;
        }
    }
}
