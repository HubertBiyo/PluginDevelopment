﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class Activity
    {
        /// <summary>
        /// 自增ID
        /// </summary>
        public int ID
        {
            set;
            get;
        }
        /// <summary>
        /// 同期活动
        /// </summary>
        public string Tqhd
        {
            set;
            get;
        }
        /// <summary>
        /// 活动状态
        /// </summary>
        public bool StateCode
        {
            set;
            get;
        }
        /// <summary>
        /// 展会ID
        /// </summary>
        public int Zhanhuiid
        {
            set;
            get;
        }
    }
}
