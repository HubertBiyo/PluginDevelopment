﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class Articles
    {

        /// <summary>
        /// 文章自增id
        /// </summary>		
        public static string FIELDId = "Id";

        /// <summary>
        /// 文章标题
        /// </summary>		
        public static string FIELDTitle = "Title";

        /// <summary>
        /// 所属栏目 
        /// </summary>		
        public static string FIELDColumnCatagoryID = "ColumnCatagoryID";


        /// <summary>
        /// 作者
        /// </summary>		
        public static string FIELDAuthor = "Author";

        /// <summary>
        /// 缩略图
        /// </summary>		
        public static string FIELDThumbnails = "Thumbnails";

        /// <summary>
        /// 文件简介
        /// </summary>		
        public static string FIELDIntroduce = "Introduce";

        /// <summary>
        /// 文章内容
        /// </summary>		
        public static string FIELDContent = "Content";

        /// <summary>
        /// 是否显示
        /// </summary>		
        public static string FIELDViewMode = "ViewMode";

        /// <summary>
        /// 链接地址
        /// </summary>		
        public static string FIELDLinkUrl = "LinkUrl";

        /// <summary>
        /// 排序
        /// </summary>		
        public static string FIELDSort = "Sort";

        /// <summary>
        /// 创建时间
        /// </summary>
        public static string FIELDCreateDate = "CreateDate";

        /// <summary>
        /// 创建者
        /// </summary>
        public static string FIELDCreator = "Creator";


        /// <summary>
        /// 文章自增id
        /// </summary>		

        public int Id
        {
            get;
            set;
        }
        /// <summary>
        /// 文章标题
        /// </summary>		

        public string Title
        {
            get;
            set;
        }
        /// <summary>
        /// 感兴趣的新闻标题
        /// </summary>
        public string GXQTitle
        {
            get;
            set;
        }
        /// <summary>
        /// 所属栏目 
        /// </summary>		

        public int ColumnCatagoryID
        {
            get;
            set;
        }
        /// <summary>
        /// 所属展会
        /// </summary>
        public int ZhanhuiId { get; set; }
        /// <summary>
        /// 所属展会
        /// </summary>
        public string ZhanhuiName { get; set; }
        /// <summary>
        /// 作者
        /// </summary>		

        public string Author
        {
            get;
            set;
        }
        /// <summary>
        /// 缩略图
        /// </summary>		

        public string Thumbnails
        {
            get;
            set;
        }
        /// <summary>
        /// 文件简介
        /// </summary>		

        public string Introduce
        {
            get;
            set;
        }
        /// <summary>
        /// 文章内容
        /// </summary>		

        public string Content
        {
            get;
            set;
        }
        /// <summary>
        /// 是否显示
        /// </summary>		

        public bool ViewMode
        {
            get;
            set;
        }
        /// <summary>
        /// 链接地址
        /// </summary>		

        public string LinkUrl
        {
            get;
            set;
        }
        /// <summary>
        /// 排序
        /// </summary>		

        public int Sort
        {
            get;
            set;
        }

        /// <summary>
        /// 发布时间
        /// </summary>
        public DateTime CreateDate
        {
            get;
            set;
        }

        /// <summary>
        /// 发布者
        /// </summary>
        public int Creator
        {
            get;
            set;
        }

        /// <summary>
        /// 是否推荐
        /// </summary>
        public int Recommend
        {
            get;
            set;
        }
    }
}
