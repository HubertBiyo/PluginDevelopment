﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class CardImageJson
    {
        public CardImageJson()
        {
            //  
            //TODO: 在此处添加构造函数逻辑  
            //  
        }
        string _status;
        CardInfo _result;
        /// <summary>  
        /// 
        /// </summary>  
        public string status
        {
            get { return _status; }
            set { _status = value; }
        }
        /// <summary>  
        /// 列表数据，OPENID的列表
        /// </summary>  
        public CardInfo result
        {
            get { return _result; }
            set { _result = value; }
        }
    }
}
