﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class CardInfo
    {
        public CardInfo()
        {
            //  
            //TODO: 在此处添加构造函数逻辑  
            //  
        }
        string _CardSrc;

        /// <summary>  
        /// 
        /// </summary>  
        public string CardSrc
        {
            get { return _CardSrc; }
            set { _CardSrc = value; }
        }
    }
}
