﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class ResponseWeixin
    {
        /// <summary>
        /// 回复文本消息
        /// </summary>
        /// <param name="content">回复内容</param>
        /// <param name="UserOpenId">用户的openid</param>
        /// <param name="DevOpenId">开发者的微信号</param>
        /// <returns></returns>
        public static string ResponseText(string content, string UserOpenId, string DevOpenId)
        {
            string Txt = "<xml>";
            Txt = Txt + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            Txt = Txt + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            Txt = Txt + "<CreateTime>1348831860</CreateTime>";
            Txt = Txt + "<MsgType><![CDATA[text]]></MsgType>";
            Txt = Txt + "<Content><![CDATA[" + content + "]]></Content>";
            Txt = Txt + "<MsgId>1234567890123456</MsgId>";
            Txt = Txt + "</xml>";
            return Txt;
        }
        /// <summary>
        /// 回复图文消息列表
        /// </summary>
        /// <param name="_List">List类型的news消息，具体参照news类</param>
        /// <param name="UserOpenId">要发送用户的openid</param>
        /// <param name="DevOpenId">开发者的微信号</param>
        /// <returns></returns>
        public static string ResponsePic(List<Articles> _List, string UserOpenId, string DevOpenId, string newdate)
        {
            string pic = "<xml>";
            pic = pic + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            pic = pic + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            pic = pic + "<CreateTime>1348831860</CreateTime>";
            pic = pic + "<MsgType><![CDATA[news]]></MsgType>";
            pic = pic + "<ArticleCount>" + _List.Count + "</ArticleCount>";
            pic = pic + "<Articles>";
            for (int i = 0; i < _List.Count; i++)
            {
                pic = pic + "<item>";
                pic = pic + "<Title><![CDATA[" + _List[i].Title + "]]></Title>";
                pic = pic + "<Description><![CDATA[" + _List[i].Introduce + "]]></Description>";
                pic = pic + "<PicUrl><![CDATA[" + _List[i].Thumbnails + "]]></PicUrl>";
                pic = pic + "<Url><![CDATA[" + ConfigurationManager.AppSettings["activityinfourl"] + _List[i].Id + "]]></Url>";
                pic = pic + "</item>";
            }
            pic = pic + "</Articles>";
            pic = pic + "<FuncFlag>1</FuncFlag>";
            pic = pic + "</xml>";
            return pic;
        }
        /// <summary>
        /// 回复图文消息列表
        /// </summary>
        /// <param name="_List">List类型的news消息，具体参照news类</param>
        /// <param name="UserOpenId">要发送用户的openid</param>
        /// <param name="DevOpenId">开发者的微信号</param>
        /// <returns></returns>
        public static string ResponseFoodPic(List<Articles> _List, string UserOpenId, string DevOpenId, string newdate)
        {
            string pic = "<xml>";
            pic = pic + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            pic = pic + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            pic = pic + "<CreateTime>1348831860</CreateTime>";
            pic = pic + "<MsgType><![CDATA[news]]></MsgType>";
            pic = pic + "<ArticleCount>" + _List.Count + "</ArticleCount>";
            pic = pic + "<Articles>";
            for (int i = 0; i < _List.Count; i++)
            {
                pic = pic + "<item>";
                pic = pic + "<Title><![CDATA[" + _List[i].Title + "]]></Title>";
                pic = pic + "<Description><![CDATA[" + _List[i].Introduce + "]]></Description>";
                pic = pic + "<PicUrl><![CDATA[" + _List[i].Thumbnails + "]]></PicUrl>";
                pic = pic + "<Url><![CDATA[" + ConfigurationManager.AppSettings["activityfoodinfourl"] + _List[i].Id + "]]></Url>";
                pic = pic + "</item>";
            }
            pic = pic + "</Articles>";
            pic = pic + "<FuncFlag>1</FuncFlag>";
            pic = pic + "</xml>";
            return pic;
        }
        /// <summary>
        /// 回复图文消息列表
        /// </summary>
        /// <param name="_List">List类型的news消息，具体参照news类</param>
        /// <param name="UserOpenId">要发送用户的openid</param>
        /// <param name="DevOpenId">开发者的微信号</param>
        /// <returns></returns>
        public static string ResponseEduPic(List<Articles> _List, string UserOpenId, string DevOpenId, string newdate)
        {
            string pic = "<xml>";
            pic = pic + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            pic = pic + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            pic = pic + "<CreateTime>1348831860</CreateTime>";
            pic = pic + "<MsgType><![CDATA[news]]></MsgType>";
            pic = pic + "<ArticleCount>" + _List.Count + "</ArticleCount>";
            pic = pic + "<Articles>";
            for (int i = 0; i < _List.Count; i++)
            {
                pic = pic + "<item>";
                pic = pic + "<Title><![CDATA[" + _List[i].Title + "]]></Title>";
                pic = pic + "<Description><![CDATA[" + _List[i].Introduce + "]]></Description>";
                pic = pic + "<PicUrl><![CDATA[" + _List[i].Thumbnails + "]]></PicUrl>";
                pic = pic + "<Url><![CDATA[" + ConfigurationManager.AppSettings["activityeduinfourl"] + _List[i].Id + "]]></Url>";
                pic = pic + "</item>";
            }
            pic = pic + "</Articles>";
            pic = pic + "<FuncFlag>1</FuncFlag>";
            pic = pic + "</xml>";
            return pic;
        }
        /// <summary>
        /// 发送图文消息

        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public static string ResponsePicNews(PicNewsModel model, string UserOpenId, string DevOpenId)
        {
            string pic = "<xml>";
            pic = pic + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            pic = pic + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            pic = pic + "<CreateTime>1348831860</CreateTime>";
            pic = pic + "<MsgType><![CDATA[news]]></MsgType>";
            pic = pic + "<ArticleCount>1</ArticleCount>";
            pic = pic + "<Articles>";
            pic = pic + "<item>";
            pic = pic + "<Title><![CDATA[" + model.title + "]]></Title>";
            pic = pic + "<Description><![CDATA[" + model.description + "]]></Description>";
            pic = pic + "<PicUrl><![CDATA[" + model.picurl + "]]></PicUrl>";
            pic = pic + "<Url><![CDATA[" + model.url + "]]></Url>";
            pic = pic + "</item>";
            pic = pic + "</Articles>";
            pic = pic + "<FuncFlag>1</FuncFlag>";
            pic = pic + "</xml>";
            return pic;
        }
        /// <summary>
        /// 回复文本消息
        /// </summary>
        /// <param name="content">回复内容</param>
        /// <param name="UserOpenId">用户的openid</param>
        /// <param name="DevOpenId">开发者的微信号</param> 
        /// <returns></returns>
        public static string ResponseKeFu(string UserOpenId, string DevOpenId)
        {
            string Txt = "<xml>";
            Txt = Txt + "<ToUserName><![CDATA[" + UserOpenId + "]]></ToUserName>";
            Txt = Txt + "<FromUserName><![CDATA[" + DevOpenId + "]]></FromUserName>";
            Txt = Txt + "<CreateTime>1348831860</CreateTime>";
            Txt = Txt + "<MsgType><![CDATA[transfer_customer_service]]></MsgType>";
            Txt = Txt + "</xml>";
            return Txt;
        }

    }
}
