﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class WXEventModel : WXModel
    {
        /// <summary>
        /// 事件类型
        /// </summary>
        public string Event { get; set; }

        /// <summary>
        /// 事件KEY值 V1001_Pretty：本期特惠; V1002_Card:会员卡;V1002_Right:会员权益;V1002_Method:会员卡使用方法
        /// </summary>
        public string EventKey { get; set; }
    }
}
