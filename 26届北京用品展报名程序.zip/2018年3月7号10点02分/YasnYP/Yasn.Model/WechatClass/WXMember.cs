﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public class WXMember
    {

        /// <summary>
        /// Id
        /// </summary>		
        public static string FIELDId = "Id";

        /// <summary>
        /// 姓名
        /// </summary>		
        public static string FIELDUserName = "UserName";

        /// <summary>
        /// 手机
        /// </summary>		
        public static string FIELDMobile = "Mobile";

        /// <summary>
        /// 微信号
        /// </summary>		
        public static string FIELDWXNo = "WXNo";

        /// <summary>
        /// CreateDate
        /// </summary>		
        public static string FIELDCreateDate = "CreateDate";

        /// <summary>
        /// 会员编号
        /// </summary>		
        public static string FIELDMemberNo = "MemberNo";

        /// <summary>
        /// 公司名称
        /// </summary>
        public static string FIELDCompanyName = "CompanyName";

        /// <summary>
        /// 卡号          
        /// </summary>
        public static string FIELDcard = "card";
        /// <summary>
        /// 卡号URL
        /// </summary>
        public static string FIELDcardimageurl = "cardimageurl";
        /// <summary>
        /// 类型
        /// </summary>
        public static string FIELDcardtype = "cardtype";


        /// <summary>
        /// Id
        /// </summary>		
        public int Id
        {
            get;
            set;
        }
        /// <summary>
        /// 姓名
        /// </summary>	
        public string UserName
        {
            get;
            set;
        }
        /// <summary>
        /// 手机
        /// </summary>	
        public string Mobile
        {
            get;
            set;
        }
        /// <summary>
        /// 微信号
        /// </summary>	
        public string WXNo
        {
            get;
            set;
        }
        /// <summary>
        /// CreateDate
        /// </summary>	
        public DateTime CreateDate
        {
            get;
            set;
        }
        /// <summary>
        /// 会员编号
        /// </summary>	
        public long MemberNo
        {
            get;
            set;
        }

        /// <summary>
        /// 会员自增ID
        /// </summary>	
        public long Zhanhuiguanlian_ID
        {
            get;
            set;
        }

        /// <summary>
        /// 公司名称
        /// </summary>
        public string CompanyName
        {
            get;
            set;
        }


        public string Activity
        {
            get;
            set;
        }

        public string ContactId
        {
            get;
            set;
        }
        public string card
        {
            get;
            set;
        }
        public string cardimageurl
        {
            get;
            set;
        }
        public string cardtype
        {
            get;
            set;
        }
    }
}
