﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model.WechatClass
{
    public abstract class WXModel
    {

        /// <summary>
        /// 开发者微信号
        /// </summary>
        public string ToUserName { get; set; }

        /// <summary>
        /// 发送方帐号
        /// </summary>
        public string FromUserName { get; set; }

        /// <summary>
        /// 消息创建时间
        /// </summary>
        public string CreateTime { get; set; }

        /// <summary>
        /// text 文本,image 图片,location 位置,link 连接,event 事件推送
        /// </summary>
        public string MsgType { get; set; }

    }
}
