﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class ZhanHuiBiaoXiaoModel
    {
        /// <summary>
        /// Id
        /// </summary>		
        public int Id
        {
            get;
            set;
        }
        /// <summary>
        /// 展会ID
        /// </summary>	
        public int zhanhuiid
        {
            get;
            set;
        }
        /// <summary>
        /// 微信用户ID
        /// </summary>	
        public string WXNo
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>	
        public string name
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>	
        public string mobil
        {
            get;
            set;
        }
        /// <summary>
        /// 
        /// </summary>	
        public string bxbm
        {
            get;
            set;
        }
        /// <summary>
        /// 注册时间
        /// </summary>
        public DateTime createdatetime
        { get; set; }
    }
}
