﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class ZhanHuiGuanLianModel : ICloneable
    {
        /// <summary>
        /// Id
        /// </summary>		
        public int Id
        {
            get;
            set;
        }
        /// <summary>
        /// 展会ID
        /// </summary>	
        public int zhanhuiid
        {
            get;
            set;
        }
        /// <summary>
        /// 微信用户ID
        /// </summary>	
        public int vxmenberid
        {
            get;
            set;
        }
        /// <summary>
        /// 联系人ID
        /// </summary>	
        public string ContactId
        {
            get;
            set;
        }
        /// <summary>
        /// 用户openid
        /// </summary>
        public string WeiXinOpenId
        {
            get;set;
        }
        /// <summary>
        /// 是否同步
        /// </summary>	
        public bool shifoutb
        {
            get;
            set;
        }
        /// <summary>
        /// 注册时间
        /// </summary>
        public DateTime createtime
        {
            get;
            set;
        }
        /// <summary>
        /// 负责人
        /// </summary>
        public string owneridname
        {
            get;
            set;
        }
        /// <summary>
        /// 卡号
        /// </summary>
        public string card
        {
            get;
            set;
        }
        /// <summary>
        /// 图片地址
        /// </summary>
        public string cardimageurl
        {
            get;
            set;
        }
        /// <summary>
        /// 卡号类别
        /// </summary>
        public int cardtype
        {
            get;
            set;
        }
        /// <summary>
        /// 手机
        /// </summary>
        public string phone
        {
            get;
            set;
        }
        /// <summary>
        /// 姓名
        /// </summary>
        public string name
        {
            get;
            set;
        }
        /// <summary>
        /// 公司名称
        /// </summary>
        public string cjiname
        {
            get;
            set;
        }
        /// <summary>
        /// 职务
        /// </summary>
        public string job
        {
            get;
            set;
        }
        /// <summary>
        /// 所属行业
        /// </summary>
        public string IndustryOwend
        {
            get;set;
        }
        /// <summary>
        /// 主营业务
        /// </summary>
        public string ManageType
        {
            get;set;
        }
        /// <summary>
        /// 兴趣活动
        /// </summary>
        public string EnjoyProduct
        {
            get;set;
        }
        /// <summary>
        /// 邮件
        /// </summary>
        public string email
        {
            get;
            set;
        }
        /// <summary>
        /// 同期活动
        /// </summary>
        public string tqhd
        {
            get;
            set;
        }
        /// <summary>
        /// 我要报销和礼品二进制组合
        /// </summary>
        public int gift
        {
            set;
            get;
        }

        /// <summary>
        /// 报名渠道
        /// </summary>
        public string Channel
        {
            set;
            get;
        }

        /// <summary>
        /// 他方映射ID
        /// </summary>
        public long MapID
        {
            set;
            get;
        }
        /// <summary>
        /// 他方传入的展商对应ID
        /// </summary>
        public int ExhibitorId
        {
            set;
            get;
        }

        /// <summary>
        /// 喜好分类
        /// </summary>
        public string ProType
        {
            set;

            get;

        }

        /// <summary>
        /// 参展人员
        /// </summary>
        public int IsZS
        {
            set;
            get;
        }

        /// <summary>
        /// 首选人员
        /// </summary>
        public int LeadId
        {
            set;
            get;
        }

        /// <summary>
        /// 公司座机
        /// </summary>
        public string Telephone
        {
            set;
            get;
        }

        /// <summary>
        /// 参与展会
        /// </summary>
        public string YXZhanhui
        {
            set;
            get;
        }
        /// <summary>
        /// 答题信息（20170523 教育展览添加字段）
        /// </summary>
        public string AnswerInfo
        {
            set;
            get;
        }
        /// <summary>
        /// 主营业务(20170624 广州展览添加字段)
        /// </summary>
        public string MainBusine
        {
            get;
            set;
        }
        /// <summary>
        /// 单位性质
        /// </summary>
        public string AccountType
        {
            get;
            set;
        }
        public int IsGift { get; set; }

        #region ICloneable 成员

        public object Clone()
        {
            MemoryStream ms = new MemoryStream();
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(ms, this);
            ms.Position = 0;
            return formatter.Deserialize(ms);
        }

        #endregion
    }
}
