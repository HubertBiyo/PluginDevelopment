﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Model
{
    public class Zhanhui
    {
        /// <summary>
        /// 展会Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// 展会名称
        /// </summary>
        public string ZhanhuiName { get; set; }
        /// <summary>
        /// 是否当前展会
        /// </summary>
        public bool Shifoudangqianzh { get; set; }
    }
}
