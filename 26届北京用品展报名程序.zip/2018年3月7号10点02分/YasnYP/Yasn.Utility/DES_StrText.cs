﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Utility
{
    public class DES_StrText
    {
        private static byte[] Keys = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private static string Key = ConfigurationManager.AppSettings["decryptKey"];
        /// <summary> 
        /// 加密 
        /// </summary> 
        /// <param name="strText"></param> 
        /// <returns></returns> 
        public static string Encrypt(string strText)
        {
            try
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(Key.Substring(0, 8));
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Encoding.UTF8.GetBytes(strText);
                DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Convert.ToBase64String(mStream.ToArray());
            }
            catch
            {
                return strText;
            }
        }
        /// <summary> 
        /// 解密 
        /// </summary> 
        /// <param name="strText"></param> 
        /// <returns></returns> 
        public static string Decrypt(string strText)
        {
            try
            {
                byte[] rgbKey = Encoding.UTF8.GetBytes(Key);
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Convert.FromBase64String(strText);
                DESCryptoServiceProvider DCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, DCSP.CreateDecryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Encoding.UTF8.GetString(mStream.ToArray());
            }
            catch
            {
                return strText;
            }
        }
    }
}
