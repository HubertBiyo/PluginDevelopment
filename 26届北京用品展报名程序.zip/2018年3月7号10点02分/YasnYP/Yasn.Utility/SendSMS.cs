﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Yasn.Utility
{
    public class SendSMS
    {
        private static Dictionary<MessageChannel, MyCertificate> dic = new Dictionary<MessageChannel, MyCertificate>();


        static SendSMS()
        {
            dic.Add(MessageChannel.GaiZhuang, new MyCertificate()
            {
                UserName = "SDK-BBX-010-25236",
                Password = "f@62a8@4a97"
            });

            dic.Add(MessageChannel.GuangZhou, new MyCertificate()
            {
                UserName = "SDK-BBX-010-25237",
                Password = "dc@d18d@409"
            });
            dic.Add(MessageChannel.BeiJing, new MyCertificate()
            {
                UserName = "SDK-BBX-010-19109",
                Password = "147e@3eb"
            });
            dic.Add(MessageChannel.JiaoYu, new MyCertificate()
            {
                UserName = "SDK-BBX-010-23175",
                Password = "43aa6E83"
            });
            dic.Add(MessageChannel.GaiZhuangSucess, new MyCertificate()
            {
                UserName = "SDK-BBX-010-25238",
                Password = "637C4a3-43e"
            });
            dic.Add(MessageChannel.GuangZhouSucess, new MyCertificate()
            {
                UserName = "SDK-BBX-010-25239",
                Password = "B-Bc01-4f1a"
            }); dic.Add(MessageChannel.BeiJingSucess, new MyCertificate()
            {
                UserName = "SDK-BBX-010-23400",
                Password = "97a33d-C"
            }); dic.Add(MessageChannel.JiaoYuSucess, new MyCertificate()
            {
                UserName = "SDK-BBX-010-23394",
                Password = "9-60_c-4"
            });

        }
        /// <summary>
        /// 生成验证码短信内容(教育展)
        /// </summary>
        /// <param name="smscode">验证码</param>
        /// <returns></returns>
        public static string SMSContent(ref int smscode)
        {
            string smscont = ConfigurationManager.AppSettings["smscode"];
            if (smscode > 0)
            {
                smscont = string.Format(smscont, smscode);
            }
            else
            {
                Random ra = new Random();
                smscode = ra.Next(100001, 999999);
                smscont = string.Format(smscont, smscode);
            }
            return smscont;
        }
        /// <summary>
        /// 生成验证码短信内容(广州展25)
        /// </summary>
        /// <param name="smscode">验证码</param>
        /// <returns></returns>
        public static string SMSContentGZZ(ref int smscodeGZZ)
        {
            string smscont = ConfigurationManager.AppSettings["smscodeGZZ"];
            if (smscodeGZZ > 0)
            {
                smscont = string.Format(smscont, smscodeGZZ);
            }
            else
            {
                Random ra = new Random();
                smscodeGZZ = ra.Next(100001, 999999);
                smscont = string.Format(smscont, smscodeGZZ);
            }
            return smscont;
        }
        /// <summary>
        /// 发送短信方法
        /// </summary>
        /// <param name="mobile">手机</param>
        /// <param name="content">内容</param>
        /// <param name="ext"></param>
        /// <returns></returns>
        public static string SendSingleSMS(string mobile, string content, string ext)
        {
            try
            {
                SMSSend.WebServiceSoapClient _webclient = new SMSSend.WebServiceSoapClient();
                //MD5加密密码
                string sn = "SDK-BBX-010-23175";
                string password = "43aa6E83";
                string pwd = getMD5(sn + password);

                string s = _webclient.mdSmsSend(sn, pwd, mobile, content, ext, "", "");
                return s;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }
        /// <summary>
        /// 发送短信方法
        /// </summary>
        /// <param name="mobile">手机</param>
        /// <param name="content">内容</param>
        /// <param name="ext"></param>
        /// <param name="channel">调用通道</param>
        /// <returns></returns>
        public static string SendSingleSMS(string mobile, string content, string ext, MessageChannel channel)
        {

            try
            {
                SMSSend.WebServiceSoapClient _webclient = new SMSSend.WebServiceSoapClient();
                //MD5加密密码
                string sn = dic[channel].UserName;
                string password = dic[channel].Password;
                string pwd = getMD5(sn + password);

                string s = _webclient.mdSmsSend(sn, pwd, mobile, content, ext, "", "");
                Utils.WriteLog(mobile + "|" + s + "|" + DateTime.Now);
                return s;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        /// <summary>
        /// 获取md5码
        /// </summary>
        /// <param name="source">待转换字符串</param>
        /// <returns>md5加密后的字符串</returns>
        public static string getMD5(string source)
        {
            string result = "";
            try
            {
                MD5 getmd5 = new MD5CryptoServiceProvider();
                byte[] targetStr = getmd5.ComputeHash(UnicodeEncoding.UTF8.GetBytes(source));
                result = BitConverter.ToString(targetStr).Replace("-", "");
                return result;
            }
            catch (Exception)
            {
                return "0";
            }

        }


    }

    public enum MessageChannel
    {
        /// <summary>
        /// 改装展验证码
        /// </summary>
        GaiZhuang = 1,
        /// <summary>
        /// 广州展验证码
        /// </summary>
        GuangZhou = 2,
        /// <summary>
        /// 北京展验证码
        /// </summary>
        BeiJing = 3,
        /// <summary>
        /// 教育展验证码
        /// </summary>
        JiaoYu = 4,
        /// <summary>
        /// 改装展成功
        /// </summary>
        GaiZhuangSucess = 5,
        /// <summary>
        /// 广州展成功
        /// </summary>
        GuangZhouSucess = 6,
        /// <summary>
        /// 北京展成功
        /// </summary>
        BeiJingSucess = 7,
        /// <summary>
        /// 教育展成功
        /// </summary>
        JiaoYuSucess = 8
    }
    public class MyCertificate
    {
        public string UserName;
        public string Password;
    }
}
