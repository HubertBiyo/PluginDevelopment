﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Yasn.Utility
{
    public enum FinishStyle : int { Succeed = 1, Error = 2 }
    public class Utils
    {
        #region 日志
        /// <summary>
        /// 写入日志
        /// </summary>
        /// <param name="message">日志内容</param>
        public static void WriteLog(string message)
        {
            WriteLog(message, "txt");
        }
        public static void WriteLog1(string message)
        {
            WriteLog1(message, "txt");
        }

        // 写入日志
        private static void WriteLog(string message, string fileType)
        {
            string folder = HttpContext.Current.Server.MapPath("~/Logs/") + DateTime.Now.ToString("yyyyMM") + @"/";
            string file = string.Format("{0}{1}.{2}", folder, DateTime.Now.ToString("yyyyMMdd"), fileType);
            message = string.Format("[{0}][{1}][{2}]:{3}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), HttpContext.Current.Request.Url.LocalPath, HttpContext.Current.Request.UserHostAddress, message);

            try
            {
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                StreamWriter sw;

                if (!File.Exists(file))
                {
                    sw = File.CreateText(file);
                    sw.Close();
                }

                sw = new StreamWriter(file, true, Encoding.Default);
                sw.WriteLine(message);
                sw.Close();
            }
            catch (Exception ex)
            {
                //throw new Exception("write log error.");
                HttpContext.Current.Response.Write(string.Format("日志写入失败, ex={0}。", ex.Message));
            }
        }
        private static void WriteLog1(string message, string fileType)
        {
            string folder = HttpContext.Current.Server.MapPath("~/Logs1/") + DateTime.Now.ToString("yyyyMM") + @"/";
            string file = string.Format("{0}{1}.{2}", folder, DateTime.Now.ToString("yyyyMMdd"), fileType);
            message = string.Format("[{0}][{1}][{2}]:{3}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), HttpContext.Current.Request.Url.LocalPath, HttpContext.Current.Request.UserHostAddress, message);

            try
            {
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }

                StreamWriter sw;

                if (!File.Exists(file))
                {
                    sw = File.CreateText(file);
                    sw.Close();
                }

                sw = new StreamWriter(file, true, Encoding.Default);
                sw.WriteLine(message);
                sw.Close();
            }
            catch (Exception ex)
            {
                //throw new Exception("write log error.");
                HttpContext.Current.Response.Write(string.Format("日志写入失败, ex={0}。", ex.Message));
            }
        }
        #endregion

        #region xml

        // 写入Xml
        public static void WriteToXml(string message, string file)
        {
            try
            {
                StreamWriter sw;

                if (!File.Exists(file))
                {
                    sw = File.CreateText(file);
                    sw.Close();
                }

                sw = new StreamWriter(file, false, Encoding.UTF8);//
                sw.WriteLine(message);
                sw.Close();
            }
            catch (Exception ex)
            {
                //throw new Exception("write log error.");
                HttpContext.Current.Response.Write(string.Format("日志写入失败, ex={0}。", ex.Message));
            }
        }
        #endregion

        #region SQL注入
        /// <summary>
        /// 检验SQL注入
        /// </summary>
        /// <param name="key">参数</param>
        /// <param name="val">值</param>
        public static bool CheckBadSql()
        {
            HttpContext ctx = HttpContext.Current;
            string[] path = ctx.Request.Url.AbsolutePath.ToLower().Split('/');
            string page = path[path.Length - 1];

            //if (Config.SqlExceptionPage != "")
            //{
            //    if (Regex.IsMatch(page, Config.SqlExceptionPage, RegexOptions.IgnoreCase))
            //    {
            //        return;
            //    }
            //}

            foreach (string querystring in ctx.Request.QueryString)
            {
                if (querystring == "__VIEWSTATE" || querystring == "__EVENTVALIDATION")
                {
                    continue;
                }

                if (Regex.IsMatch(ctx.Request[querystring], @"select|\sand\s|insert|delete|count\(|drop table|update|truncate|asc\(|mid\(|char\(|xp_cmdshell|exec master|netlocalgroup administrators|net user", RegexOptions.IgnoreCase))
                {
                    WriteLog(string.Format("非法SQL注入 key={0}, val={1}", querystring, ctx.Request[querystring]));
                    //GoFinish("非法字符！");
                    return false;
                }
            }

            //foreach (string form in ctx.Request.Form)
            //{
            //    if (Regex.IsMatch(ctx.Request.Form[form], @"select|and|insert|delete|from|count\(|drop table|truncate|asc\(|mid\(|char\(|xp_cmdshell|exec master|netlocalgroup administrators|net user", RegexOptions.IgnoreCase))
            //    {
            //        WriteLog(string.Format("非法SQL注入 key={0}, val={1}", form, ctx.Request.Form[form]));
            //        //GoFinish("非法字符！");
            //        return false;
            //    }
            //}
            return true;
        }
        #endregion

        #region 跳转到完成页
        private static void GoFinish(string finishPage, string message, FinishStyle style, string returnUrl)
        {
            HttpContext.Current.Response.Redirect(string.Format(
                "{0}?message={1}&style={2}&url={3}",
                finishPage,
                message,
                Convert.ToInt32(style),
                returnUrl
            ));
        }

        /// <summary>
        ///  跳转到完成页
        /// </summary>
        /// <param name="message"></param>
        /// <param name="style"></param>
        /// <param name="returnUrl"></param>
        public static void GoFinish(string message, FinishStyle style, string returnUrl)
        {
            string[] urls = HttpContext.Current.Request.Url.AbsolutePath.ToLower().Split('/');
            string finishPage = urls.Length > 2 && urls[1] == "admin" ? string.Format("/{0}/finish.aspx", "Admin") : "finish.aspx";
            GoFinish(finishPage, message, style, returnUrl);
        }

        /// <summary>
        /// 跳转到完成页后回到本页


        /// </summary>
        /// <param name="message"></param>
        /// <param name="style"></param>
        public static void GoFinish(string message, FinishStyle style)
        {
            string url = "";
            string orginal = HttpContext.Current.Request.Url.PathAndQuery.ToLower();
            string[] urls = orginal.Split('/');

            if (urls.Length > 2 && urls[1] == "admin")
            {
                for (int i = 0; i < urls.Length; i++)
                {
                    url += (i == 1 ? "Admin" : urls[i]);
                    if (i < urls.Length - 1)
                    {
                        url += "/";
                    }
                }
            }
            else
            {
                url = orginal;
            }

            GoFinish(message, style, HttpContext.Current.Server.UrlEncode(url));
        }

        /// <summary>
        /// 跳转到完成页, 用于成功提示
        /// </summary>
        /// <param name="message">提示信息</param>
        /// <param name="url">返回地址</param>
        public static void GoFinish(string message, string url)
        {
            GoFinish(message, FinishStyle.Succeed, url);
        }

        /// <summary>
        /// 跳转到完成页, 用于没有跳转的错误提示


        /// </summary>
        /// <param name="message"></param>
        public static void GoFinish(string message)
        {
            GoFinish(message, FinishStyle.Error, "");
        }
        #endregion

        #region 类型判断
        /// <summary>
        /// 判断对象是否为Int32类型的数字


        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsNumeric(string expression)
        {
            if (!string.IsNullOrEmpty(expression))
            {
                string str = expression;
                if (str.Length > 0 && str.Length <= 11 && Regex.IsMatch(str, @"^[-]?[0-9]*[.]?[0-9]*$"))
                {
                    if ((str.Length < 10) || (str.Length == 10 && str[0] == '1') || (str.Length == 11 && str[0] == '-' && str[1] == '1'))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// 判断对象是否为datatime类型
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static bool IsDateTime(string expression)
        {
            if (string.IsNullOrEmpty(expression))
            {
                return false;
            }

            try
            {
                DateTime temp = Convert.ToDateTime(expression);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region QueryStrng类型化方法


        /// <summary>
        ///  获取字符串形式的url参数
        /// </summary>
        /// <param name="key"></param>
        /// <param name="def"></param>
        /// <returns></returns>
        public static string GetQueryStringChar(string key, string def)
        {
            System.Web.HttpContext ctx = System.Web.HttpContext.Current;

            if (ctx.Request.QueryString[key] == null)
            {
                return def;
            }

            return ctx.Server.UrlDecode(ctx.Request.QueryString[key]);
        }

        /// <summary>
        ///  获取数值形式的url参数
        /// </summary>
        /// <param name="key"></param>
        /// <param name="def"></param>
        /// <returns></returns>
        public static int GetQueryStringInt(string key, int def)
        {
            System.Web.HttpContext ctx = System.Web.HttpContext.Current;

            if (ctx.Request.QueryString[key] == null)
            {
                return def;
            }
            else if (!IsNumeric(ctx.Request.QueryString[key]))
            {
                return def;
            }

            return Convert.ToInt32(ctx.Request.QueryString[key]);
        }

        /// <summary>
        /// HttpRequest扩展方法, 获取日期形式的url参数
        /// </summary>
        /// <param name="e"></param>
        /// <param name="key">键</param>
        /// <param name="def">默认值</param>
        /// <returns></returns>
        public static DateTime GetQueryStringDateTime(string key, DateTime def)
        {
            System.Web.HttpContext ctx = System.Web.HttpContext.Current;

            if (ctx.Request.QueryString[key] == null)
            {
                return def;
            }
            else if (!IsDateTime(ctx.Request.QueryString[key]))
            {
                return def;
            }

            return Convert.ToDateTime(ctx.Request.QueryString[key]);
        }

        /// <summary>
        /// HttpRequest扩展方法, 获取日期形式的url参数
        /// </summary>
        /// <param name="key"></param>
        /// <param name="appentDayEnd"></param>
        /// <returns></returns>
        public static string GetQueryStringDateTime(string key, string def, bool appentDayEnd)
        {
            System.Web.HttpContext ctx = System.Web.HttpContext.Current;

            if (ctx.Request.QueryString[key] == null)
            {
                return def;
            }
            else if (!IsDateTime(ctx.Request.QueryString[key]))
            {
                return def;
            }

            string val = ctx.Request.QueryString[key];

            if (appentDayEnd)
            {
                val += " 23:59:59";
            }

            return val;
        }
        #endregion

        #region 脚本相关
        //--------------------------------------------原来的-----------------------------------------------------//
        //public static void RegisterAlertScript(System.Web.UI.Page page, string message)
        //{
        //    page.ClientScript.RegisterClientScriptBlock(
        //        typeof(System.Web.UI.Page),
        //        Guid.NewGuid().ToString("N"),
        //        string.Format("<script language='javascript' type='text/javascript'>alert('{0}');</script>", message)
        //    );
        //}

        /// <summary>
        /// 弹出没有指向页面的对话框
        /// </summary>
        ///  <param name="page">当前页面,置为this即可</param>
        ///  <param name="s">对话框提示的内容</param>
        /// <returns></returns>
        public static void RegisterAlertScript(System.Web.UI.Page page, string s)
        {
            string msg = @"<script language=javascript>";
            msg += @"alert('";
            msg += s;
            msg += "');";
            msg += "window.location.href=window.location.href;";
            msg += @"</script>";
            page.Response.Write(msg);
        }

        /// <summary>
        /// 弹出有指向页面的对话框
        /// </summary>
        ///  <param name="s">对话框提示的内容</param>
        ///  <param name="page">当前页面,置为this即可</param>
        ///  <param name="newPage">指向的页面路径</param>
        /// <returns></returns>
        public static void RegisterAlertScript(string s, System.Web.UI.Page page, string newPage)
        {
            string msg = @"<script language=javascript>";
            msg += @"alert('";
            msg += s;
            msg += "');";
            msg += "window.location.href='" + newPage + "';";
            msg += @"</script>";
            page.Response.Write(msg);
        }
        #endregion

        #region 常用正则判断
        /// <summary>
        /// 是否合法用户名


        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsLegalUserName(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^[_0-9a-zA-Z]{4,12}$"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 是否合法密码
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsLegalPassword(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^[_0-9a-zA-Z]{6,12}$"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 是否合法32加密串
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsLegalEncrypt32(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^[0-9a-zA-Z]{32}$"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 是否合法身份证号
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsLegalIdentityCard(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^(([0-9]{14}[x0-9]{1})|([0-9]{17}[x0-9]{1}))$"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 是否合法邮箱
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsLegalEmail(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^.+@.+$"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// 是否中文字符
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static bool IsChineseChar(string val)
        {
            if (val == "" || !Regex.IsMatch(val, @"^[\u4e00-\u9fa5]+$"))
            {
                return false;
            }

            return true;
        }
        #endregion

        public static string AppendUrlParameter(string url, string key, string val)
        {
            if (url.IndexOf("?") > -1)
            {
                url += string.Format("&{0}={1}", key, val);
            }
            else
            {
                url += string.Format("?{0}={1}", key, val);
            }

            return url;
        }



        #region GridView 转换成 DataTable
        /**/
        /// <summary> 
        /// 从GridView的数据生成DataTable 
        /// </summary> 
        /// <param name="gv">GridView对象</param> 
        public static DataTable GridView2DataTable(GridView gv)
        {
            DataTable table = new DataTable();
            int rowIndex = 0;
            List<string> cols = new List<string>();
            if (!gv.ShowHeader && gv.Columns.Count == 0)
            {
                return table;
            }
            GridViewRow headerRow = gv.HeaderRow;
            if (headerRow == null)
            {
                return table;
            }
            int columnCount = headerRow.Cells.Count;
            for (int i = 0; i < columnCount; i++)
            {
                string text = GetCellText(headerRow.Cells[i]);
                cols.Add(text);
            }
            foreach (GridViewRow r in gv.Rows)
            {
                if (r.RowType == DataControlRowType.DataRow)
                {
                    DataRow row = table.NewRow();
                    int j = 0;
                    for (int i = 0; i < columnCount; i++)
                    {
                        string text = GetCellText(r.Cells[i]);
                        if (!String.IsNullOrEmpty(text))
                        {
                            if (rowIndex == 0)
                            {
                                string columnName = cols[i];
                                if (String.IsNullOrEmpty(columnName))
                                {
                                    continue;
                                }
                                if (table.Columns.Contains(columnName))
                                {
                                    continue;
                                }
                                DataColumn dc = table.Columns.Add();
                                dc.ColumnName = columnName;
                                dc.DataType = typeof(string);
                            }
                            row[j] = text;
                            j++;
                        }
                    }
                    rowIndex++;
                    table.Rows.Add(row);
                }
            }
            return table;
        }
        public static string GetCellText(TableCell cell)
        {
            string text = cell.Text;
            if (!string.IsNullOrEmpty(text))
            {
                return text;
            }
            foreach (Control control in cell.Controls)
            {
                if (control != null && control is IButtonControl)
                {
                    IButtonControl btn = control as IButtonControl;
                    text = btn.Text.Replace("\r\n", "").Trim();
                    break;
                }
                if (control != null && control is ITextControl)
                {
                    LiteralControl lc = control as LiteralControl;
                    if (lc != null)
                    {
                        continue;
                    }
                    ITextControl l = control as ITextControl;

                    text = l.Text.Replace("\r\n", "").Trim();
                    break;
                }
            }
            return text;
        }

        #endregion


        #region  Cookie
        public static bool SetCookie(string strName, string strValue, int strDay)
        {
            try
            {
                HttpCookie Cookie = new HttpCookie(strName);
                Cookie.Expires = DateTime.Now.AddDays(strDay);
                Cookie.Value = strValue;
                System.Web.HttpContext.Current.Response.Cookies.Add(Cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SetCookie(string strName, string strValue)
        {
            try
            {
                HttpCookie Cookie = new HttpCookie(strName);
                Cookie.Domain = HttpContext.Current.Request.Url.Host;
                Cookie.Value = strValue;
                System.Web.HttpContext.Current.Response.Cookies.Add(Cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool SetCookieSeconds(string strName, string strValue, int strSeconds)
        {
            try
            {
                HttpCookie Cookie = new HttpCookie(strName);
                Cookie.Expires = DateTime.Now.AddSeconds(strSeconds);
                Cookie.Value = strValue;
                System.Web.HttpContext.Current.Response.Cookies.Add(Cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// Cookie写入
        /// </summary>
        /// <param name="strName">Cookie名称</param>
        /// <param name="KeyName">参数名称</param>
        /// <param name="strValue">参数值</param>
        /// <param name="strDay">存放时间(不传默认30天)</param>
        /// <returns></returns>
        public static bool SetCookie(string strName, string KeyName, string strValue, int strDay = 30)
        {
            try
            {
                if (System.Web.HttpContext.Current.Request.Cookies[strName] != null)
                {
                    HttpCookie Cookie = System.Web.HttpContext.Current.Request.Cookies[strName];
                    Cookie.Expires = DateTime.Now.AddDays(strDay);
                    Cookie.Domain = HttpContext.Current.Request.Url.Host;
                    Cookie.Values.Set(KeyName, strValue);
                    System.Web.HttpContext.Current.Response.AppendCookie(Cookie);
                }
                else
                {
                    HttpCookie Cookie = new HttpCookie(strName);
                    Cookie.Expires = DateTime.Now.AddDays(strDay);
                    Cookie.Domain = HttpContext.Current.Request.Url.Host;
                    Cookie.Values.Add(KeyName, strValue);
                    System.Web.HttpContext.Current.Response.AppendCookie(Cookie);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 写入cookie,过期时间用秒
        /// </summary>
        /// <param name="strName"></param>
        /// <param name="strValue"></param>
        /// <param name="strSec"></param>
        /// <returns></returns>
        public static bool SetCookieBySec(string strName, string strValue, int strSec)
        {
            try
            {
                HttpCookie Cookie = new HttpCookie(strName);
                Cookie.Expires = DateTime.Now.AddSeconds(strSec);
                Cookie.Value = strValue;
                System.Web.HttpContext.Current.Response.Cookies.Add(Cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string GetCookie(string strName)
        {
            HttpCookie Cookie = System.Web.HttpContext.Current.Request.Cookies[strName];
            if (Cookie != null)
            {
                return ChDecodeUrl(Cookie.Value.ToString());
            }
            else
            {
                return null;
            }
        }

        public static string GetCookie(string strName, string KeyName)
        {
            HttpCookie Cookie = System.Web.HttpContext.Current.Request.Cookies[strName];
            if (Cookie != null)
            {
                return ChDecodeUrl(Cookie[KeyName]);
            }
            else
            {
                return null;
            }
        }

        public static bool DelCookie(string strName)
        {
            try
            {
                HttpCookie Cookie = new HttpCookie(strName);
                Cookie.Domain = HttpContext.Current.Request.Url.Host;
                Cookie.Expires = DateTime.Now.AddDays(-1);
                System.Web.HttpContext.Current.Response.Cookies.Add(Cookie);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        ///URLToUTF8
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ChDecodeUrl(string str)
        {
            return System.Web.HttpUtility.UrlDecode(str);
        }

        #endregion
    }
}
