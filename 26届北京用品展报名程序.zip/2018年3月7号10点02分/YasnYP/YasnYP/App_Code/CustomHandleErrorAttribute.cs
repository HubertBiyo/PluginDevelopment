﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace YasnYP.Controllers
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class CustomHandleErrorAttribute : HandleErrorAttribute
    {
        public void writeLogToFile(string strMemo, ExceptionContext exceptionContext)
        {
            if (!Directory.Exists(exceptionContext.RequestContext.HttpContext.Server.MapPath(@"~\logs\")))
            {
                Directory.CreateDirectory(exceptionContext.RequestContext.HttpContext.Server.MapPath(@"~\logs\"));
            }
            string filename = exceptionContext.RequestContext.HttpContext.Server.MapPath(@"~\logs\reglog.txt");
            StreamWriter sr = null;
            try
            {
                if (!System.IO.File.Exists(filename))
                {
                    sr = System.IO.File.CreateText(filename);
                }
                else
                {
                    sr = System.IO.File.AppendText(filename);
                }
                sr.WriteLine(strMemo);
            }
            catch
            {

            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                }
            }
        }
    }
}

