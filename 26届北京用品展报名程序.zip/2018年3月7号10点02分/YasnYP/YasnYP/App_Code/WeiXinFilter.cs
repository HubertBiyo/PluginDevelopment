﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Text;
using System.Collections;
using YasnYP.Controllers;
using Yasn.Model;
using Yasn.Utility;
using Yasn.Logic;

namespace YasnYP
{
    [AttributeUsage(AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class WeiXinFilter : ActionFilterAttribute
    {
        /// <summary>
        /// 是否忽略
        /// </summary>
        public bool IsIgnore
        {
            set;
            get;
        }

        #region IActionFilter 成员，已关注获取openid，未关注提示关注

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!IsIgnore)
            {
                CookieContainer myCookieContainer = new CookieContainer();
                string url = string.Format("https://api.weixin.qq.com/sns/oauth2/access_token?appid={0}&secret={1}&code={2}&grant_type=authorization_code", ConfigurationManager.AppSettings["WeiYuAppId"], ConfigurationManager.AppSettings["WeiYuAppSecret"], filterContext.HttpContext.Request.Params["code"]);

                JObject ja = JObject.Parse(GetWebContent(url, ref myCookieContainer));

                Utils.WriteLog("ja：" + ja.ToString());

                string openid = string.Empty;
                try
                {
                    filterContext.Controller.ViewBag.openId = ja["openid"].ToString();      //获取openid
                    openid = ja["openid"].ToString();
                    Utils.WriteLog("北京用品展openid：" + ja["openid"].ToString());
                }
                catch (Exception ex)
                {
                    filterContext.Controller.ViewBag.openId = Utils.GetCookie("openIDJYNow");
                    openid = Utils.GetCookie("openIDJYNow");
                    Utils.WriteLog("教育openIDJYNow：" + Utils.GetCookie("openIDJYNow") + ex.ToString());
                }
                try
                {
                    //当前微信ID没有关注公众号则跳到关注引导页
                    if (!string.IsNullOrEmpty(openid))
                    {

                        //根据定时任务获取access_token,然后从数据库中读取access_token
                        string myToken = GetGongZhongHaoToken();
                        url = string.Format("https://api.weixin.qq.com/cgi-bin/user/info?access_token={0}&openid={1}&lang=zh_CN", myToken, openid);
                        myCookieContainer = new CookieContainer();

                        ja = JObject.Parse(GetWebContent(url, ref myCookieContainer));
                        string flag = ja["subscribe"].ToString();//获取到则为已关注，异常则为没关注(如果为0，则没关注)

                        if (flag.Trim() == "0")
                        {
                            filterContext.HttpContext.Response.Redirect("http://mp.weixin.qq.com/s?__biz=MzI3NjIzMzQ1OQ==&mid=100002143&idx=1&sn=54bbeeb761ae946b850d634c155be78c&chksm=6b79e4c35c0e6dd518b15f03ef4838787f8517989f2af665e53d67645d950681564d7fb39d9c#rd", true);
                        }
                        else
                        {
                            Utils.WriteLog("北京用品用户已关注：" + flag);
                        }
                        
                    }
                    else
                    {
                        Utils.WriteLog("获取关注参数前openid为空：");
                        filterContext.HttpContext.Response.Redirect("http://mp.weixin.qq.com/s?__biz=MzI3NjIzMzQ1OQ==&mid=100002143&idx=1&sn=54bbeeb761ae946b850d634c155be78c&chksm=6b79e4c35c0e6dd518b15f03ef4838787f8517989f2af665e53d67645d950681564d7fb39d9c#rd", true);
                    }
                }
                catch (Exception ex)
                {
                    Utils.WriteLog("展览用户异常：" + ex.StackTrace);
                    filterContext.HttpContext.Response.Redirect("http://mp.weixin.qq.com/s?__biz=MzI3NjIzMzQ1OQ==&mid=100002143&idx=1&sn=54bbeeb761ae946b850d634c155be78c&chksm=6b79e4c35c0e6dd518b15f03ef4838787f8517989f2af665e53d67645d950681564d7fb39d9c#rd", true);
                }
            }

        }
        /// <summary>
        /// 获取公众号token
        /// </summary>
        /// <param name="filterContext"></param>ActionFilterAttribute
        /// <returns></returns>
        private string GetGongZhongHaoToken()
        {
            //获取access_token,如果为空则从新获取
            string token = "";
            //获取数据库中的token
            token = Yasn.Logic.CarAccessoryWXMember.GetToken();
            return token;
        }
        private string GetWebContent(string url, ref CookieContainer myCookieContainer)
        {
            string curNewUrl = string.Empty;
            string html = string.Empty;
            HttpWebRequest req = null;
            //如果是发送HTTPS请求  
            if (url.StartsWith("https", StringComparison.OrdinalIgnoreCase))
            {
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(CheckValidationResult);
                req = WebRequest.Create(url) as HttpWebRequest;
                req.ProtocolVersion = HttpVersion.Version10;
            }
            req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "Post";
            req.AllowAutoRedirect = false;
            req.KeepAlive = true;
            req.UserAgent = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";
            req.Accept = "text/html,application/xhtml+xml,*/*";
            req.CookieContainer = myCookieContainer;
            req.ContentType = "application/x-www-form-urlencoded";

            using (HttpWebResponse wr = (HttpWebResponse)req.GetResponse())
            {
                wr.Cookies = req.CookieContainer.GetCookies(req.RequestUri);
                curNewUrl = wr.ResponseUri.OriginalString;
                myCookieContainer.Add(wr.Cookies);
                List<Cookie> cookies = GetAllCookies(myCookieContainer);
                myCookieContainer = new CookieContainer();
                for (int i = 0; i < cookies.Count; i++)
                {
                    myCookieContainer.Add(cookies[i]);
                }
                Stream responseStream = wr.GetResponseStream();
                StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);

                html = streamReader.ReadToEnd();

            }

            return html;
        }

        public List<Cookie> GetAllCookies(CookieContainer cc)
        {
            List<Cookie> lstCookies = new List<Cookie>();

            Hashtable table = (Hashtable)cc.GetType().InvokeMember("m_domainTable", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, cc, new object[] { });
            StringBuilder sb = new StringBuilder();
            foreach (object pathList in table.Values)
            {
                SortedList lstCookieCol = (SortedList)pathList.GetType().InvokeMember("m_list", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, pathList, new object[] { });
                foreach (CookieCollection colCookies in lstCookieCol.Values)
                    foreach (Cookie c in colCookies)
                    {
                        lstCookies.Add(c);
                    }
            }

            return lstCookies;
        }

        private static bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true; //总是接受  
        }

        #endregion
    }
}