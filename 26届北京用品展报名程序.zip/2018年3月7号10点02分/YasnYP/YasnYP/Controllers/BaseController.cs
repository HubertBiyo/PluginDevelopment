﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using System.Collections;
using System.Text;
using System.IO;
using System.Configuration;
using System.Web.Mvc;
using System.Data.SqlClient;
using Yasn.Utility;
using System.Data;

namespace YasnYP.Controllers
{
    public class BaseController : Controller
    {
        /// <summary>
        /// 获取某个app的公众号token
        /// </summary>
        /// <param name="AppId"></param>
        /// <param name="AppSecret"></param>
        /// <returns></returns>
        private object GetGongZhongHaoTokenParam(string AppId, string AppSecret)
        {
            System.Web.Caching.Cache objCache = HttpContext.Cache;

            object myToken = objCache["access_token"];


            //无效
            if (myToken == null)
            {
                CookieContainer myCookieContainer = new CookieContainer();
                string url = string.Format("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={0}&secret={1}", AppId, AppSecret);
                JObject ja = JObject.Parse(GetWebContent(url, ref myCookieContainer));

                string gzstr = "";
                bool hasErr = ja.Properties().Any(p => p.Name == "errcode");
                IEnumerable<JProperty> properties = ja.Properties();
                foreach (JProperty item in properties)
                {
                    gzstr += item.Name + ":" + item.Value + "||";
                }
                string token = ja["access_token"].ToString();
                int expires = int.Parse(ja["expires_in"].ToString());
                objCache.Insert("access_token", token, null, DateTime.Now.AddSeconds(expires - 1000), System.Web.Caching.Cache.NoSlidingExpiration);
                myToken = objCache["access_token"];

                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("insert into TokenInfo(");
                    strSql.Append("access_token,expiretime");
                    strSql.Append(") values (");
                    strSql.Append("@access_token,@expiretime");
                    strSql.Append(");Select @@Identity;");

                    SqlParameter[] parameters = {
                        new SqlParameter("@access_token", SqlDbType.NVarChar,350) ,
                        new SqlParameter("@expiretime", SqlDbType.DateTime)
                     };

                    parameters[0].Value = token;
                    parameters[1].Value = DateTime.Now.AddSeconds(expires - 2000);

                    object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);

                    if (obj == null)
                    {

                    }
                    else
                    {
                        Utils.WriteLog("获取成功新增入TokenInfo|" + DateTime.Now + gzstr);
                    }

                }
                catch (Exception ex)
                {
                    Utils.WriteLog("新增异常" + ex.Message);
                }
            }


            return myToken;


        }
        /// <summary>
        /// 做一个定时任务 获取access_token
        /// </summary>
        /// <returns></returns>
        private string GetAccess_Token()
        {
            //获取access_token,如果为空则从新获取
            string token = "";
            //获取数据库中的token
            token = Yasn.Logic.CarAccessoryWXMember.GetToken();
            return token;
        }
        /// <summary>
        /// 获取公众号身份信息
        /// </summary>
        /// <param name="flag"></param>
        /// <param name="curUrl"></param>
        public void GetShare(string flag, string curUrl, object myToken_Cpb, DateTime InvalidTime,int leadid)
        {
            System.Web.Caching.Cache objCache = HttpContext.Cache;
            string AppId = "";
            string AppSecret = "";
            if (flag == "Yasn-YongPin")
            {
                ViewBag.AppId = ConfigurationManager.AppSettings["WeiYuAppId"];
                ViewBag.LeadId = leadid;
                AppId = ConfigurationManager.AppSettings["WeiYuAppId"];
                AppSecret = ConfigurationManager.AppSettings["WeiYuAppSecret"];
            }
            Utils.WriteLog("AppId:" + AppId + "AppSecret" + AppSecret);
            DateTime NowTime = System.DateTime.Now;
            //如何当前日期大于失效的日期，则需要重新获取access_token
            object myToken = string.Empty;

            string tokenurl = "https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token=" + myToken_Cpb.ToString();
            CookieContainer myCookieContainer1 = new CookieContainer();
            JObject ja1 = JObject.Parse(GetWebContent(tokenurl, ref myCookieContainer1));
            if (ja1.Property("errcode")!= null && ja1.Property("errcode").ToString()!= "")
            {
                myToken = GetGongZhongHaoTokenParam(AppId, AppSecret);      //在页面动态获取access_token
                Utils.WriteLog("动态获取myToken：" + myToken);
            }
            else
            {
                myToken = myToken_Cpb;
                Utils.WriteLog("获取抛出的access_token：" + myToken);
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into TokenInfo(");
                strSql.Append("access_token,expiretime");
                strSql.Append(") values (");
                strSql.Append("@access_token,@expiretime");
                strSql.Append(");Select @@Identity;");

                SqlParameter[] parameters = {
                            new SqlParameter("@access_token", SqlDbType.NVarChar,350) ,
                            new SqlParameter("@expiretime", SqlDbType.DateTime)
                         };

                parameters[0].Value = myToken_Cpb;
                parameters[1].Value = InvalidTime;

                object obj = DbHelperSQL.GetSingle(strSql.ToString(), parameters);
            }

            object myTicket = objCache["ticket"];
            if (myTicket == null)
            {
                CookieContainer myCookieContainer = new CookieContainer();
                string url = string.Format("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token={0}&type=jsapi", myToken.ToString());
                JObject ja = JObject.Parse(GetWebContent(url, ref myCookieContainer));
                Utils.WriteLog("ja:" + ja);
                string token = ja["ticket"].ToString();
                Utils.WriteLog("url:" + url);
                objCache.Insert("ticket", token, null, DateTime.Now.AddSeconds(3600), System.Web.Caching.Cache.NoSlidingExpiration);
                myTicket = objCache["ticket"];
            }

            ViewBag.Stamp = ConvertDateTimeInt(DateTime.Now);
            ViewBag.Flag = flag;
            string stream = string.Format("jsapi_ticket={0}&noncestr={1}&timestamp={2}&url={3}", (string)myTicket, ViewBag.Flag, ViewBag.Stamp, curUrl);
            Utils.WriteLog("stream参数：" + myTicket + "  " + ViewBag.Flag + "  " + ViewBag.Stamp + "  " + curUrl);
            ViewBag.MySignature = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(stream, "SHA1");
            Utils.WriteLog("ViewBag.AppId：" + ViewBag.AppId + "ViewBag.Stamp" + ViewBag.Stamp + "ViewBag.Flag" + ViewBag.Flag + "ViewBag.MySignature" + ViewBag.MySignature);
        }
        /// <summary>
        /// 将c# DateTime时间格式转换为Unix时间戳格式
        /// </summary>
        /// <param name="time">时间</param>
        /// <returns>long</returns>
        private long ConvertDateTimeInt(System.DateTime time)
        {

            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            long t = (time.Ticks - startTime.Ticks) / 10000; //除10000调整为13位
            return t;
        }

        private string GetWebContent(string url, ref CookieContainer myCookieContainer)
        {
            string curNewUrl = string.Empty;
            string html = string.Empty;
            HttpWebRequest req = null;
            //如果是发送HTTPS请求  
            if (url.StartsWith("https", StringComparison.OrdinalIgnoreCase))
            {
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(CheckValidationResult);
                req = WebRequest.Create(url) as HttpWebRequest;
                req.ProtocolVersion = HttpVersion.Version10;
            }
            req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "Post";
            req.AllowAutoRedirect = false;
            req.KeepAlive = true;
            req.UserAgent = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";
            req.Accept = "text/html,application/xhtml+xml,*/*";
            req.CookieContainer = myCookieContainer;
            req.ContentType = "application/x-www-form-urlencoded";

            using (HttpWebResponse wr = (HttpWebResponse)req.GetResponse())
            {
                wr.Cookies = req.CookieContainer.GetCookies(req.RequestUri);
                curNewUrl = wr.ResponseUri.OriginalString;
                myCookieContainer.Add(wr.Cookies);
                List<Cookie> cookies = GetAllCookies(myCookieContainer);
                myCookieContainer = new CookieContainer();
                for (int i = 0; i < cookies.Count; i++)
                {
                    myCookieContainer.Add(cookies[i]);
                }
                Stream responseStream = wr.GetResponseStream();
                StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);

                html = streamReader.ReadToEnd();

            }

            return html;
        }

        private List<Cookie> GetAllCookies(CookieContainer cc)
        {
            List<Cookie> lstCookies = new List<Cookie>();

            Hashtable table = (Hashtable)cc.GetType().InvokeMember("m_domainTable", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, cc, new object[] { });
            StringBuilder sb = new StringBuilder();
            foreach (object pathList in table.Values)
            {
                SortedList lstCookieCol = (SortedList)pathList.GetType().InvokeMember("m_list", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, pathList, new object[] { });
                foreach (CookieCollection colCookies in lstCookieCol.Values)
                    foreach (Cookie c in colCookies)
                    {
                        lstCookies.Add(c);
                    }
            }

            return lstCookies;
        }

        private bool CheckValidationResult(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true; //总是接受  
        }


    }
}