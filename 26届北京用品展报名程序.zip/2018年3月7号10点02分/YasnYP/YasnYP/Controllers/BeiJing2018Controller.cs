﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Yasn.Logic;
using Yasn.Model;
using Yasn.Model.WechatClass;
using Yasn.Utility;

namespace YasnYP.Controllers
{
    [CustomHandleErrorAttribute]
    public class BeiJing2018Controller : BaseController
    {
        private const int ZhanhuiNo = 2013;//2018北京用品展会ID

        [HttpGet]
        public ActionResult ValidatPage()
        {
            try
            {
                ////正式上线状态
                string openid = Request.QueryString["openid"];
                object myToken = Request.QueryString["access_token"];
                string datetime = Request.QueryString["access_token_time_out"];
                string f = Request.QueryString["f"];    //获取f参数        1为报名，2为报销

                DateTime InvalidTime = ConvertUnixToDateTime(datetime);

                Utils.WriteLog("车品宝抛出的数据：" + openid + "  access_token:" + myToken + "时间戳: " + datetime + "  失效时间" + InvalidTime);
                //将access_token存储到cookie中
                Utils.SetCookie("myToken", myToken.ToString());
                Utils.SetCookie("InvalidTime", InvalidTime.ToString());

                //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
                GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);
                Utils.WriteLog("手机号验证页面（分享）：access_token： " + myToken + "   失效时间：" + InvalidTime);


                //本地测试的openId
                //string openid = "oNty8jdss7aasdsdasdbwasd11";
                //string f = "1";



                // string openid = (string)ViewBag.openId;
                Utils.WriteLog("刚进入ValidatePage页面：" + openid);
                //查询该微信用户是否已报名
                int ID = Yasn.Logic.CarAccessoryWXMember.IsWXNo(openid, ZhanhuiNo);
                //如果该用户已经在微信中报名成功则跳转成功页面
                if (ID > 0)
                {
                    //如果传的参数是  HotelInfo    则代表是酒店入住，将Phone传到酒店入住页面
                    if (f == "90000001")
                    {
                        //如果该Openid已经在数据库存在，则查询出所对应的手机号码
                        string Phone = Yasn.Logic.CarAccessoryWXMember.GetPhoneByOpenid(openid, ZhanhuiNo);
                        return this.RedirectToAction("Occupancy", "BeiJing2018", new
                        {
                            Phone = Phone
                        });
                    }
                    //如果传的参数是 Resting    则代表是休息区权限，将Openid传到休息区页面
                    else if (f == "90000002")
                    {
                        //领证入口关闭
                        DateTime NowTimeEnd = System.DateTime.Now;
                        DateTime EndTime = DateTime.Parse(ConfigurationManager.AppSettings["EndTime"].Trim());
                        //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                        if (NowTimeEnd > EndTime)
                        {
                            return this.RedirectToAction("EndPage", "BeiJing2018", new
                            {
                            });
                        }
                        else
                        {
                            return this.RedirectToAction("Resting", "BeiJing2018", new
                            {
                                openid = openid
                            });
                        }

                    }
                    //如果传的参数是 90000003    则代表是参观用户领证，将Openid传到参观用户领证页面
                    else if (f == "90000003")
                    {
                        //领证入口关闭
                        DateTime NowTimeEnd = System.DateTime.Now;
                        DateTime EndTime = DateTime.Parse(ConfigurationManager.AppSettings["EndTime"].Trim());
                        //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                        if (NowTimeEnd > EndTime)
                        {
                            return this.RedirectToAction("EndPage", "BeiJing2018", new
                            {
                            });
                        }
                        else
                        {
                            return this.RedirectToAction("AudienceReceive", "BeiJing2018", new
                            {
                                openid = openid
                            });
                        }

                    }
                    else if (Convert.ToInt32(f) > 50 && Convert.ToInt32(f) < 150)
                    {
                        //领证入口关闭
                        DateTime NowTimeEnd = System.DateTime.Now;
                        DateTime EndTime = DateTime.Parse(ConfigurationManager.AppSettings["EndTime"].Trim());
                        //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                        if (NowTimeEnd > EndTime)
                        {
                            return this.RedirectToAction("EndPage", "BeiJing2018", new
                            {
                            });
                        }
                        else
                        {
                            return this.RedirectToAction("ActiveList", "BeiJing2018", new
                            {
                                openid = openid,
                                ActiveCode = f

                            });
                        }


                    }
                    else
                    {
                        //领证入口关闭
                        DateTime NowTimeEnd = System.DateTime.Now;
                        DateTime EndTime = DateTime.Parse(ConfigurationManager.AppSettings["EndTime"].Trim());
                        //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                        if (NowTimeEnd > EndTime)
                        {
                            return this.RedirectToAction("EndPage", "BeiJing2018", new
                            {
                            });
                        }
                        else
                        {
                            //获取当前日期
                            DateTime NowTime = System.DateTime.Now;
                            DateTime SmartTime = DateTime.Parse(ConfigurationManager.AppSettings["SmartTime"].Trim());

                            //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                            if (NowTime > SmartTime)
                            {

                                return this.RedirectToAction("AudienceReceive", "BeiJing2018", new
                                {
                                    openid = openid
                                });
                            }
                            else
                            {
                                return this.RedirectToAction("Success", "BeiJing2018", new
                                {
                                    IDS = ID
                                });
                            }
                        }

                    }

                }
                //否则跳转到手机/编码验证界面            
                // Utils.WriteLog("进入ValidatPage页面（post）：" + openid + "     主行人员ID" + f);
                Utils.SetCookie("openIDNow", openid);
                Utils.SetCookie("LeadID", f);
                return View();

            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.ToString());
                return this.RedirectToAction("SendCode", "BeiJing2018");
            }
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ValidatPage(Yasn.Model.PersonalInfoModel model)
        {
            //使用cookie获取openid
            string openid = Utils.GetCookie("openIDNow");

            string LeadID = Utils.GetCookie("LeadID");
            Utils.WriteLog("Post 验证页：" + ViewBag.openId);

            string UserMobile = model.UserMobile;   // 手机号码+验证码渠道


            //验证手机的合法性
            if (UserMobile != null)
            {
                //加密openid与UserMobile
                string mopenid = DES_StrText.Encrypt(openid);
                string musermobile = DES_StrText.Encrypt(UserMobile);

                //正则表达式验证手机号码
                string AllPhoneRegex = @"^0?(13[0-9]|15[012356789]|18[0123456789]|14[57]|17[0135678]|19[9])[0-9]{8}$";
                if (System.Text.RegularExpressions.Regex.IsMatch(UserMobile, AllPhoneRegex))
                {
                    //查询wxmember表是否存在该手机号
                    List<WXMember> wxMemberList = WXMemberLogic.GetYPModelList(UserMobile, ZhanhuiNo);
                    if (wxMemberList.Count != 0)
                    {
                        //如果不为空，则代表已经手机号已经绑定微信号，需要更新微信号：
                        Yasn.Model.WechatClass.WXMember WXModel = new Yasn.Model.WechatClass.WXMember();
                        WXModel.WXNo = Utils.GetCookie("openIDNow");
                        WXModel.Mobile = UserMobile;
                        WXModel.CreateDate = System.DateTime.Now;

                        //更新微信表中以前绑定该手机号的微信号
                        string UpdateWXNO = Yasn.Logic.CarAccessoryWXMember.UpdateWXNOByPhone(WXModel);

                        //更新展会关联表
                        string UpdateZHGL = Yasn.Logic.CarAccessoryWXMember.ZHGLUpdateWXNOByPhone(WXModel.WXNo, WXModel.Mobile, ZhanhuiNo);
                        //通过手机号查询展会关联表，并跳转到成功页
                        int IDS = Yasn.Logic.CarAccessoryWXMember.GetIDByPhone(UserMobile, ZhanhuiNo);
                        //如果该用户已经在微信中报名成功则跳转成功页面
                        if (IDS > 0)
                        {
                            //获取当前日期
                            DateTime NowTime = System.DateTime.Now;
                            DateTime SmartTime = DateTime.Parse(ConfigurationManager.AppSettings["SmartTime"].Trim());

                            //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                            if (NowTime > SmartTime)
                            {
                                return this.RedirectToAction("AudienceReceive", "BeiJing2018", new
                                {
                                    openid = openid
                                });
                            }
                            else
                            {
                                return this.RedirectToAction("Success", "BeiJing2018", new
                                {
                                    IDS = IDS
                                });
                            }

                        }
                    }
                    //根据拿到的手机号从基础数据表中查询是否存数据；如果存在，则将查到的数据赋给页面中的字段；
                    Test_Phone SelectInfo = Yasn.Logic.CarAccessoryWXMember.GetListByPhone(UserMobile);
                    if (null != SelectInfo)
                    {

                        //将数据存入到ViewBag中，然后在页面调用即可，
                        //ViewBag.Name = SelectInfo.fullname;
                        //ViewBag.cjiname = SelectInfo;
                        //ViewBag.job = SelectInfo.job;
                        //ViewBag.accounttype = SelectInfo.accounttype;
                        //ViewBag.card = SelectInfo.card;

                        Yasn.Model.WechatClass.WXMember WXModel = new Yasn.Model.WechatClass.WXMember();
                        WXModel.UserName = SelectInfo.fullname;//姓名
                        WXModel.Mobile = UserMobile;    //手机号
                        WXModel.CompanyName = SelectInfo.Company;   //公司名称
                        //WXModel.card = SelectInfo.yasn_code;   //卡号
                        WXModel.WXNo = openid;         //OpenID

                        string vxmid = string.Empty;
                        vxmid = Yasn.Logic.CarAccessoryWXMember.AddWXMemberByPhone_xzc(WXModel, ZhanhuiNo);

                        //得到最大的编号
                        int vxmenberid = Convert.ToInt32(vxmid);

                        //唯一编码
                        int CardNumber = (int)90000000 + (int)vxmenberid;

                        Yasn.Model.ZhanHuiGuanLianModel ZHGLModel = new Yasn.Model.ZhanHuiGuanLianModel();
                        ZHGLModel.WeiXinOpenId = openid;
                        ZHGLModel.LeadId = Convert.ToInt32(LeadID);
                        ZHGLModel.zhanhuiid = ZhanhuiNo;        //展会ID
                        ZHGLModel.vxmenberid = vxmenberid;      //微信用户id
                        ZHGLModel.phone = UserMobile;            //手机号码
                        ZHGLModel.name = SelectInfo.fullname;    //姓名
                        ZHGLModel.cjiname = SelectInfo.Company;  //工作单位
                        ZHGLModel.job = SelectInfo.job; //职务
                        ZHGLModel.IndustryOwend = SelectInfo.protype; //所属行业
                        ZHGLModel.MainBusine = SelectInfo.mainbusine; //经营类型
                        ZHGLModel.ManageType = SelectInfo.managetype; //主营业务
                        ZHGLModel.EnjoyProduct = string.Empty; //兴趣活动
                        //ZHGLModel.card = CardNumber.ToString();   //唯一编码
                        ZHGLModel.card = SelectInfo.card;   //唯一编码
                        ZHGLModel.IsGift = SelectInfo.ISGift;
                        //ZHGLModel.cardimageurl = "/QRCode/2018-03-03/" + CardNumber + ".png";
                        ZHGLModel.cardimageurl = SelectInfo.cardimageurl;
                        string result = string.Empty;

                        int ID = Yasn.Logic.CarAccessoryWXMember.AddZhanHuiGuanLianByPhoneBasic(ZHGLModel);
                        Utils.WriteLog("通过PhoneBasic表保存成功的ID：" + ID);
                        if (ID > 0)
                        {
                            //获取当前日期
                            DateTime NowTime = System.DateTime.Now;
                            DateTime SmartTime = DateTime.Parse(ConfigurationManager.AppSettings["SmartTime"].Trim());

                            //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                            if (NowTime > SmartTime)
                            {
                                return this.RedirectToAction("AudienceReceive", "BeiJing2018", new
                                {
                                    openid = openid
                                });
                            }
                            else
                            {
                                return this.RedirectToAction("Success", "BeiJing2018", new
                                {
                                    IDS = ID
                                });
                            }

                        }
                    }

                    return this.RedirectToAction("Login", "BeiJing2018", new
                    {
                        W = mopenid,
                        P = musermobile,
                        LeadID = LeadID
                    });
                }
            }
            return View();

        }
        [HttpGet]
        public ActionResult Login(string W, string P, string LeadID)
        {
            try
            {
                string myToken = Utils.GetCookie("myToken");
                DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
                //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
                GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);
                Utils.WriteLog("Login: access_token:" + myToken + "  失效时间" + InvalidTime);

                string Phone = DES_StrText.Decrypt(P);
                string WeiXinOpenId = DES_StrText.Decrypt(W);
                ViewBag.Phone = Phone;
                ViewBag.openid = WeiXinOpenId;
                string UserMobile = ViewBag.Phone;


                Utils.SetCookie("openIDNow", ViewBag.openid);
                Utils.SetCookie("PhoneNow", ViewBag.Phone);
                Utils.SetCookie("LeadID", LeadID);
                return View();
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.ToString());
                return Content(string.Empty);
            }
        }

        [HttpPost]
        public ActionResult Login(Yasn.Model.PersonalInfoModel model)
        {
            string masterId = string.Empty;
            string oldGift = model.MyGift;
            model.MyGift = "0";//全部默认为报名
            ////post方式获取页面中的value值
            //string Phone = Request.Form.Get("Phone").ToString();
            //string WeiXinOpenId = Request.Form.Get("WeiXinOpenId").ToString();

            //使用cookie获取openid
            string WeiXinOpenId = Utils.GetCookie("openIDNow");
            string Phone = Utils.GetCookie("PhoneNow");
            string LeadID = Utils.GetCookie("LeadID");

            masterId = (Yasn.Logic.CarAccessoryWXMember.GetDQBMBYID(WeiXinOpenId, ZhanhuiNo)).ToString();
            //进入添加信息页面前，先判断是否已经报名成功。
            if (!string.IsNullOrEmpty(masterId) && masterId != "0")
            {
                model.ZhanhuiNo = ZhanhuiNo;
                masterId = SaveInfo(model, Phone, WeiXinOpenId, LeadID, true);
            }
            else
            {
                model.ZhanhuiNo = ZhanhuiNo;
                if (Yasn.Logic.CarAccessoryWXMember.IsExistsPhoneOfCurrent(Phone, ZhanhuiNo))
                {
                    masterId = SaveInfo(model, Phone, WeiXinOpenId, LeadID, true);
                }
                else
                {
                    masterId = SaveInfo(model, Phone, WeiXinOpenId, LeadID, false);
                }
            }
            //通过手机号查询展会关联表，并跳转到成功页
            int IDS = Yasn.Logic.CarAccessoryWXMember.GetIDByPhone(Phone, ZhanhuiNo);
            if (IDS > 0)
            {
                //获取当前日期
                DateTime NowTime = System.DateTime.Now;
                DateTime SmartTime = DateTime.Parse(ConfigurationManager.AppSettings["SmartTime"].Trim());

                //如何当前日期大于设定的日期，则不走答题页面，直接跳转到成功页面
                if (NowTime > SmartTime)
                {
                    return this.RedirectToAction("AudienceReceive", "BeiJing2018", new
                    {
                        openid = WeiXinOpenId
                    });
                }
                else
                {
                    return this.RedirectToAction("Success", "BeiJing2018", new
                    {
                        IDS = IDS
                    });
                }


            }
            return View();
        }

        private string SaveInfo(Yasn.Model.PersonalInfoModel model, string Phone, string WeiXinOpenId, string LeadID, bool isUpdate)
        {
            Yasn.Model.WechatClass.WXMember WXModel = new Yasn.Model.WechatClass.WXMember();
            WXModel.WXNo = model.WeiXinOpenId;
            WXModel.Mobile = Phone;
            WXModel.UserName = model.UserName;
            WXModel.CompanyName = model.Company;
            string vxmid = string.Empty;
            vxmid = Yasn.Logic.CarAccessoryWXMember.AddWXMemberByPhone_xzc(WXModel, ZhanhuiNo);

            //更改展会时，需要更改编号开始的序号


            //得到最大的编号
            int vxmenberid = Convert.ToInt32(vxmid);

            //唯一编码
            int CardNumber = (int)90000000 + (int)vxmenberid;

            Yasn.Model.ZhanHuiGuanLianModel ZHGLModel = new Yasn.Model.ZhanHuiGuanLianModel();
            ZHGLModel.WeiXinOpenId = WeiXinOpenId;
            ZHGLModel.LeadId = Convert.ToInt32(LeadID);
            ZHGLModel.zhanhuiid = ZhanhuiNo;        //展会ID
            ZHGLModel.vxmenberid = vxmenberid;      //微信用户id
            ZHGLModel.phone = Phone;            //手机号码
            ZHGLModel.name = model.UserName.Trim();    //姓名
            ZHGLModel.cjiname = model.Company.Trim();  //工作单位
            ZHGLModel.job = model.UserPosition.Trim(); //职务
            ZHGLModel.IndustryOwend = model.IndustryOwend; //所属行业
            ZHGLModel.MainBusine = model.MainBusine; //经营类型
            ZHGLModel.ManageType = model.ManageType; //主营业务
            ZHGLModel.EnjoyProduct = model.EnjoyProduct; //兴趣活动
            ZHGLModel.card = CardNumber.ToString();   //唯一编码
            //农业博览会二维码存放路径
            ZHGLModel.cardimageurl = "/QRCode/2018-03-03/" + CardNumber + ".png";
            string result = string.Empty;
            if (isUpdate)
            {
                result = Yasn.Logic.CarAccessoryWXMember.UpdateZhanHuiGuanLian(ZHGLModel);
            }
            else
            {
                result = (Yasn.Logic.CarAccessoryWXMember.AddZhanHuiGuanLianByOther(ZHGLModel)).ToString();
            }
            return result;
        }

        [HttpGet]
        public ActionResult Success(int IDS)
        {
            //进入该页面首先判断该openid是否已报名，然后根据结果跳转对应页面

            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));

            //获取分享权限(报名成功之后，IDS为该人员的id，分享出去，别人将会成为他的随行人员，存储leadId)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, IDS);
            Utils.WriteLog("Success: access_token:" + myToken + "  失效时间" + InvalidTime);

            //报销功能是否启用
            @ViewBag.EnableFlag = false;
            int _gift = 0;
            ViewBag.IDS = IDS;

            ViewBag.BannerURL = ConfigurationManager.AppSettings["BannerURL"].Trim();
            Utils.SetCookie("JYBannerURL", ViewBag.BannerURL);
            int.TryParse(string.IsNullOrEmpty(Request.Params["MyGift"]) ? "0" : Request.Params["MyGift"].ToString(), out _gift);
            List<Yasn.Model.ZhanHuiGuanLianModel> results = Yasn.Logic.ZhanhuiguanlianLogic.GetPrimarySecondaryList(IDS);
            //var models = results.OrderBy(c => c.LeadId).ToList();
            return View(results);
        }
        public ActionResult EndPage()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Reimburse(int IDS)
        {
            ViewBag.IDS = IDS;
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(报名成功之后，IDS为该人员的id，分享出去，别人将会成为他的随行人员，存储leadId)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, IDS);
            return View();
        }
        /// <summary>
        /// 分享指定位置
        /// </summary>
        public void SendCode()
        {
            try
            {
                string f = string.Empty;
                if (Request.QueryString["f"] == null || Request.QueryString["f"].ToString() == "")
                {
                    f = "0";    //获取f参数        1为报名，2为报销
                }
                else
                {
                    f = Request.QueryString["f"];    //获取f参数        1为报名，2为报销
                }
                string url = string.Format("http://caigou.yasn.com/api/b2b2c/wx/getOpenid.do?f=" + f);
                Utils.WriteLog("成功访问SendCode()");
                HttpContext.Response.Redirect(url);
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.Message);
            }
        }
        /// <summary>
        /// 报销页面的分享链接
        /// </summary>
        public void ReimSendCode()
        {
            try
            {
                string url = string.Format("http://caigou.yasn.com/api/b2b2c/wx/getOpenid.do?f=2");
                Utils.WriteLog("成功访问ReimSendCode()");
                HttpContext.Response.Redirect(url);
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.Message);
            }
        }

        /// <summary>
        /// 记录通过手机验证码短信发送记录
        /// </summary>
        /// <param name="phone">用户手机</param>
        /// <returns>0--添加成功，-1为当天达到最大发送限制,-2为手机号码重复</returns>
        public string WriteValidateInfo(string phone, int? gift)
        {
            //调用web.config中广州展览的短信验证码发送
            string strpwdvalid = ConfigurationManager.AppSettings["2017BJYPSMSCode"].Trim();
            string result = "{{\"resultMsg\":\"{0}\"}}";
            int sm = -3;//代表手机号为空

            if (!string.IsNullOrEmpty(phone))
            {
                bool flag = false;
                if (!flag)
                {
                    object myCode = ControllerContext.HttpContext.Cache[phone];
                    string rd = "";
                    if (myCode == null)
                    {
                        Random d = new Random();
                        for (int i = 0; i < 4; i++)
                        {
                            rd += d.Next(0, 9).ToString();
                        }
                        ControllerContext.HttpContext.Cache.Insert(phone, rd, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(5));
                    }
                    else
                    {
                        rd = (string)myCode;
                    }
                    //0--可以发送，-1为当天达到最大发送限制（5次）
                    sm = new Yasn.Data.PhoneValidateLog().Add(phone, rd);
                    if (sm == 0)
                    {
                        //发送短信代码，测试时注释
                        SendSMS.SendSingleSMS(phone, string.Format(strpwdvalid, rd), string.Empty, MessageChannel.BeiJing);

                        //发送完短信，往发送短信日志表中插入数据
                        SMSHistory SMSHisModel = new SMSHistory();
                        SMSHisModel.ZhanhuiID = 2013;                                  //展会id
                        SMSHisModel.SMSContent = string.Format(strpwdvalid, rd);    //短信内容
                        SMSHisModel.SerialNum = "SDK-BBX-010-19109";        //短信平台账户
                        SMSHisModel.SMSType = 3;      //短信类型
                        SMSHisModel.Channel = 2;      //发送短信渠道
                        SMSHisModel.Phone = phone;    //发送短信的手机号

                        string AddSMSHistory = Yasn.Logic.CarAccessoryWXMember.AddSMSHistory(SMSHisModel);
                    }
                }
                else
                {
                    sm = -2;

                }
            }
            return string.Format(result, 0);
        }

        /// <summary>
        /// 检查手机号在当前展会是否已报名
        /// </summary>
        /// <returns></returns>
        public string CheckPhone()
        {
            string ReturnStr = "";
            string Phone = "";
            if (Request.HttpMethod == "GET")
            {
                Phone = Request.Params["UserMobile"];
            }
            try
            {
                //验证手机的合法性

                if (Phone.Length < 11)
                {
                    ReturnStr = "{\"status\":\"error\",\"message\":\"手机号码不合法，请输入正确的号码\"}";
                }
                string AllPhoneRegex = @"^0?(13[0-9]|15[012356789]|18[0123456789]|14[57]|17[0135678]|19[9])[0-9]{8}$";
                if (System.Text.RegularExpressions.Regex.IsMatch(Phone, AllPhoneRegex))
                {
                    string cardId = string.Empty;
                    //验证该手机在当前是否已报名，如果报名返回已经报名
                    List<WXMember> wxMemberList = WXMemberLogic.GetYPModelList(Phone, ZhanhuiNo);
                    //该手机号没有报过名

                    if (wxMemberList.Count == 0)
                    {
                        if (string.IsNullOrEmpty(cardId))
                        {
                            ReturnStr = "{\"status\":\"pass\",\"message\":\"新增\"}";
                        }
                        else
                        {
                            Yasn.Model.WechatClass.WXMember WXModel = new Yasn.Model.WechatClass.WXMember();
                            WXModel.WXNo = Request.Params["WeiXinOpenId"];
                            WXModel.CreateDate = DateTime.Now;
                            string vxmid = Yasn.Logic.CarAccessoryWXMember.AddMemberNew(WXModel, ZhanhuiNo);
                            int vxmenberid = Convert.ToInt32(vxmid);
                            string flag = string.Empty;
                            Yasn.Model.ZhanHuiGuanLianModel ZHGLModel = new Yasn.Model.ZhanHuiGuanLianModel();
                            ZHGLModel.zhanhuiid = ZhanhuiNo;
                            ZHGLModel.vxmenberid = vxmenberid;
                            ZHGLModel.createtime = DateTime.Now;
                            ZHGLModel.phone = Phone;
                            ZHGLModel.name = Request.Params["UserName"];
                            ZHGLModel.cjiname = Request.Params["company"];
                            ZHGLModel.job = Request.Params["UserPosition"];
                            ZHGLModel.email = Request.Params["UserEmail"];
                            //ZHGLModel.tqhd = Request.Params["ActionID"];
                            string tqhd = "";
                            try
                            {
                                tqhd = Request.Params["ActionID"];
                            }
                            catch { tqhd = ""; }
                            ZHGLModel.tqhd = tqhd;
                            ZHGLModel.shifoutb = true;
                            ZHGLModel.card = cardId;
                            ZHGLModel.ProType = Request.Params["ProType"];
                            if (Yasn.Logic.CarAccessoryWXMember.IsExistsPhoneOfCurrent(Phone, ZhanhuiNo))
                            {
                                flag = Yasn.Logic.CarAccessoryWXMember.UpdateZhanHuiGuanLian(ZHGLModel);
                            }
                            else
                            {

                                flag = Yasn.Logic.CarAccessoryWXMember.AddZhanHuiGuanLian(ZHGLModel);
                            }
                            Utils.WriteLog(Phone + "提交成功");
                            ReturnStr = "{\"status\":\"repeat\",\"message\":\"" + flag + "\"}";
                        }
                    }
                    else
                    {
                        ReturnStr = "{\"status\":\"repeat\",\"message\":\"" + wxMemberList[0].Zhanhuiguanlian_ID + "\"}";
                    }
                }
                else
                {
                    ReturnStr = "{\"status\":\"error\",\"message\":\"手机号码不合法，请输入正确的号码\"}";
                }
            }
            catch (Exception ex)
            {
                ReturnStr = "{\"status\":\"error\",\"message\":\"" + ex.Message + "\"}";
            }
            return ReturnStr;

        }

        /// <summary>
        /// 判断用户发来的验证码是否过期或者有效

        /// </summary>
        /// <param name="userPhone">用户手机</param>
        /// <param name="validateCode">验证码</param>
        /// <returns>0--正常，-2--验证码不可信,-1--验证码失效</returns>
        public string ValidateCodeValid(string userPhone, string validateCode)
        {
            string result = "{{\"resultMsg\":\"{0}\"}}";
            return string.Format(result, new Yasn.Data.PhoneValidateLog().Exists(userPhone, validateCode));
        }
        /// <summary>
        /// 判断用户录入的手机号和编码是否匹配
        /// </summary>
        /// <param name="userPhone">用户手机号码</param>
        /// <param name="Card">雅森给用户的唯一编码</param>
        /// <returns>0--标识匹配成功，-2--表示匹配失败</returns>
        public string IsPhoneBM(string userPhone, string Card)
        {
            Utils.WriteLog("验证手机号加编码" + userPhone + Card);
            string result = "{{\"resultMsg\":\"{0}\"}}";
            Utils.WriteLog("验证手机号加编码" + string.Format(result, new Yasn.Data.PhoneValidateLog().IsPhoneBM(userPhone, Card)));
            return string.Format(result, new Yasn.Data.PhoneValidateLog().IsPhoneBM(userPhone, Card));
        }

        /// <summary>
        /// 向数据库插入用户位置信息
        /// </summary>
        public void InsertLocationInfo()
        {
            try
            {
                string openid = Utils.GetCookie("openIDNow");

                Utils.WriteLog(openid);
                decimal Lng = 0.00m;        //经度
                decimal Lat = 0.00m;        //纬度
                string Province = string.Empty;  //省份
                string City = string.Empty;     //城市
                string District = string.Empty; //区县
                if (Request.HttpMethod == "GET")
                {
                    Lng = Convert.ToDecimal(Request.Params["Lng"]);
                    Lat = Convert.ToDecimal(Request.Params["Lat"]);
                    Province = Request.Params["Province"];
                    City = Request.Params["City"];
                    District = Request.Params["District"];

                    Utils.WriteLog("向数据库插入用户的位置信息：" + "Openid" + openid + "经度：" + Lng + "纬度：" + Lat + "省份：" + Province + "城市" + City + "区县" + District);

                    string AddLocationInfo = Yasn.Logic.CarAccessoryWXMember.AddLocationInfo(ZhanhuiNo, openid, Lng, Lat, Province, City, District); //将数据添加到用户位置表
                    Utils.WriteLog(AddLocationInfo);
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.Message);
            }
        }
        /// <summary>
        /// 时间戳转换为datetime
        /// </summary>
        /// <param name="unix"></param>
        /// <returns></returns>
        public static DateTime ConvertUnixToDateTime(string unix)
        {
            DateTime startUnixTime = System.TimeZoneInfo.ConvertTime(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc), TimeZoneInfo.Local);
            return startUnixTime.AddSeconds(double.Parse(unix));
        }

        public ActionResult Occupancy(string Phone)
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            //string openid = Request.Params["OpenID"];
            //ViewBag.openId = openid;
            ////string openid = Request.QueryString["OpenID"];
            string FullName = string.Empty;          //姓名
            string HotelName = string.Empty;        //酒店名称
            string RoomType = string.Empty;         //房间类型
            string CheckInState = string.Empty;     //入住状态
            string Remark = string.Empty;           //备注
            DateTime CheckInDate = System.DateTime.Now;      //入住时间
            DateTime CheckOutDate = System.DateTime.Now;    //离开时间

            //Phone = "15130079715";
            //根据openid获取该微信用户的ID，姓名、编码、服务类别
            int ID = Yasn.Logic.CarAccessoryWXMember.GetMID(ZhanhuiNo, Phone, ref FullName, ref HotelName, ref RoomType, ref CheckInDate, ref CheckOutDate, ref CheckInState, ref Remark);

            if (ID > 0)
            {
                ViewBag.IsOk = 1;
                ViewBag.FullName = FullName;
                ViewBag.HotelName = HotelName;
                ViewBag.RoomType = RoomType;
                ViewBag.CheckDate = CheckInDate.ToShortDateString() + "至" + CheckOutDate.ToShortDateString();
                ViewBag.CheckInState = CheckInState;
                ViewBag.Remark = Remark;
                ViewBag.Phone = Phone;
                ViewBag.ID = ID;
            }
            else
            {
                ViewBag.IsOk = 0;
            }
            return View();
        }

        public ActionResult OccupancyCopy()
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            string Phone = Request.Params["OpenID"];
            //ViewBag.openId = openid;
            ////string openid = Request.QueryString["OpenID"];
            string FullName = string.Empty;          //姓名
            string HotelName = string.Empty;        //酒店名称
            string RoomType = string.Empty;         //房间类型
            string CheckInState = string.Empty;     //入住状态
            string Remark = string.Empty;           //备注
            DateTime CheckInDate = System.DateTime.Now;      //入住时间
            DateTime CheckOutDate = System.DateTime.Now;    //离开时间

            int ID = Yasn.Logic.CarAccessoryWXMember.GetMID(ZhanhuiNo, Phone, ref FullName, ref HotelName, ref RoomType, ref CheckInDate, ref CheckOutDate, ref CheckInState, ref Remark);

            if (ID > 0)
            {
                ViewBag.IsOk = 1;
                ViewBag.FullName = FullName;
                ViewBag.HotelName = HotelName;
                ViewBag.RoomType = RoomType;
                ViewBag.CheckDate = CheckInDate.ToShortDateString() + "至" + CheckOutDate.ToShortDateString();
                ViewBag.CheckInState = CheckInState;
                ViewBag.Remark = Remark;
                ViewBag.Phone = Phone;
                ViewBag.ID = ID;
            }
            else
            {
                ViewBag.IsOk = 0;
            }
            return View();
        }
        /// <summary>
        /// 入住状态
        /// </summary>
        /// <param name="pam"></param>
        /// <param name="pam1"></param>
        /// <param name="fl"></param>
        /// <returns></returns>
        public string GoCheckIn(string ID)
        {
            string result = "";
            result = Yasn.Logic.CarAccessoryWXMember.GoCheckIn(ID, ZhanhuiNo);
            return result;
        }

        [HttpGet]
        public ActionResult Resting(string Openid)
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);
            ViewBag.openId = Openid;

            //string openid = Request.Params["OpenID"];
            ////string openid = Request.QueryString["OpenID"];
            //获取到用户OpenID，判断是否已有该服务
            //ViewBag.openId = "o81pHw202p-CJL9Wg07u4e-MrFrY";
            string openid = ViewBag.openId;
            string fullname = "";
            string card = "";
            int isgift = 0;
            int giftvalue = 0;
            string phone = "";
            //根据openid获取该微信用户的ID，姓名、编码、服务类别
            int ID = Yasn.Logic.CarAccessoryWXMember.GetRestInfo(ZhanhuiNo, openid, ref fullname, ref card, ref isgift, ref giftvalue, ref phone);
            //if (isgift > 0)
            //{
            //    ViewBag.NameStr = "VIP买家" + fullname + "经理";
            //}
            //else
            //{
            //    ViewBag.NameStr = "专业买家" + fullname + "经理";
            //}

            ViewBag.isgift = isgift;
            //gift=3:已领礼品与会刊
            ViewBag.giftvalue = giftvalue;
            ViewBag.phone = phone;
            return View();
        }
        [HttpGet]
        public ActionResult RestingCopy()
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            //string openid = Request.Params["OpenID"];
            //ViewBag.openId = openid;
            ////string openid = Request.QueryString["OpenID"];
            string openid = Request.Params["OpenID"];
            ViewBag.openId = openid;
            //string openid = Request.QueryString["OpenID"];
            string fullname = "";
            string card = "";
            int isgift = 0;
            int giftvalue = 0;
            string phone = "";
            //根据openid获取该微信用户的ID，姓名、编码、服务类别
            int ID = Yasn.Logic.CarAccessoryWXMember.GetRestInfo(ZhanhuiNo, openid, ref fullname, ref card, ref isgift, ref giftvalue, ref phone);

            ViewBag.isgift = isgift;
            //gift=3:已领礼品与会刊
            ViewBag.giftvalue = giftvalue;
            ViewBag.phone = phone;
            return View();
        }

        /// <summary>
        /// 领取礼品、会刊
        /// </summary>
        /// <param name="pam"></param>
        /// <param name="pam1"></param>
        /// <param name="fl"></param>
        /// <returns></returns>
        public string GoGift(string fl, string openid)
        {
            //fl=1领取礼品,fl=2领取会刊
            //执行存储过程读取结果
            int flag = 0;
            if (!string.IsNullOrEmpty(fl))
            {
                flag = int.Parse(fl);
            }
            string result = "";
            result = Yasn.Logic.CarAccessoryWXMember.GoGift(openid, flag, ZhanhuiNo);
            return result;
        }

        /// <summary>
        /// 跳转车品链接参数设定
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public string GoCP(string phone)
        {
            if (!string.IsNullOrEmpty(phone))
            {
                string dt = DateTime.Now.AddMinutes(5).ToString("yyyy-MM-dd HH:mm:ss");
                return Yasn.Utility.DES.DESEnCode(dt);
            }
            else
            {
                return "";//手机为空，传出空验证秘钥
            }
        }

        public ActionResult ActiveList(string openid, string ActiveCode)
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            string ActiveName = string.Empty;
            string ActiveTheme = string.Empty;
            TqhdSign TqhdSign = new TqhdSign();
            List<Activity> ActivityList = Yasn.Logic.CarAccessoryWXMember.GetActivityOfCurrent(ZhanhuiNo, true);
            //Openid = "o81pHw202p-CJL9Wg07u4e-MrFrY";
            //ActiveCode = 55;
            Utils.WriteLog("进入同期活动签到页面，该活动ID为：" + ActiveCode);
            if (ActivityList.Count > 0)
            {
                foreach (var a in ActivityList)
                {
                    if (a.ID == Convert.ToInt32(ActiveCode))
                    {
                        ViewBag.ActiveName = a.Tqhd;
                        //ViewBag.ActiveTheme = "智能·节能·效能";
                        TqhdSign.OpenID = openid;
                        TqhdSign.tqhdID = a.ID;
                        Utils.WriteLog("同期活动名称：" + a.Tqhd + "    同期活动ID" + a.ID);
                        break;
                    }
                    Utils.WriteLog("同期活动名称1：" + a.Tqhd + "    同期活动ID1" + a.ID);
                }
                string flag = Yasn.Logic.CarAccessoryWXMember.AddTqhdSign(TqhdSign);//将该签到数据插入到数据库
            }
            return View();
        }

        public ActionResult AudienceReceive(string openid)
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            ViewBag.OpenID = openid;

            Dictionary<string, string> myDic = Yasn.Logic.CarAccessoryWXMember.GetARInfo(openid, ZhanhuiNo);
            string ARState = myDic["ARState"].ToString();
            string ARDatetime = myDic["ARDatetime"].ToString();
            ViewBag.ARState = ARState;
            ViewBag.ARDatetime = ARDatetime;
            return View();
        }
        public ActionResult AudienceReceiveCopy()
        {
            string myToken = Utils.GetCookie("myToken");
            DateTime InvalidTime = Convert.ToDateTime(Utils.GetCookie("InvalidTime"));
            //获取分享权限(只有成功页分享出去才有LeadId,其他页面为1)
            GetShare("Yasn-YongPin", Request.Url.AbsoluteUri, myToken, InvalidTime, 1);

            string openid = Request.Params["OpenID"];
            ViewBag.OpenID = openid;

            Dictionary<string, string> myDic = Yasn.Logic.CarAccessoryWXMember.GetARInfo(openid, ZhanhuiNo);
            string ARState = myDic["ARState"].ToString();
            string ARDatetime = myDic["ARDatetime"].ToString();
            ViewBag.ARState = ARState;
            ViewBag.ARDatetime = ARDatetime;
            return View();
        }
        /// <summary>
        /// 更新观众领取证件的状态（已领取or未领取）
        /// </summary>
        /// <param name="OpenID"></param>
        /// <returns></returns>
        public string GoARState(string OpenID)
        {
            string result = "";
            result = Yasn.Logic.CarAccessoryWXMember.GoARState(OpenID, ZhanhuiNo);
            return result;
        }
    }
}