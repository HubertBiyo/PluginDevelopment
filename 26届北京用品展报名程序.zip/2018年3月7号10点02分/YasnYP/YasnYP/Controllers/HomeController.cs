﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;
using Yasn.Framework;
using Yasn.Model;
using Yasn.Model.WechatClass;
using Yasn.Utility;

namespace YasnYP.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "欢迎光临北京雅森国际";

            return View();
        }
        public string ConfigYP()
        {
            Utils.WriteLog("进行ConfigYP()方法-----" + DateTime.Now.ToString());
            if (Request.HttpMethod == "GET")
            {
                return Request.Params["echostr"].ConvertTo<string>("");
            }
            Utils.WriteLog("获取参数");
            Stream s = Request.InputStream;
            int count = 0;
            byte[] buffer = new byte[1024];
            StringBuilder builder = new StringBuilder();
            while ((count = s.Read(buffer, 0, 1024)) > 0)
            {
                builder.Append(Encoding.UTF8.GetString(buffer, 0, count));
            }
            s.Flush();
            s.Close();
            s.Dispose();
            string WechatXML = string.Empty;
            WechatXML = builder.ToString();//获取xml数据
            Utils.WriteLog("用户与公众号的交互XML" + "\n" + WechatXML + "\n 时间：" + DateTime.Now.ToString());

            if (!string.IsNullOrEmpty(WechatXML))
            {
                ResponseMsg(WechatXML);////调用消息适配器
                Utils.WriteLog("进入ResponseMsg方法()" + WechatXML);
            }
            return string.Empty;
        }
        private void ResponseMsg(string weixin)// 服务器响应微信请求
        {
            Utils.WriteLog("进入ResponseMsg()");
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(weixin);//读取xml字符串
            XmlElement root = doc.DocumentElement;
            ExmlMsg xmlMsg = GetExmlMsg(root);
            string messageType = xmlMsg.MsgType;//获取收到的消息类型。文本(text)，图片(image)，语音等。

            Utils.WriteLog("消息类型messageType" + messageType);
            try
            {

                switch (messageType)
                {
                    //当消息为文本时
                    case "text":
                        GetTextCase(xmlMsg);
                        break;
                    case "event":
                        if (!string.IsNullOrEmpty(xmlMsg.EventName) && xmlMsg.EventName.Trim() == "subscribe")
                        {
                            //刚关注时的时间，用于欢迎词  
                            long nowtime = ConvertDateTimeInt(DateTime.Now);
                            //string msg = ConfigurationManager.AppSettings["welcome"] + "[愉快]\r\n";
                            string msg = "恭喜！您已开启后市场财富之门！[鼓掌]\r\n\r\n这里有国内最大最全的后市场全产业链展会→【雅森展会】[强]\r\n\r\n这里有全套店面解决方案，终端门店赚钱好帮手→【雅森帮】[爱心]\r\n\r\n这里有买好、卖好、服务好平台→【雅森车品宝】[玫瑰]";

                            string resxml = "<xml><ToUserName><![CDATA[" + xmlMsg.FromUserName + "]]></ToUserName><FromUserName><![CDATA[" + xmlMsg.ToUserName + "]]></FromUserName><CreateTime>" + nowtime + "</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[" + msg.ToString() + "]]></Content><FuncFlag>0</FuncFlag></xml>";

                            //判断用户关注后推送一条文本消息
                            Response.Write(resxml);
                            //2018.02.26更改内容
                            //StringBuilder content = new StringBuilder();
                            //content.Append("欢迎关注雅森帮！您已开启汽车后市场成功之门！\n");
                            //content.Append("2018雅森北京展 \n");
                            //content.Append("2018年3月3日-3月6日 \r\n\r\n");
                            //content.Append("观众报名\n");
                            //string url = "http://caigou.yasn.com/api/b2b2c/wx/getOpenid.do?f=95106";
                            //content.Append("<a href='" + url + "'>点击进入展会报名直通车</a>");

                            //string resxml = "<xml><ToUserName><![CDATA[" + xmlMsg.FromUserName + "]]></ToUserName><FromUserName><![CDATA[" + xmlMsg.ToUserName + "]]></FromUserName><CreateTime>" + nowtime + "</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[" + content.ToString() + "]]></Content><FuncFlag>0</FuncFlag></xml>";
                            //Response.Write(resxml);

                            // StringBuilder content1 = new StringBuilder();


                            //2018.03.07 10：03更换消息发送
                            //StringBuilder content = new StringBuilder();

                            //content.Append("欢迎关注雅森帮！您已开启汽车后市场财富之门！\n");
                            //content.Append("2018雅森北京展 \n");
                            //content.Append("2018年3月3日-3月6日 \r\n\r\n");
                            //string url = "http://caigou.yasn.com/api/b2b2c/wx/getOpenid.do?f=95106";
                            //content.Append("<a href='" + url + "'>点击领取入场证</a>\r\n\r\n");

                            //content.Append("雅森车品宝春季购物节W3馆火热进行中，7大活动，千万豪礼疯狂送！\r\n");
                            //string url2 = "http://shop.yasn.com/";
                            //content.Append("<a href='" + url2 + "'>点击快速注册雅森车品宝</a>");


                            //string resxml = "<xml><ToUserName><![CDATA[" + xmlMsg.FromUserName + "]]></ToUserName><FromUserName><![CDATA[" + xmlMsg.ToUserName + "]]></FromUserName><CreateTime>" + nowtime + "</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[" + content.ToString() + "]]></Content><FuncFlag>0</FuncFlag></xml>";
                            ////判断用户关注后推送一条文本消息
                            //Response.Write(resxml);

                            //string token = Yasn.Logic.CarAccessoryWXMember.GetToken();
                            //Utils.WriteLog("调用客服消息token" + token);

                            //调用微信接口 客服消息发送  用户关注后推送一条文本消息
                            //ResponseKeFuText(content1.ToString(), xmlMsg.FromUserName, token);
                        }
                        break;
                    default:
                        break;
                }
                Response.End();
            }
            catch (Exception)
            {

            }
        }
        /// <summary>
        /// 调用微信客服消息接口
        /// </summary>
        /// <param name="content"></param>
        /// <param name="UserOpenId"></param>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static string ResponseKeFuText(string content, string UserOpenId, string access_token)
        {
            string kfurl = string.Format("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={0}", access_token);
            StringBuilder menuStr = new StringBuilder();
            menuStr.Append("{");
            menuStr.Append("\"touser\":");
            menuStr.Append("\"" + UserOpenId + "\",");
            menuStr.Append("\"msgtype\":");
            menuStr.Append("\"text\",");
            menuStr.Append("\"text\":");
            menuStr.Append("  {");
            menuStr.Append("\"content\":");
            menuStr.Append("\"" + content + "\"");
            menuStr.Append("  }");
            menuStr.Append("}");

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(kfurl);
            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";

            byte[] postdata = Encoding.GetEncoding("UTF-8").GetBytes(menuStr.ToString());
            request.ContentLength = postdata.Length;

            Stream newStream = request.GetRequestStream();
            newStream.Write(postdata, 0, postdata.Length);
            newStream.Close();

            HttpWebResponse myResponse = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
            string msgcontent = reader.ReadToEnd();//得到结果
            Utils.WriteLog("调用客服消息结果" + msgcontent);
            return msgcontent;
        }
        public ExmlMsg GetExmlMsg(XmlElement root)
        {
            ExmlMsg xmlMsg = new ExmlMsg()
            {
                FromUserName = root.SelectSingleNode("FromUserName").InnerText,
                ToUserName = root.SelectSingleNode("ToUserName").InnerText,
                CreateTime = root.SelectSingleNode("CreateTime").InnerText,
                MsgType = root.SelectSingleNode("MsgType").InnerText,
            };
            if (xmlMsg.MsgType.Trim().ToLower() == "text")
            {
                xmlMsg.Content = root.SelectSingleNode("Content").InnerText;
            }
            else if (xmlMsg.MsgType.Trim().ToLower() == "event")
            {
                xmlMsg.EventName = root.SelectSingleNode("Event").InnerText;
            }
            return xmlMsg;
        }
        private void GetTextCase(ExmlMsg model)
        {
            string content = (model as ExmlMsg).Content;
            Utils.WriteLog("微信测试号用户发送的主要内容： --" + content + "  " + DateTime.Now.ToString());
            string str = string.Empty;
            string ReturnContent = string.Empty;
            //判断手机号码是否合格
            if (System.Text.RegularExpressions.Regex.IsMatch(content, @"^[1][345789]\d{9}$"))
            {
                ReturnContent = Yasn.Logic.WXMemberLogic.GetUserName(content);
                Utils.WriteLog("微信测试号用户发送的主要内容： --" + ReturnContent + "  " + DateTime.Now.ToString());
                if (!string.IsNullOrEmpty(ReturnContent))
                {
                    str = ResponseWeixin.ResponseText(ReturnContent, model.FromUserName, model.ToUserName);
                }
                else
                {
                    ReturnContent = "啥也没有。";
                    str = ResponseWeixin.ResponseText(ReturnContent, model.FromUserName, model.ToUserName);
                }
            }
            else if (content.Trim() == "锐准")
            {
                StringBuilder ReturnContent1 = new StringBuilder();
                string url2 = "http://c7.gg/GWFQ";
                ReturnContent1.Append("<a href='" + url2 + "'>点击参与抽奖</a>");
                str = ResponseWeixin.ResponseText(ReturnContent1.ToString(), model.FromUserName, model.ToUserName);
            }
            else
            {
                ReturnContent = "输入错误。";
                str = ResponseWeixin.ResponseText(ReturnContent, model.FromUserName, model.ToUserName);
            }
            Utils.WriteLog("返回的内容： --" + str + "  " + DateTime.Now.ToString());
            Response.Write(str);
            int a = Yasn.Logic.WXMemberLogic.InsertWechatXML(model, ReturnContent);
            Utils.WriteLog("InsertWechatXML" + a);

        }
        private string HyNYString(WXModel model)
        {
            StringBuilder conSb = new StringBuilder();

            if (ShiFouYPGQ())
            {

                conSb.Append(ConfigurationManager.AppSettings["welcomeNY"] + ":[愉快]\r\n");
                //string url = string.Format("https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri=http://weixin.yasn.com.cn/SignUp/SignUpEdu&response_type=code&scope=snsapi_base&state=1#wechat_redirect", ConfigurationManager.AppSettings["WeiYuAppId"]);
                //conSb.Append("回复“展商”查看特色展商名录\r\n");
                //conSb.Append("回复“活动”查看现场同期活动\r\n");
                //conSb.Append("点击<a href='" + url + "'>立即注册</a>" + "，报名参观展会！");//链接我要报名功能
                //conSb.Append("报名流程：\r\n");
                //conSb.Append("1.本人报名参观：直接回复【姓名+手机号】\r\n");
                //conSb.Append("（PS：“+”不可省略）[拥抱]\r\n");
                //conSb.Append("2.同行报名：您可多次回复【姓名+手机号】\r\n");
                //conSb.Append("3.报名查询：再次点击【我要报名】或直接回复字母【C】.\r\n");
            }
            else
            {
                conSb.Append(ConfigurationManager.AppSettings["regnytitle"] + "");
            }
            XDocument doc = new XDocument(new XElement("xml",
                new XElement("ToUserName", model.FromUserName),
                new XElement("FromUserName", model.ToUserName),
                new XElement("CreateTime", DateTime.Now.ToLongTimeString()),
                new XElement("MsgType", "text"),
                new XElement("Content", conSb.ToString())));

            return doc.ToString();
        }

        private bool ShiFouYPGQ()
        {
            try
            {
                string endreddate = ConfigurationManager.AppSettings["eduendreddate"].Trim();
                if (DateTime.Parse(endreddate) >= DateTime.Now)
                    return true;

                return false;

            }
            catch
            {
                return false;
            }
        }
        public void writeLogToFile(string strMemo)
        {
            if (!Directory.Exists(Server.MapPath(@"logs\")))
            {
                Directory.CreateDirectory(Server.MapPath(@"logs\"));
            }
            string filename = Server.MapPath(@"logs/log.txt");
            StreamWriter sr = null;
            try
            {
                if (!System.IO.File.Exists(filename))
                {
                    sr = System.IO.File.CreateText(filename);
                }
                else
                {
                    sr = System.IO.File.AppendText(filename);
                }
                sr.WriteLine(strMemo);
            }
            catch
            {

            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                }
            }
        }

        /// <summary>
        /// 返回地理位置XML数据
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        private WXModel ParseWXModel(string xml)
        {
            XDocument doc = XDocument.Parse(xml);
            XElement element = doc.Element(XName.Get("xml"));

            //writeLogToFile("进入ParseWXModel方法：" + xml + DateTime.Now.ToString());
            try
            {
                string msgType = element.Element(XName.Get("MsgType")).Value.ToLower();

                if (msgType == "event")
                {
                    //writeLogToFile("xml-event：" + xml + DateTime.Now.ToString());
                    WXEventModel eventModel = null;
                    string eventType = element.Element(XName.Get("Event")).Value.ToLower(); ;

                    //if (eventType != "CLICK")
                    //    return null;
                    if (eventType == "location")
                    {
                        WXLocationModel locationModel = new WXLocationModel
                        {
                            ToUserName = element.Element(XName.Get("ToUserName")).Value,
                            FromUserName = element.Element(XName.Get("FromUserName")).Value,
                            CreateTime = element.Element(XName.Get("CreateTime")).Value,
                            MsgType = msgType,
                            Longitude = element.Element(XName.Get("Longitude")).Value.ConvertTo<double>(),
                            Latitude = element.Element(XName.Get("Latitude")).Value.ConvertTo<double>(),
                            Precision = element.Element(XName.Get("Precision")).Value.ConvertTo<double>()
                        };

                        return locationModel;
                    }
                    else
                    {
                        eventModel = new WXEventModel
                        {
                            ToUserName = element.Element(XName.Get("ToUserName")).Value,
                            FromUserName = element.Element(XName.Get("FromUserName")).Value,
                            CreateTime = element.Element(XName.Get("CreateTime")).Value,
                            MsgType = msgType,
                            Event = eventType,
                            EventKey = element.Element(XName.Get("EventKey")).Value
                        };
                        return eventModel;
                    }
                }
                else if (msgType == "location")
                {
                    WXLocationModel locationModel = new WXLocationModel
                    {
                        ToUserName = element.Element(XName.Get("ToUserName")).Value,
                        FromUserName = element.Element(XName.Get("FromUserName")).Value,
                        CreateTime = element.Element(XName.Get("CreateTime")).Value,
                        MsgType = msgType,
                        Longitude = element.Element(XName.Get("Longitude")).Value.ConvertTo<double>(),
                        Latitude = element.Element(XName.Get("Latitude")).Value.ConvertTo<double>(),
                        Precision = element.Element(XName.Get("Precision")).Value.ConvertTo<double>()
                    };

                    return locationModel;
                }
            }
            catch (Exception ex)
            {
                writeLogToFile("ParseWXModel方法异常：" + ex.Message + "   --" + DateTime.Now.ToString());
            }
            return null;
        }
        /// <summary>
        /// 将c# DateTime时间格式转换为Unix时间戳格式
        /// </summary>
        /// <param name="time">时间</param>
        /// <returns>long</returns>
        private long ConvertDateTimeInt(System.DateTime time)
        {

            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            long t = (time.Ticks - startTime.Ticks) / 10000; //除10000调整为13位
            return t;
        }
        /// <summary>
        /// 时间戳转换为datetime
        /// </summary>
        /// <param name="unix"></param>
        /// <returns></returns>
        public static DateTime ConvertUnixToDateTime(string unix)
        {
            DateTime startUnixTime = System.TimeZoneInfo.ConvertTime(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc), TimeZoneInfo.Local);
            return startUnixTime.AddSeconds(double.Parse(unix));
        }
    }
}