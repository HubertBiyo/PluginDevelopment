﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace YasnYP.Controllers
{
    public class ToolController : Controller
    {
        private const int ZhanhuiNo = 2013;//2018北京用品展会ID
        // GET: Tool
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult VerificatCode()
        {
            return View();
        }
        [HttpPost]
        public ActionResult VerificatCode(Yasn.Model.PersonalInfoModel model)
        {
            string UserMobile = model.UserMobile;
            return View();
        }
        public string QueryVerificatCode()
        {
            string ReturnStr = string.Empty;
            string Phone = "";
            if (Request.HttpMethod == "GET")
            {
                Phone = Request.Params["UserMobile"];
            }
            try
            {
                //验证手机的合法性

                if (Phone.Length < 11 || Phone.Length>11)
                {
                    ReturnStr = "{\"status\":\"error\",\"message\":\"输入不对。\"}";
                }
                string AllPhoneRegex = @"^0?(13[0-9]|15[012356789]|18[0123456789]|14[57]|17[0135678]|19[9])[0-9]{8}$";
                string VerCode = string.Empty;
                if (System.Text.RegularExpressions.Regex.IsMatch(Phone, AllPhoneRegex))
                {
                    VerCode = Yasn.Logic.CarAccessoryWXMember.QueryCode(Phone);
                    ReturnStr = "{\"status\":\"repeat\",\"message\":\"" + VerCode + "\"}";
                }
                else
                {
                    ReturnStr = "{\"status\":\"regex\",\"message\":\"输入不对。\"}";
                }
                return ReturnStr;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
    }
}