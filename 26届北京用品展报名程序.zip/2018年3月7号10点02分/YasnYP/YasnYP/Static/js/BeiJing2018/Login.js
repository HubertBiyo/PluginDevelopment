﻿var CodeFlag = null;
var PhoneFlag = null;
var IsNotNullFlag = null;
var Promise = function () {
    this.thens = [];
};
Promise.prototype = {
    resolve: function () {
        var t = this.thens.shift(), n;
        t && (n = t.apply(null, arguments), n instanceof Promise && (n.thens = this.thens));
    },
    then: function (n) {
        return this.thens.push(n), this;
    }
}



$(function () {
    $('#UserName').blur(function () {
        this.style.borderColor = this.value == '' ? '#FF9900' : 'green';
        if (this.value == '') {
            $("#login-Name").show();
        }
        else {
            $("#login-Name").hide();
        }
    })
    //工作单位
    $('#company').blur(function () {
        this.style.borderColor = this.value == '' ? '#FF9900' : 'green';
        if (this.value == '') {
            $("#login-Company").show();
        }
        else {
            $("#login-Company").hide();
        }
    })
    //职务
    $('#UserPosition').blur(function () {
        this.style.borderColor = this.value == '' ? '#FF9900' : 'green';
        if (this.value == '') {
            $("#login-UserPosition").show();
        }
        else {
            $("#login-UserPosition").hide();
        }
    })
    $("#SmartLoginInfo").validate({
        errorPlacement: function (error, element) {
            if (element.is(":input"))
                error.appendTo($("#msg" + element.attr("name")));
            else
                error.insertAfter(element);
        },
        submitHandler: function (form) {
            try {
                form.action = "/BeiJing2018/Login";
                form.target = "_self";
                form.method = "POST";
                form.submit();
            }
            catch (e) {
                alert("提交失败，请稍后重试");
            }
        }
    });
});
$(".SmartLoginSumbit").bind("click", function () {
    myCheck();

});
function myCheck() {
    if (document.getElementById("UserName").value == '' || document.getElementById("fl-trade").value == '' || document.getElementById("company").value == '' || document.getElementById("UserPosition").value == '' || document.getElementById("fl-Industry").value == '' || document.getElementById("fl-product").value == '' || document.getElementById("fl-purchase").value == '') {
        if (document.getElementById("UserName").value == '') {
            $("#login-Name").show();
        }
        else {
            $("#login-Name").hide();
        }
        if (document.getElementById("company").value == '') {
            $("#login-Company").show();
        }
        else {
            $("#login-Company").hide();
        }
        if (document.getElementById("UserPosition").value == '') {
            $("#login-UserPosition").show();
        }
        else {
            $("#login-UserPosition").hide();
        }
        if (document.getElementById("fl-trade").value == '') {
            $("#login-MainBusine").show();
        }
        else {
            $("#login-MainBusine").hide();
        }
        if (document.getElementById("fl-Industry").value == '') {
            $("#login-Industry").show();
        }
        else {
            $("#login-Industry").hide();
        }
       
        if (document.getElementById("fl-product").value == '') {
            $("#login-ManageType").show();
        }
        else {
            $("#login-ManageType").hide();
        }
        if (document.getElementById("fl-purchase").value == '') {
            $("#login-EnjoyProduct").show();
        }
        else {
            $("#login-EnjoyProduct").hide();
        }
        return;
    }
    else {
        $("#SmartLoginInfo").submit();

    }
}