﻿var CodeFlag = null;
var PhoneFlag = null;
var ZWCardFlag = null;
var ISZWCardFlag = null;
var ISNotNull = null;
var Promise = function () {
    this.thens = [];
};
Promise.prototype = {
    resolve: function () {
        var t = this.thens.shift(), n;
        t && (n = t.apply(null, arguments), n instanceof Promise && (n.thens = this.thens));
    },
    then: function (n) {
        return this.thens.push(n), this;
    }
}
window.onload = function () {
    /*设置遮罩黑色背景高度*/
    var showCover = document.querySelector("#show-content");
    if (showCover) {
        showCover.style.height = window.screen.availHeight + 'px';
    }
    /*设置遮罩黑色背景高度*/
    var showCover1 = document.querySelector("#show-cover");
    if (showCover1) {
        showCover1.style.height = window.screen.availHeight + 'px';
    }
}
$(function () {
    $('#UserMobile').blur(function () {
        this.style.borderColor = this.value == '' ? '#FF9900' : 'green';
        if (this.value == '') {
            $("#login-phone").show();
            $("#login-phone1").hide();
            $("#login-phone2").hide();
        }
        else {
            $("#login-phone").hide();
           // PhoneValidate();
        }

    })
    $('#txtcode').blur(function () {
        this.style.borderColor = this.value == '' ? '#FF9900' : 'green';
    })
    $("#Validatinfopost1").validate({
        errorPlacement: function (error, element) {
            if (element.is(":input"))
                error.appendTo($("#msg" + element.attr("name")));
            else
                error.insertAfter(element);
        },
        submitHandler: function (form) {
            try {
                if (CodeFlag == true && PhoneFlag == true) {
                    form.action = "/BeiJing2018/ValidatPage";
                    form.target = "_self";
                    form.method = "POST";
                    form.submit();
                }
            }
            catch (e) {
                alert("提交失败，请稍后重试");
            }
        }
    });
});
$(".ValidatPageSubmitYZM").bind("click", function () {
    PhoneValidate().then(CodeEnable).then(finalCheck);

});

function finalCheck() {
    $("#Validatinfopost1").submit();
}

function PhoneValidate() {//判断手机号是否符合规范
    var promise = new Promise();
    $.get("/BeiJing2018/CheckPhone", { UserMobile: $('#UserMobile').val(), WeiXinOpenId: $('#WeiXinOpenId').val() }, function (result) {
        var info = eval("(" + result + ")");
        if (info.status == "repeat") {
            $("#login-phone1").hide();
            $("#login-phone2").show();
            PhoneFlag = true;
        }
        else if (info.status == "pass") {
            $("#login-phone1").hide();
            $("#login-phone2").hide();
            PhoneFlag = true;
        }
        else if (info.status == "error") {
            $("#login-phone").hide();
            $("#login-phone1").show();
            $("#login-phone2").hide();
            PhoneFlag = false;
        }
        else {
            $("#login-phone1").hide();
            $("#login-phone").show();

            PhoneFlag = false;
        }
        promise.resolve();
    });
    return promise;

}

function CodeEnable() {//判断手机验证码是否有效 
    var promise = new Promise();
    $.getJSON("/BeiJing2018/ValidateCodeValid", { userPhone: $('#UserMobile').val(), validateCode: $('#txtcode').val() }, function (sendmess) {

        if (sendmess.resultMsg == 0) {
            $("#msgtxtcode").html('');
            $("#send-Rightcode").hide()

            CodeFlag = true;
        }
        if (sendmess.resultMsg == -1) {
            $("#msgtxtcode").html("<label generated=\"true\" for=\"txtcode\" class=\"error\" style=\"display: inline;\">验证码已过期，请重新获取</label>");
            CodeFlag = false;
        }
        if (sendmess.resultMsg == -2) {
            if (document.getElementById("txtcode").value == '') {
                $("#login-yzm").show();
                $("#send-Rightcode").hide();//显示验证码错误
            }
            else {
                $("#login-yzm").hide();
                $("#send-Rightcode").show();//显示验证码错误

            }
            $("#send-code").hide();     //隐藏短信发送成功文字信息

            CodeFlag = false;
        }
        promise.resolve();
    });
    return promise;

}

function ISPhoneBM() {//判断手机号和编码是否有效 
    var promise = new Promise();
    $.getJSON("/BeiJing2018/IsPhoneBM", { userPhone: $('#UserMobile').val(), Card: $('#RegistratCode').val() }, function (Isphone) {
        if (Isphone.resultMsg == 0) {
            CodeFlag = true;
        }
        if (Isphone.resultMsg == -2) {
            $("#show-cover").show();
            $("#bm").show();
            $("#bmOk").click(function () {
                $("#show-cover").hide();
                $("#bm").hide();
            });
            CodeFlag = false;
        }
        promise.resolve();
    });
    return promise;
}

function GetCode() {//获取验证码     失效时间为10分钟
    var v_mobile = $('#UserMobile').val();
    //非空验证
    if (v_mobile === undefined || v_mobile.replace(/\s*/, '') == '') {
        $('#UserMobile').focus();
        return false;
    }
    //格式验证
    if (!(/^1[3|4|5|6|7|8|9]\d{9}$/.test(v_mobile))) {
        $('#UserMobile').focus();
        return false;
    }
    $("#btGetCode").removeAttr('onclick');
    $.ajax({
        type: "POST",
        url: "/BeiJing2018/WriteValidateInfo",
        data: { phone: $('#UserMobile').val() },
        dataType: "json",
        cache: false,
        async: false,
        success: function (data) {
            if (data.resultMsg == 0) {
                //显示发送成功
                $("#send-code").show();
                $("#login-yzm").hide();
                $("#send-Rightcode").hide();
                jump(60);
            }
            if (data.resultMsg == -1) {
                alert('多次未收到验证码，请更换手机号或5分钟之后重新获取验证码');
            }
            if (data.resultMsg == -2) {
                $("#UserMobile").html("<label generated=\"true\" for=\"UserMobile\" class=\"error\" style=\"display: inline;\">该手机号码已提交申请，请更换手机号</label>");

            }
        },
        timeout: 600000
    });
}
function jump(count) {
    window.setTimeout(function () {
        count--;
        if (count > 0) {
            $("#btGetCode").html(count + '秒后重发');
            var stamp = document.getElementById("btGetCode");
            removeClass(stamp, "can-code");
            stamp.disabled = true;
            jump(count);
        } else {
            $("#btGetCode").html('获取验证码');
            var stamp = document.getElementById("btGetCode");
            stamp.disabled = false;
            addClass(stamp, "can-code");
            $("#btGetCode").attr('onclick', 'GetCode();')
        }
    }, 1000);
}
function removeClass(elements, cName) {
    if (hasClass(elements, cName)) {
        elements.className = elements.className.replace(new RegExp("(\\s|^)" + cName + "(\\s|$)"), " "); // replace方法是替换 
    }
}
function hasClass(elements, cName) {
    return !!elements.className.match(new RegExp("(\\s|^)" + cName + "(\\s|$)")); // ( \\s|^ ) 判断前面是否有空格 （\\s | $ ）判断后面是否有空格 两个感叹号为转换为布尔值 以方便做判断 
}
function addClass(elements, cName) {
    if (!hasClass(elements, cName)) {
        elements.className += " " + cName;
    }
}

