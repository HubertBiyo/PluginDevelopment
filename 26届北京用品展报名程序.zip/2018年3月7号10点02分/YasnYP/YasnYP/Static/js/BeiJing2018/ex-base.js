window.onload = function () {
  /*设置遮罩黑色背景高度*/
    var showCover = document.querySelector("#show-cover");
    if(showCover) {
        showCover.style.height = window.screen.availHeight + 'px';
    }
}