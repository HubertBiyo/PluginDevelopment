﻿var Promise = function () {
    this.thens = [];
};
Promise.prototype = {
    resolve: function () {
        var t = this.thens.shift(), n;
        t && (n = t.apply(null, arguments), n instanceof Promise && (n.thens = this.thens));
    },
    then: function (n) {
        return this.thens.push(n), this;
    }
}

//$(function () {
//    $("#VerCodeInfo").validate({
//        errorPlacement: function (error, element) {
//            if (element.is(":input"))
//                error.appendTo($("#msg" + element.attr("name")));
//            else
//                error.insertAfter(element);
//        },
//        submitHandler: function (form) {
//            try {
//                if (CodeFlag == true && PhoneFlag == true) {
//                    form.action = "/Tool/VerificatCode";
//                    form.target = "_self";
//                    form.method = "POST";
//                    form.submit();
//                }
//            }
//            catch (e) {
//                alert("提交失败，请稍后重试");
//            }
//        }
//    });
//});

$(".GetVerCode").bind("click", function () {
    GetVerCodeByPhone();
});

function GetVerCodeByPhone() {//判断手机号是否符合规范
    var promise = new Promise();
    $.get("/Tool/QueryVerificatCode", { UserMobile: $('#UserMobile').val() }, function (result) {
        var info = eval("(" + result + ")");
        if (info.status == "repeat") {
            $("#msgVerCodeShow").html(info.message);
            PhoneFlag = false;
        }
        else if (info.status == "error") {
            PhoneFlag = false;
            $("#msgVerCodeShow").html(info.message);
        }
        else {
            $("#msgVerCodeShow").html("输入不对");
            PhoneFlag = false;
        }
        promise.resolve();
    });
    return promise;
}